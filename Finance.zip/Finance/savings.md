# 💰 Savings Page - Feature Documentation & Enhancements

The **Savings Page** is a core module in the personal finance tracking website. It enables users to add, view, and track the performance of their savings in various formats such as deposits, digital gold, SIPs, stocks, and more. Below is a breakdown of the key logic and suggestions for improvements to enhance user experience and functionality.

---

## 🧾 Form Structure (Common for All Savings Types)

Each savings entry should support the following fields:

- **Amount**
- **Merchant** (Bank name / App / Institution)
- **Date**
- **Upload Statement** (PDF, CSV, etc.)

---

## 💡 Suggested Enhancements

### 1. 💼 Unified Savings Dashboard
- Total invested across all types.
- Segmented savings with color-coded cards.
- Filter/sort savings by date, merchant, type.

### 2. 📊 Data Visualizations
- **Pie Chart**: Distribution of investment types.
- **Bar Chart**: Monthly growth of total savings.
- **Line Graph**: Individual deposit growth over time (ideal for FDs, SIPs).
- **Donut Chart**: Showing proportions like "active", "matured", "closed" savings.

### 3. 🔔 Smart Notifications & Reminders
- Email/SMS/Push reminder for:
  - FD installment due.
  - SIP next debit.
  - Maturity approaching.
- Status-based badges like: `Pending`, `Successful`, `Matured`.

### 4. 📁 Attachments Handling
- Enable preview for uploaded PDFs (e.g., using PDF.js).
- OCR-based statement reader (future enhancement).

---

## 📥 Deposits

### Fields:
- Current Balance
- Deposit Type
- Maturity Amount
- Maturity Date
- Interest Rate
- Installment Date (for RD/FD)
- Upload Statement (PDF/CSV)

### Features:

#### 🗓️ Recurring Deposits (RD)
- Show monthly installment cards (Pending/Success)
- Installment tracking logic with:
  - Toggle: `Submit/Mark Paid`
  - Auto-mail confirmation
- Graphs for:
  - Total number of installments
  - Growth of RD over time
  - Expected maturity vs actual investment

#### 🔒 Fixed Deposits (FD)
- View all FDs with maturity countdown
- Highlight expired or matured FDs
- Chart for interest accumulation over time

---

## 🧱 Digital Gold
- Total grams held
- Value in INR (based on current market price via API)
- Show profit/loss since purchase
- Include timeline of gold purchases

---

## 📊 Stocks
- Display current holding, total investment, market value
- Fetch live stock data using public APIs
- Include:
  - Buy price vs current price
  - Dividend earnings (optional)
  - Graph: Portfolio value over time

---

## 📜 LIC / Insurance
- LIC Plan name and number
- Premium due dates
- Maturity date
- Premium history
- Reminder feature for premium payments

---

## 📅 Calendar Integration
- Show savings events like:
  - Installment dates
  - Maturity dates
  - Premium dues
- Exportable to Google Calendar / Outlook

---

## 👤 User Personalization
- Add user-specific goals (e.g., “Save ₹5,00,000 by 2026”)
- Track goal completion with progress bar

---

## 🔐 Security Suggestions
- Encrypted file uploads
- Mask sensitive fields (like bank account number)
- OTP for sensitive changes

---

## 🌐 Tech Suggestions
- PDF Preview: `pdf.js`
- Charts: `Chart.js` / `Recharts` / `ECharts`
- Email: `Nodemailer`
- Cron jobs for reminders
- OCR: `Tesseract.js` (optional)

---

## 🏁 Future Enhancements
- Auto-fetch statements from banks (with user permission)
- AI summary of savings performance
- Multi-user collaboration (Family accounts)

---

## 📂 Folder Structure Suggestion

