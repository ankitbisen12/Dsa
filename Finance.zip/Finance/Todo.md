TODO: If User is not logged then show login button otherwise show a profile icon with initial of names

TODO: Make sure all the user info like password should not expose in any frontend part.

TODO: Implement Google OAuth login //done on 2nd July

TODO: Implement 
