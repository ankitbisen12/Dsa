'use client';

import { ArrowRight, Award, BarChart, Lightbulb, Users, Twitter, Linkedin, Github, Mail, MapPin, Phone, Send } from 'lucide-react';
import Link from 'next/link';

export default function AboutPage() {
  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="relative bg-gradient-to-r from-blue-600 to-blue-800 text-white py-20">
        <div className="container mx-auto px-6 text-center">
          <h1 className="text-4xl md:text-6xl font-bold mb-6">About Our Company</h1>
          <p className="text-xl md:text-2xl max-w-3xl mx-auto mb-8">
            Empowering businesses with innovative financial solutions for a better tomorrow.
          </p>
          <div className="flex flex-wrap justify-center gap-4">
            <Link href="/transactions" className="bg-white text-blue-700 px-8 py-3 rounded-lg font-semibold hover:bg-blue-50 transition duration-300 flex items-center">
              Get Started <ArrowRight className="ml-2" size={18} />
            </Link>
            <a href="#contact" className="border-2 border-white text-white px-8 py-3 rounded-lg font-semibold hover:bg-white/10 transition duration-300">
              Contact Us
            </a>
          </div>
        </div>
        <div className="absolute bottom-0 left-0 right-0 h-16 bg-gradient-to-t from-white to-transparent"></div>
      </section>

      {/* Our Story */}
      <section className="py-20 bg-white">
        <div className="container mx-auto px-6">
          <div className="max-w-4xl mx-auto text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold mb-6">Our Story</h2>
            <div className="h-1 w-20 bg-blue-600 mx-auto mb-8"></div>
            <p className="text-gray-600 text-lg leading-relaxed">
              Founded in 2023, our journey began with a simple mission: to make financial management accessible and intuitive for businesses of all sizes. 
              What started as a small team of passionate individuals has grown into a trusted platform serving thousands of users worldwide.
            </p>
          </div>
          
          <div className="grid md:grid-cols-3 gap-12 mt-16">
            <div className="text-center p-6 rounded-xl hover:shadow-xl transition duration-300">
              <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <Lightbulb className="text-blue-600" size={28} />
              </div>
              <h3 className="text-xl font-semibold mb-3">Our Vision</h3>
              <p className="text-gray-600">To revolutionize financial management through innovative technology and exceptional user experiences.</p>
            </div>
            
            <div className="text-center p-6 rounded-xl hover:shadow-xl transition duration-300">
              <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <BarChart className="text-green-600" size={28} />
              </div>
              <h3 className="text-xl font-semibold mb-3">Our Mission</h3>
              <p className="text-gray-600">To empower businesses with the tools they need to achieve financial success and growth.</p>
            </div>
            
            <div className="text-center p-6 rounded-xl hover:shadow-xl transition duration-300">
              <div className="w-16 h-16 bg-purple-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <Award className="text-purple-600" size={28} />
              </div>
              <h3 className="text-xl font-semibold mb-3">Our Values</h3>
              <p className="text-gray-600">Integrity, innovation, and customer success are at the heart of everything we do.</p>
            </div>
          </div>
        </div>
      </section>

      {/* Team Section */}
      <section className="py-20 bg-gray-50">
        <div className="container mx-auto px-6">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Meet Our Team</h2>
            <div className="h-1 w-20 bg-blue-600 mx-auto mb-8"></div>
            <p className="text-gray-600 max-w-2xl mx-auto">
              Our diverse team of experts is dedicated to delivering exceptional financial solutions and support.
            </p>
          </div>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {teamMembers.map((member, index) => (
              <div key={index} className="bg-white rounded-xl overflow-hidden shadow-md hover:shadow-xl transition duration-300">
                <div className="h-64 bg-gray-200 relative overflow-hidden">
                  <img 
                    src={`https://source.unsplash.com/random/400x400/?portrait,${index}`} 
                    alt={member.name}
                    className="w-full h-full object-cover"
                  />
                </div>
                <div className="p-6 text-center">
                  <h3 className="text-xl font-semibold mb-1">{member.name}</h3>
                  <p className="text-blue-600 mb-3">{member.role}</p>
                  <p className="text-gray-600 text-sm">{member.bio}</p>
                  <div className="flex justify-center space-x-3 mt-4">
                    {member.socials.map((social, i) => (
                      <a 
                        key={i} 
                        href={social.url} 
                        target="_blank" 
                        rel="noopener noreferrer"
                        className="text-gray-500 hover:text-blue-600 transition"
                      >
                        {social.icon === 'twitter' ? <Twitter size={18} /> : 
                         social.icon === 'linkedin' ? <Linkedin size={18} /> : 
                         <Github size={18} />}
                      </a>
                    ))}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Stats */}
      <section className="py-20 bg-blue-600 text-white">
        <div className="container mx-auto px-6">
          <div className="grid md:grid-cols-4 gap-8 text-center">
            <div className="p-6">
              <div className="text-4xl font-bold mb-2">10K+</div>
              <p className="text-blue-100">Active Users</p>
            </div>
            <div className="p-6">
              <div className="text-4xl font-bold mb-2">50+</div>
              <p className="text-blue-100">Team Members</p>
            </div>
            <div className="p-6">
              <div className="text-4xl font-bold mb-2">15+</div>
              <p className="text-blue-100">Countries</p>
            </div>
            <div className="p-6">
              <div className="text-4xl font-bold mb-2">99.9%</div>
              <p className="text-blue-100">Uptime</p>
            </div>
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section id="contact" className="py-20 bg-white">
        <div className="container mx-auto px-6">
          <div className="max-w-4xl mx-auto">
            <div className="text-center mb-16">
              <h2 className="text-3xl md:text-4xl font-bold mb-4">Get In Touch</h2>
              <div className="h-1 w-20 bg-blue-600 mx-auto mb-8"></div>
              <p className="text-gray-600 max-w-2xl mx-auto">
                Have questions or want to learn more? We'd love to hear from you.
              </p>
            </div>
            
            <div className="grid md:grid-cols-2 gap-12">
              <div>
                <h3 className="text-xl font-semibold mb-6">Contact Information</h3>
                <div className="space-y-6">
                  <div className="flex items-start">
                    <div className="bg-blue-100 p-3 rounded-full mr-4">
                      <MapPin className="text-blue-600" size={20} />
                    </div>
                    <div>
                      <h4 className="font-medium text-gray-800">Our Location</h4>
                      <p className="text-gray-600">123 Finance Street, San Francisco, CA 94103</p>
                    </div>
                  </div>
                  
                  <div className="flex items-start">
                    <div className="bg-blue-100 p-3 rounded-full mr-4">
                      <Mail className="text-blue-600" size={20} />
                    </div>
                    <div>
                      <h4 className="font-medium text-gray-800">Email Us</h4>
                      <p className="text-gray-600">info@financetracker.com</p>
                    </div>
                  </div>
                  
                  <div className="flex items-start">
                    <div className="bg-blue-100 p-3 rounded-full mr-4">
                      <Phone className="text-blue-600" size={20} />
                    </div>
                    <div>
                      <h4 className="font-medium text-gray-800">Call Us</h4>
                      <p className="text-gray-600">+1 (555) 123-4567</p>
                    </div>
                  </div>
                </div>
                
                <div className="mt-8">
                  <h4 className="font-medium text-gray-800 mb-4">Follow Us</h4>
                  <div className="flex space-x-4">
                    <a href="#" className="bg-gray-100 p-3 rounded-full text-gray-600 hover:bg-blue-50 hover:text-blue-600 transition">
                      <Twitter size={20} />
                    </a>
                    <a href="#" className="bg-gray-100 p-3 rounded-full text-gray-600 hover:bg-blue-50 hover:text-blue-600 transition">
                      <Linkedin size={20} />
                    </a>
                    <a href="#" className="bg-gray-100 p-3 rounded-full text-gray-600 hover:bg-blue-50 hover:text-blue-600 transition">
                      <Github size={20} />
                    </a>
                  </div>
                </div>
              </div>
              
              <div className="bg-white rounded-xl shadow-lg p-8">
                <h3 className="text-xl font-semibold mb-6">Send Us a Message</h3>
                <form className="space-y-6">
                  <div>
                    <label htmlFor="name" className="block text-sm font-medium text-gray-700 mb-1">Full Name</label>
                    <input 
                      type="text" 
                      id="name" 
                      className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                      placeholder="John Doe"
                    />
                  </div>
                  
                  <div>
                    <label htmlFor="email" className="block text-sm font-medium text-gray-700 mb-1">Email Address</label>
                    <input 
                      type="email" 
                      id="email" 
                      className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                      placeholder="you@example.com"
                    />
                  </div>
                  
                  <div>
                    <label htmlFor="subject" className="block text-sm font-medium text-gray-700 mb-1">Subject</label>
                    <input 
                      type="text" 
                      id="subject" 
                      className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                      placeholder="How can we help?"
                    />
                  </div>
                  
                  <div>
                    <label htmlFor="message" className="block text-sm font-medium text-gray-700 mb-1">Message</label>
                    <textarea 
                      id="message" 
                      rows={4} 
                      className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                      placeholder="Your message here..."
                    ></textarea>
                  </div>
                  
                  <button 
                    type="submit" 
                    className="w-full bg-blue-600 text-white py-3 px-6 rounded-lg font-medium hover:bg-blue-700 transition duration-300 flex items-center justify-center"
                  >
                    Send Message <Send className="ml-2" size={18} />
                  </button>
                </form>
              </div>
            </div>
          </div>
        </div>
      </section>
      
      {/* CTA Section */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-6 text-center">
          <h2 className="text-3xl md:text-4xl font-bold mb-6">Ready to get started?</h2>
          <p className="text-gray-600 max-w-2xl mx-auto mb-8 text-lg">
            Join thousands of businesses that trust us with their financial management needs.
          </p>
          <Link 
            href="/transactions" 
            className="bg-blue-600 text-white px-8 py-3 rounded-lg font-semibold hover:bg-blue-700 transition duration-300 inline-flex items-center"
          >
            Start Free Trial <ArrowRight className="ml-2" size={18} />
          </Link>
        </div>
      </section>
    </div>
  );
}

// Team members data
const teamMembers = [
  {
    name: 'Alex Johnson',
    role: 'CEO & Founder',
    bio: 'Finance expert with over 15 years of experience in fintech and business development.',
    socials: [
      { icon: 'twitter', url: '#' },
      { icon: 'linkedin', url: '#' },
      { icon: 'github', url: '#' }
    ]
  },
  {
    name: 'Sarah Williams',
    role: 'CTO',
    bio: 'Tech visionary with a passion for building scalable financial platforms.',
    socials: [
      { icon: 'twitter', url: '#' },
      { icon: 'linkedin', url: '#' },
      { icon: 'github', url: '#' }
    ]
  },
  {
    name: 'Michael Chen',
    role: 'Lead Developer',
    bio: 'Full-stack developer specializing in modern web technologies and cloud architecture.',
    socials: [
      { icon: 'twitter', url: '#' },
      { icon: 'linkedin', url: '#' },
      { icon: 'github', url: '#' }
    ]
  },
  {
    name: 'Emily Rodriguez',
    role: 'Head of Design',
    bio: 'UI/UX designer focused on creating intuitive and beautiful user experiences.',
    socials: [
      { icon: 'twitter', url: '#' },
      { icon: 'linkedin', url: '#' },
      { icon: 'github', url: '#' }
    ]
  }
];
