"use server";

import { NextResponse } from "next/server";
import { getCurrentUser } from "../../app/lib/auth";
import User from "../../models/userModel";
import { sanitizeUser } from "../../utils/common";

export async function uploadImage(formData) {
    try {
        const file = formData.get('profileImage');
        
        if (!file) {
            return NextResponse.json(
                { error: "No file provided" },
                { status: 400 }
            );
        }

        const { _id } = await getCurrentUser();
        if (!_id) {
            return NextResponse.json(
                { error: "User not authenticated" },
                { status: 401 }
            );
        }

        const bytes = await file.arrayBuffer();
        const buffer = Buffer.from(bytes);

        const profileImage = {
            data: buffer,
            contentType: file.type,
        };

        const updatedUser = await User.findByIdAndUpdate(_id, 
            { profileImage },
            { new: true }
        );

        if (!updatedUser) {
            return NextResponse.json(
                { error: "User not found" },
                { status: 404 }
            );
        }

        return sanitizeUser(updatedUser);
    } catch (error) {
        console.error('Error uploading image:', error);
        return NextResponse.json(
            { error: error.message || "Error uploading image" },
            { status: 500 }
        );
    }
}

export async function updateProfile(updatedData) {
    try {
        console.log("updatedData",updatedData);  
        const {_id}  = await getCurrentUser();
        console.log("_id",_id);
        const updatedUser = await User.findByIdAndUpdate(_id, updatedData, { new: true });
        
        return sanitizeUser(updatedUser);
    } catch (error) {
        console.log("Error:", error);
    }
}

