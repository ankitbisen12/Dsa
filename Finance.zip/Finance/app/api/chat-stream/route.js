// app/api/chat-stream/route.js
export const config = {
    runtime: 'edge',
};

export async function POST(req) {
    try {
        const { message } = await req.json();

        if (!message || typeof message !== 'string') {
            return new Response(JSON.stringify({ error: 'Invalid message format' }), {
                status: 400,
                headers: { 'Content-Type': 'application/json' },
            });
        }

        if (!process.env.OPENAI_API_KEY) {
            console.error('OpenAI API key is not configured');
            return new Response(JSON.stringify({ error: 'Server configuration error' }), {
                status: 500,
                headers: { 'Content-Type': 'application/json' },
            });
        }

        const response = await fetch("https://api.openai.com/v1/chat/completions", {
            method: "POST",
            headers: {
                "Authorization": `Bearer ${process.env.OPENAI_API_KEY}`,
                "Content-Type": "application/json",
            },
            body: JSON.stringify({
                model: "gpt-3.5-turbo",
                messages: [
                    { role: "system", content: "You are a helpful finance assistant that helps users with their financial questions and analysis." },
                    { role: "user", content: message }
                ],
                temperature: 0.7,
                stream: true,
                max_tokens: 20,
            }),
        });

        if (!response.ok || !response.body) {
            const errorData = await response.json().catch(() => ({}));
            return new Response(JSON.stringify({
                error: 'Failed to fetch response from AI',
                details: errorData,
            }), {
                status: response.status,
                headers: { 'Content-Type': 'application/json' },
            });
        }

        return new Response(response.body, {
            headers: {
                'Content-Type': 'text/event-stream',
                'Cache-Control': 'no-cache',
                'Connection': 'keep-alive',
            },
        });
    } catch (error) {
        console.error('Error in chat-stream API:', error);
        return new Response(JSON.stringify({
            error: 'An unexpected error occurred',
            details: error.message,
        }), {
            status: 500,
            headers: { 'Content-Type': 'application/json' },
        });
    }
}
