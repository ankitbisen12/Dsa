"use server";

import Transaction from "../../models/transactionModel";
import { getCurrentUser } from "../lib/auth";
import { NextResponse } from "next/server";

export async function getAllTransactions() {
    try {
        const transactions = await Transaction.find({}).populate('user', '-password -salt').lean();
        const serializedTransactions = transactions.map((tx) => ({
            ...tx,
            _id: tx._id.toString(),
            user: {
                ...tx.user,
                _id: tx.user._id.toString(),
                createdAt: tx.user.createdAt.toString(),
                updatedAt: tx.user.updatedAt.toString(),
            },
            createdAt: tx.createdAt.toString(),
            updatedAt: tx.updatedAt.toString(),
        }));

        return serializedTransactions;
        return transactions;
    } catch (error) {
        return NextResponse.json({ error: "Failed to fetch transactions" }, { status: 500 });
    }
}

export async function getTransactionById(id) {
    try {
        const transaction = await Transaction.findById(id).populate('user', '-password -salt');
        if (!transaction) {
            return NextResponse.json({ error: 'Transaction not found' }, { status: 404 });
        }
        const serializedTransaction = {
            ...transaction.toObject(),
            _id: transaction._id.toString(),
            createdAt: transaction.createdAt.toString(),
            updatedAt: transaction.updatedAt.toString(),
            user: {
              ...transaction.user.toObject(),
              _id: transaction.user._id.toString(),
              createdAt: transaction.user.createdAt.toString(),
              updatedAt: transaction.user.updatedAt.toString(),
            },
          };
      
          return serializedTransaction;
    } catch (error) {
        return { error: 'Error fetching transaction' };
    }
}


export async function createTransaction(transaction) {
    try {
        const user = await getCurrentUser();
        const newTransaction = await Transaction.create({ ...transaction, user: user._id.toString() });
        console.log("new transcation created");
        return newTransaction;
    } catch (error) {
        console.log("error", error);
    }
}

export async function updateTransaction(id, transaction) {
    try {
        const updatedTransaction = await Transaction.findByIdAndUpdate(id, transaction, { new: true });
        if (!updatedTransaction) {
            return NextResponse.json({ error: 'Transaction not found' }, { status: 404 });
        }
        return NextResponse.json(updatedTransaction, { status: 200 });
    } catch (error) {
        return NextResponse.json({ error: 'Error updating transaction' }, { status: 500 });
    }
}

export async function deleteTransaction(id) {
    try {
        const deletedTransaction = await Transaction.findByIdAndDelete(id);
        if (!deletedTransaction) {
            return NextResponse.json({ error: 'Transaction not found' }, { status: 404 });
        }
        return NextResponse.json(deletedTransaction, { status: 200 });
    } catch (error) {
        return NextResponse.json({ error: 'Error deleting transaction' }, { status: 500 });
    }
}