import { NextResponse } from "next/server";
import { getCurrentUser } from "../../../../app/lib/auth";
import User from "../../../../models/userModel";

export async function GET() {
    try {
        const currentUser = await getCurrentUser();

        if (!currentUser?._id) {
            return new NextResponse("Unauthorized", { status: 401 });
        }

        const user = await User.findById(currentUser._id).select("profileImage");

        if (!user?.profileImage?.data) {
            return new NextResponse("Image not found", { status: 404 });
        }

        return new NextResponse(user.profileImage.data, {
            headers: {
                "Content-Type": user.profileImage.contentType,
                "Content-Length": user.profileImage.data.length.toString(),
                "Cache-Control": "public, max-age=86400"  // optional: cache for 1 day
            },
        });
    } catch (err) {
        return new NextResponse("Server error", { status: 500 });
    }
}
