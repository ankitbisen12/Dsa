import { NextResponse } from "next/server";
import { getGoogleAuthURL } from "../../../auth/google";

export async function GET() {
  const authURL = getGoogleAuthURL();
  return NextResponse.redirect(authURL);
}
