import { getGoogleUser } from "../../../../auth/google";
import { encrypt } from "../../../../lib/session";
import User from "../../../../../models/userModel";
import { cookies } from "next/headers";
import { redirect } from "next/navigation";

export async function GET(request) {
  const { searchParams } = new URL(request.url);
  const code = searchParams.get("code");

  if (!code) {
    return new Response("Authorization code not provided", { status: 400 });
  }

  try {
    // Get the Google user
    const googleUser = await getGoogleUser(code);
    console.log("googleUser", googleUser);
    // Find or create user in the database
    const user = await User.findOrCreate({
      name: googleUser.displayName,
      email: googleUser.email,
    });

    // Create session
    const session = await encrypt({
      userId: user._id.toString(),
      expires: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000), // 7 days
    });
    
    const expiresAt = new Date(Date.now() + 7 * 24 * 60 * 60 * 1000);
    const cookieStore = await cookies();
    // Set the session cookie
    cookieStore.set("session", session, {
      httpOnly: true,
      secure: true,
      expires: expiresAt,
    });

    // Redirect to dashboard or home page
    return redirect("/dashboard");
  } catch (error) {
    console.error("Error during Google OAuth callback:", error);
    return redirect(`/login`);
  }
}
