'use client';
import React, { useState } from 'react';
import Sidebar from '@/components/Sidebar';
import Header from '@/components/Header';
import AccountList from '@/components/accounts/AccountList';
import AccountSummary from '@/components/accounts/AccountSummary';

export default function AccountsPage() {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [activeFilter, setActiveFilter] = useState('All');

  const filters = ['All', 'Active', 'Inactive', 'Credit'];

  // Format currency function
  const formatCurrency = (amount) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
    }).format(amount);
  };

  return (
    <div className="flex h-screen bg-gray-50">
      {/* Sidebar */}
      <Sidebar isOpen={sidebarOpen} onClose={() => setSidebarOpen(false)} />

      {/* Main Content */}
      <div className="flex-1 flex flex-col overflow-hidden">
        {/* Header */}
        <Header onMenuClick={() => setSidebarOpen(true)} />

        {/* Main Content */}
        <main className="flex-1 overflow-x-hidden overflow-y-auto bg-gray-50 p-4 md:p-6">
          <div className="max-w-7xl mx-auto">
            {/* Page Title and Actions */}
            <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-6">
              <div>
                <h1 className="text-2xl font-bold text-gray-900">Accounts</h1>
                <p className="text-sm text-gray-500">Manage your financial accounts and balances</p>
              </div>
              <div className="mt-4 md:mt-0">
                <button className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-md text-sm font-medium">
                  + New Transaction
                </button>
              </div>
            </div>

            {/* Summary Cards */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
              <AccountSummary 
                title="Total Balance" 
                amount={formatCurrency(45800.95)} 
                icon="total"
                trend="up"
                trendPercentage="5.2%"
              />
              <AccountSummary 
                title="Monthly Income" 
                amount={formatCurrency(12500.50)} 
                icon="income"
                trend="up"
                trendPercentage="2.1%"
              />
              <AccountSummary 
                title="Monthly Expenses" 
                amount={formatCurrency(8750.30)} 
                icon="expense"
                trend="down"
                trendPercentage="3.8%"
              />
              <AccountSummary 
                title="Total Debt" 
                amount={formatCurrency(1250.30)} 
                icon="debt"
                trend="down"
                trendPercentage="1.5%"
              />
            </div>

            {/* Filter Tabs and Account List */}
            <div className="bg-white rounded-lg shadow overflow-hidden">
              {/* Filter Tabs */}
              <div className="border-b border-gray-200">
                <nav className="flex -mb-px overflow-x-auto">
                  {filters.map((filter) => (
                    <button
                      key={filter}
                      onClick={() => setActiveFilter(filter)}
                      className={`whitespace-nowrap py-4 px-6 border-b-2 font-medium text-sm ${
                        activeFilter === filter
                          ? 'border-blue-500 text-blue-600'
                          : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                      }`}
                    >
                      {filter}
                    </button>
                  ))}
                </nav>
              </div>

              {/* Account List */}
              <div className="p-4">
                <AccountList />
              </div>
            </div>
          </div>
        </main>
      </div>
    </div>
  );
}
