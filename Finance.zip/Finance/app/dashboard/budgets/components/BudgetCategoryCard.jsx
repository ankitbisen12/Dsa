'use client';

import { Card, CardContent, CardHeader, CardTitle } from '../../../../components/ui/card';
import { Progress } from '../../../../components/ui/progress';

export const BudgetCategoryCard = ({ category }) => {
  const remaining = category.budget - category.spent;
  const percentage = (category.spent / category.budget) * 100;
  
  const getProgressColor = (spent, budget) => {
    const percentage = (spent / budget) * 100;
    if (percentage > 90) return 'bg-red-500';
    if (percentage > 70) return 'bg-yellow-500';
    return 'bg-green-500';
  };

  return (
    <Card>
      <CardHeader className="pb-2">
        <div className="flex justify-between items-center">
          <CardTitle className="text-lg">{category.name}</CardTitle>
          <span className={`text-sm font-medium ${
            percentage > 100 ? 'text-red-500' : 'text-green-500'
          }`}>
            {percentage > 100 ? 'Over Budget' : `${Math.round(percentage)}% Used`}
          </span>
        </div>
      </CardHeader>
      <CardContent>
        <div className="flex justify-between text-sm mb-2">
          <span>Budget: ₹{category.budget.toLocaleString()}</span>
          <span>Spent: ₹{category.spent.toLocaleString()}</span>
        </div>
        <div className="flex justify-between text-sm mb-2">
          <span>Remaining: ₹{remaining.toLocaleString()}</span>
          <span>{Math.round(percentage)}%</span>
        </div>
        <Progress 
          value={Math.min(100, percentage)} 
          className={`h-2 ${getProgressColor(category.spent, category.budget)}`} 
        />
      </CardContent>
    </Card>
  );
};
