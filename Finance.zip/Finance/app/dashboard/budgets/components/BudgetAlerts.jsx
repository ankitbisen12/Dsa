'use client';

import { Alert, AlertDescription, AlertTitle } from '../../../../components/ui/alert';
import { AlertCircle } from 'lucide-react';

export const BudgetAlerts = ({ budgetData, totalSpent, monthlyBudget }) => {
  const overBudgetCategories = budgetData.filter(cat => cat.spent > cat.budget);
  const budgetUtilization = (totalSpent / monthlyBudget) * 100;

  return (
    <div className="space-y-4 mb-8">
      {overBudgetCategories.length > 0 && (
        <Alert variant="destructive">
          <AlertCircle className="h-4 w-4" />
          <AlertTitle>Over Budget Categories</AlertTitle>
          <AlertDescription>
            You've exceeded your budget in: {" "}
            {overBudgetCategories.map(cat => cat.name).join(", ")}
          </AlertDescription>
        </Alert>
      )}

      <Alert>
        <AlertCircle className="h-4 w-4" />
        <AlertTitle>Monthly Insight</AlertTitle>
        <AlertDescription>
          You've spent {budgetUtilization.toFixed(1)}% of your monthly budget so far.
          {totalSpent > monthlyBudget * 0.8 && " Consider reviewing your expenses to stay within budget."}
        </AlertDescription>
      </Alert>
    </div>
  );
};
