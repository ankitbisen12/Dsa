import { Card, CardContent, CardHeader, CardTitle } from '../../../../components/ui/card';
import { Progress } from '../../../../components/ui/progress';

export const BudgetOverview = ({ monthlyBudget, totalSpent, remainingBudget, budgetUtilization }) => {
  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
      <Card>
        <CardHeader className="pb-2">
          <CardTitle className="text-sm font-medium">Total Monthly Budget</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-2xl font-bold">₹{monthlyBudget.toLocaleString()}</div>
        </CardContent>
      </Card>
      <Card>
        <CardHeader className="pb-2">
          <CardTitle className="text-sm font-medium">Total Spent This Month</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-2xl font-bold">₹{totalSpent.toLocaleString()}</div>
        </CardContent>
      </Card>
      <Card>
        <CardHeader className="pb-2">
          <CardTitle className="text-sm font-medium">Remaining Budget</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-2xl font-bold">₹{remainingBudget.toLocaleString()}</div>
          <Progress value={budgetUtilization} className="h-2 mt-2" />
          <p className="text-xs text-muted-foreground mt-1">
            {budgetUtilization.toFixed(1)}% of budget used
          </p>
        </CardContent>
      </Card>
    </div>
  );
};
