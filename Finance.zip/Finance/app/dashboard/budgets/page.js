'use client';
import { useState, useEffect } from 'react';
import { BudgetOverview } from './components/BudgetOverview';
import { BudgetCategoryCard } from './components/BudgetCategoryCard';
import { BudgetCharts } from './components/BudgetCharts';
import { BudgetAlerts } from './components/BudgetAlerts';

// Sample data - in a real app, this would come from your API
const sampleCategories = [
  { id: 1, name: 'Housing / Rent', budget: 30000, spent: 28000 },
  { id: 2, name: 'Food & Groceries', budget: 15000, spent: 12000 },
  { id: 3, name: 'Transportation', budget: 8000, spent: 6500 },
  { id: 4, name: 'Utilities', budget: 5000, spent: 4800 },
  { id: 5, name: 'Entertainment', budget: 5000, spent: 5200 },
  { id: 6, name: 'Investments', budget: 20000, spent: 20000 },
];

const Budgets = () => {
  const [budgetData, setBudgetData] = useState(sampleCategories);
  const [monthlyBudget, setMonthlyBudget] = useState(85000);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    // Simulate API call
    const timer = setTimeout(() => {
      setIsLoading(false);
    }, 500);
    return () => clearTimeout(timer);
  }, []);

  const totalSpent = budgetData.reduce((sum, category) => sum + category.spent, 0);
  const remainingBudget = monthlyBudget - totalSpent;
  const budgetUtilization = Math.min(100, (totalSpent / monthlyBudget) * 100);

  const pieChartData = budgetData.map(category => ({
    name: category.name,
    value: category.budget
  }));

  const barChartData = budgetData.map(category => ({
    name: category.name,
    budget: category.budget,
    spent: category.spent,
    remaining: Math.max(0, category.budget - category.spent)
  }));

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary"></div>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold mb-8">Budget Management</h1>
      
      {/* 1. Monthly Budget Overview */}
      <BudgetOverview 
        monthlyBudget={monthlyBudget}
        totalSpent={totalSpent}
        remainingBudget={remainingBudget}
        budgetUtilization={budgetUtilization}
      />

      {/* 2. Budget Categories */}
      <h2 className="text-2xl font-semibold mb-4">Budget Categories</h2>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
        {budgetData.map((category) => (
          <BudgetCategoryCard key={category.id} category={category} />
        ))}
      </div>

      {/* 3. Budget Trends */}
      <h2 className="text-2xl font-semibold mb-4">Budget Trends</h2>
      <BudgetCharts 
        pieChartData={pieChartData} 
        barChartData={barChartData} 
      />

      {/* 4. Budget Alerts and Insights */}
      <h2 className="text-2xl font-semibold mb-4">Alerts & Insights</h2>
      <BudgetAlerts 
        budgetData={budgetData} 
        totalSpent={totalSpent} 
        monthlyBudget={monthlyBudget} 
      />
    </div>
  );
};

export default Budgets;