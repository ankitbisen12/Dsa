'use client';
import { useEffect, useState } from 'react';
import { useRouter, useParams } from 'next/navigation';
import { FiArrowLeft, FiEdit, FiTrash2, FiCalendar, FiDollarSign, FiClock, FiCheckCircle, FiClock as FiPending } from 'react-icons/fi';
import Link from 'next/link';

const RDDetailsPage = () => {
  const router = useRouter();
  const { id } = useParams();
  const [rdData, setRdData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchRdDetails = () => {
      try {
        // Get all savings from localStorage
        const savedSavings = JSON.parse(localStorage.getItem('savings') || '[]');
        const rd = savedSavings.find(s => s.id === parseInt(id) && s.type === 'rd');
        
        if (!rd) {
          setError('Recurring deposit not found');
          setLoading(false);
          return;
        }

        // Generate installment details
        const installments = generateInstallments(rd);
        setRdData({ ...rd, installments });
      } catch (err) {
        console.error('Error fetching RD details:', err);
        setError('Failed to load RD details');
      } finally {
        setLoading(false);
      }
    };

    fetchRdDetails();
  }, [id]);

  const generateInstallments = (rd) => {
    if (!rd.date || !rd.installments) return [];
    
    const installments = [];
    const startDate = new Date(rd.date);
    
    for (let i = 0; i < rd.installments; i++) {
      const dueDate = new Date(startDate);
      dueDate.setMonth(startDate.getMonth() + i);
      
      installments.push({
        number: i + 1,
        dueDate: dueDate.toISOString().split('T')[0],
        amount: rd.amount,
        status: i < (rd.paidInstallments || 0) ? 'paid' : 'pending',
        paymentDate: i < (rd.paidInstallments || 0) ? dueDate.toISOString().split('T')[0] : null
      });
    }
    
    return installments;
  };

  const handleMarkAsPaid = (installmentNumber) => {
    if (!rdData) return;
    
    try {
      const updatedRd = { ...rdData };
      updatedRd.paidInstallments = Math.max(rdData.paidInstallments || 0, installmentNumber);
      
      // Update in localStorage
      const savedSavings = JSON.parse(localStorage.getItem('savings') || '[]');
      const updatedSavings = savedSavings.map(s => 
        s.id === rdData.id ? updatedRd : s
      );
      
      localStorage.setItem('savings', JSON.stringify(updatedSavings));
      setRdData(updatedRd);
      
      // Refresh the page to show updated data
      window.location.reload();
    } catch (err) {
      console.error('Error updating installment status:', err);
    }
  };

  const formatDate = (dateString) => {
    if (!dateString) return 'N/A';
    const options = { year: 'numeric', month: 'short', day: 'numeric' };
    return new Date(dateString).toLocaleDateString('en-US', options);
  };

  const calculateMaturityAmount = () => {
    if (!rdData) return 0;
    const principal = rdData.amount * rdData.installments;
    const rate = (rdData.interestRate || 0) / 100;
    const n = 12; // Compounded monthly
    const t = rdData.installments / 12; // Time in years
    
    // A = P * (1 + r/n)^(n*t)
    return principal * Math.pow(1 + rate/n, n*t);
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-blue-500"></div>
      </div>
    );
  }


  if (error || !rdData) {
    return (
      <div className="max-w-4xl mx-auto p-6">
        <div className="bg-red-50 border-l-4 border-red-400 p-4 mb-6">
          <div className="flex">
            <div className="flex-shrink-0">
              <svg className="h-5 w-5 text-red-400" viewBox="0 0 20 20" fill="currentColor">
                <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 101.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z" clipRule="evenodd" />
              </svg>
            </div>
            <div className="ml-3">
              <p className="text-sm text-red-700">
                {error || 'Failed to load RD details. Please try again.'}
              </p>
            </div>
          </div>
        </div>
        <Link href="/savings" className="inline-flex items-center text-blue-600 hover:text-blue-800">
          <FiArrowLeft className="mr-1" /> Back to Savings
        </Link>
      </div>
    );
  }

  const maturityAmount = calculateMaturityAmount();
  const totalPaid = (rdData.amount || 0) * (rdData.paidInstallments || 0);
  const nextInstallment = rdData.installments.find(i => i.status === 'pending');

  return (
    <div className="max-w-4xl mx-auto p-4 sm:p-6">
      <div className="mb-6">
        <Link href="/savings" className="inline-flex items-center text-blue-600 hover:text-blue-800 mb-4">
          <FiArrowLeft className="mr-1" /> Back to Savings
        </Link>
        
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-6">
          <div>
            <h1 className="text-2xl font-bold text-gray-900">{rdData.title}</h1>
            <p className="text-gray-600">{rdData.institution}</p>
          </div>
          <div className="mt-4 sm:mt-0 flex space-x-3">
            <Link 
              href={`/savings/rd/${id}/edit`}
              className="inline-flex items-center px-4 py-2 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
            >
              <FiEdit className="mr-2 h-4 w-4" /> Edit
            </Link>
            <button
              onClick={() => {
                if (window.confirm('Are you sure you want to delete this RD?')) {
                  // Handle delete
                  const savedSavings = JSON.parse(localStorage.getItem('savings') || '[]');
                  const updatedSavings = savedSavings.filter(s => s.id !== rdData.id);
                  localStorage.setItem('savings', JSON.stringify(updatedSavings));
                  router.push('/savings');
                }
              }}
              className="inline-flex items-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-red-600 hover:bg-red-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-red-500"
            >
              <FiTrash2 className="mr-2 h-4 w-4" /> Delete
            </button>
          </div>
        </div>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
        <div className="bg-white p-4 rounded-lg shadow">
          <p className="text-sm font-medium text-gray-500">Monthly Installment</p>
          <p className="text-xl font-semibold">₹{rdData.amount?.toLocaleString() || '0'}</p>
        </div>
        <div className="bg-white p-4 rounded-lg shadow">
          <p className="text-sm font-medium text-gray-500">Paid Installments</p>
          <p className="text-xl font-semibold">{rdData.paidInstallments || 0} / {rdData.installments?.length || 0}</p>
        </div>
        <div className="bg-white p-4 rounded-lg shadow">
          <p className="text-sm font-medium text-gray-500">Next Due</p>
          <p className="text-xl font-semibold flex items-center">
            <FiCalendar className="mr-2 text-blue-500" />
            {nextInstallment ? formatDate(nextInstallment.dueDate) : 'N/A'}
          </p>
        </div>
        <div className="bg-white p-4 rounded-lg shadow">
          <p className="text-sm font-medium text-gray-500">Maturity Amount</p>
          <p className="text-xl font-semibold">₹{maturityAmount.toFixed(2)}</p>
        </div>
      </div>

      {/* Progress */}
      <div className="bg-white p-6 rounded-lg shadow mb-8">
        <h2 className="text-lg font-semibold mb-4">Progress</h2>
        <div className="mb-2 flex justify-between text-sm text-gray-600">
          <span>₹0</span>
          <span>₹{(rdData.amount * rdData.installments).toLocaleString()}</span>
        </div>
        <div className="w-full bg-gray-200 rounded-full h-4">
          <div 
            className="bg-blue-600 h-4 rounded-full" 
            style={{ 
              width: `${((rdData.paidInstallments || 0) / rdData.installments) * 100}%`,
              transition: 'width 0.3s ease-in-out'
            }}
          ></div>
        </div>
        <div className="mt-2 text-right text-sm text-gray-500">
          {Math.round(((rdData.paidInstallments || 0) / rdData.installments) * 100)}% Complete
        </div>
      </div>

      {/* Installments Table */}
      <div className="bg-white shadow rounded-lg overflow-hidden">
        <div className="px-6 py-4 border-b border-gray-200">
          <h2 className="text-lg font-semibold">Installments</h2>
        </div>
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
              <tr>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Installment
                </th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Due Date
                </th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Amount
                </th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Status
                </th>
                <th scope="col" className="relative px-6 py-3">
                  <span className="sr-only">Actions</span>
                </th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {rdData.installments?.map((installment) => (
                <tr key={installment.number} className="hover:bg-gray-50">
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                    #{installment.number}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    {formatDate(installment.dueDate)}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    ₹{installment.amount?.toLocaleString() || '0'}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${
                      installment.status === 'paid' 
                        ? 'bg-green-100 text-green-800' 
                        : 'bg-yellow-100 text-yellow-800'
                    }`}>
                      {installment.status === 'paid' ? 'Paid' : 'Pending'}
                    </span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                    {installment.status === 'pending' && (
                      <button
                        onClick={() => handleMarkAsPaid(installment.number)}
                        className="text-blue-600 hover:text-blue-900 mr-4"
                      >
                        Mark as Paid
                      </button>
                    )}
                    {installment.status === 'paid' && (
                      <span className="text-green-600 flex items-center">
                        <FiCheckCircle className="mr-1" />
                        Paid on {formatDate(installment.paymentDate)}
                      </span>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* RD Summary */}
      <div className="mt-8 grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="bg-white p-6 rounded-lg shadow">
          <h3 className="text-lg font-medium text-gray-900 mb-4">RD Summary</h3>
          <dl className="space-y-4">
            <div className="flex justify-between">
              <dt className="text-sm font-medium text-gray-500">Start Date</dt>
              <dd className="text-sm text-gray-900">{formatDate(rdData.date)}</dd>
            </div>
            <div className="flex justify-between">
              <dt className="text-sm font-medium text-gray-500">Maturity Date</dt>
              <dd className="text-sm text-gray-900">{formatDate(rdData.maturityDate)}</dd>
            </div>
            <div className="flex justify-between">
              <dt className="text-sm font-medium text-gray-500">Interest Rate</dt>
              <dd className="text-sm text-gray-900">{rdData.interestRate}%</dd>
            </div>
            <div className="flex justify-between">
              <dt className="text-sm font-medium text-gray-500">Total Investment</dt>
              <dd className="text-sm text-gray-900">₹{(rdData.amount * rdData.installments).toLocaleString()}</dd>
            </div>
            <div className="flex justify-between">
              <dt className="text-sm font-medium text-gray-500">Total Interest</dt>
              <dd className="text-sm text-gray-900">₹{(maturityAmount - (rdData.amount * rdData.installments)).toFixed(2)}</dd>
            </div>
            <div className="border-t border-gray-200 pt-4 mt-4">
              <div className="flex justify-between">
                <dt className="text-base font-medium text-gray-900">Maturity Amount</dt>
                <dd className="text-base font-semibold text-blue-600">₹{maturityAmount.toFixed(2)}</dd>
              </div>
            </div>
          </dl>
        </div>
        
        <div className="bg-white p-6 rounded-lg shadow">
          <h3 className="text-lg font-medium text-gray-900 mb-4">Recent Transactions</h3>
          {rdData.installments?.filter(i => i.status === 'paid').slice(0, 5).length > 0 ? (
            <div className="space-y-4">
              {rdData.installments
                .filter(i => i.status === 'paid')
                .sort((a, b) => new Date(b.paymentDate) - new Date(a.paymentDate))
                .slice(0, 5)
                .map((installment) => (
                  <div key={installment.number} className="flex items-center p-3 border border-gray-100 rounded-lg">
                    <div className="flex-shrink-0 h-10 w-10 rounded-full bg-green-100 flex items-center justify-center">
                      <FiCheckCircle className="h-5 w-5 text-green-600" />
                    </div>
                    <div className="ml-4">
                      <p className="text-sm font-medium text-gray-900">Installment #{installment.number}</p>
                      <p className="text-xs text-gray-500">Paid on {formatDate(installment.paymentDate)}</p>
                    </div>
                    <div className="ml-auto text-right">
                      <p className="text-sm font-medium text-gray-900">₹{installment.amount?.toLocaleString() || '0'}</p>
                      <p className="text-xs text-green-600">Completed</p>
                    </div>
                  </div>
                ))}
            </div>
          ) : (
            <div className="text-center py-8">
              <FiClock className="mx-auto h-12 w-12 text-gray-400" />
              <h4 className="mt-2 text-sm font-medium text-gray-900">No transactions yet</h4>
              <p className="mt-1 text-sm text-gray-500">Your payment history will appear here.</p>
            </div>
          )}
          
          <div className="mt-6">
            <h4 className="text-sm font-medium text-gray-900 mb-2">Need help?</h4>
            <p className="text-sm text-gray-500">
              If you have any questions about your RD, please contact our support team.
            </p>
            <button className="mt-2 text-sm font-medium text-blue-600 hover:text-blue-500">
              Contact Support
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default RDDetailsPage;
