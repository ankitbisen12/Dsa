'use client';
import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { FiPlus, FiSearch, FiFilter, FiDownload, FiUpload, FiChevronDown, FiChevronUp, FiTrendingUp, FiTrendingDown, FiShield, FiDollarSign } from 'react-icons/fi';
import dynamic from 'next/dynamic';

// Dynamically import components with no SSR
const SavingsCard = dynamic(() => import('../../../components/savings/SavingsCard'), { ssr: false });
const SavingsChart = dynamic(() => import('../../../components/savings/SavingsChart'), { ssr: false });
const AddSavingsModal = dynamic(() => import('../../../components/savings/AddSavingsModal'), { ssr: false });

export default function SavingsPage() {
  const [savings, setSavings] = useState([]);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingSaving, setEditingSaving] = useState(null);
  const [activeTab, setActiveTab] = useState('all');
  const [timeRange, setTimeRange] = useState('thisMonth');
  const [searchQuery, setSearchQuery] = useState('');
  const [showFilters, setShowFilters] = useState(false);
  const [filters, setFilters] = useState({
    type: 'all',
    status: 'all',
    dateRange: 'all',
  });

  const router = useRouter();

  // Fetch savings data from localStorage on component mount
  useEffect(() => {
    const fetchSavings = () => {
      try {
        const savedSavings = localStorage.getItem('savings');
        if (savedSavings) {
          setSavings(JSON.parse(savedSavings));
        } else {
          // Initialize with sample data if no data exists
          const sampleData = [
            // Fixed Deposits
            {
              id: 1,
              type: 'fd',
              title: 'Fixed Deposit',
              amount: 250000,
              institution: 'HDFC Bank',
              date: '2023-01-15',
              maturityDate: '2025-01-15',
              interestRate: 6.5,
              status: 'active',
            },
            {
              id: 2,
              type: 'fd',
              title: 'Tax Saver FD',
              amount: 150000,
              institution: 'ICICI Bank',
              date: '2023-03-20',
              maturityDate: '2028-03-20', // 5 years
              interestRate: 7.1,
              status: 'active',
              taxSaving: true
            },
            
            // Recurring Deposits
            {
              id: 3,
              type: 'rd',
              title: 'Monthly RD',
              amount: 10000,
              institution: 'SBI',
              date: '2023-06-01',
              maturityDate: '2024-06-01',
              interestRate: 5.8,
              status: 'active',
              installments: 12,
              paidInstallments: 7,
            },
            
            // Digital Gold
            {
              id: 4,
              type: 'gold',
              title: 'Digital Gold',
              amount: 15000,
              institution: 'PhonePe',
              date: '2023-03-10',
              quantity: 2.5, // in grams
              currentValue: 16250,
              status: 'active',
            },
            {
              id: 5,
              type: 'gold',
              title: 'Sovereign Gold Bond',
              amount: 50000,
              institution: 'RBI',
              date: '2022-11-15',
              quantity: 8.5, // in grams
              currentValue: 55250,
              interestRate: 2.5,
              status: 'active',
              maturityDate: '2027-11-15'
            },
            
            // Insurance Policies (LIC)
            {
              id: 6,
              type: 'insurance',
              title: 'LIC Jeevan Anand',
              policyNumber: 'LIC12345678',
              premiumAmount: 50000,
              sumAssured: 2500000,
              institution: 'LIC',
              startDate: '2022-05-15',
              maturityDate: '2042-05-15',
              premiumFrequency: 'yearly',
              status: 'active',
              nextPremiumDue: '2024-05-15',
              currentValue: 550000,
              bonusAmount: 50000
            },
            {
              id: 7,
              type: 'insurance',
              title: 'LIC Term Insurance',
              policyNumber: 'LIC87654321',
              premiumAmount: 12500,
              sumAssured: 10000000,
              institution: 'LIC',
              startDate: '2021-11-10',
              premiumFrequency: 'yearly',
              status: 'active',
              nextPremiumDue: '2023-11-10',
              policyTerm: 30,
              isTermPlan: true
            },
            {
              id: 8,
              type: 'insurance',
              title: 'LIC Money Back Policy',
              policyNumber: 'LIC24681357',
              premiumAmount: 35000,
              sumAssured: 500000,
              institution: 'LIC',
              startDate: '2020-08-22',
              maturityDate: '2030-08-22',
              premiumFrequency: 'yearly',
              status: 'active',
              nextPremiumDue: '2023-08-22',
              currentValue: 280000,
              nextSurvivalBenefit: '2025-08-22',
              survivalBenefitAmount: 150000
            },
            
            // Stocks
            {
              id: 9,
              type: 'stocks',
              symbol: 'RELIANCE',
              company: 'Reliance Industries',
              quantity: 10,
              averagePrice: 2500,
              currentPrice: 2850,
              investment: 25000,
              currentValue: 28500,
              institution: 'Zerodha',
              purchaseDate: '2023-01-10',
              profitLoss: 3500,
              profitLossPercentage: 14,
              status: 'active',
              sector: 'Oil & Gas',
              lastDividend: 9 // per share
            },
            {
              id: 10,
              type: 'stocks',
              symbol: 'TCS',
              company: 'Tata Consultancy Services',
              quantity: 15,
              averagePrice: 3200,
              currentPrice: 3550,
              investment: 48000,
              currentValue: 53250,
              institution: 'Groww',
              purchaseDate: '2022-11-05',
              profitLoss: 5250,
              profitLossPercentage: 10.94,
              status: 'active',
              sector: 'IT',
              lastDividend: 24 // per share
            },
            {
              id: 11,
              type: 'stocks',
              symbol: 'HDFCBANK',
              company: 'HDFC Bank',
              quantity: 25,
              averagePrice: 1450,
              currentPrice: 1650,
              investment: 36250,
              currentValue: 41250,
              institution: 'Zerodha',
              purchaseDate: '2023-02-18',
              profitLoss: 5000,
              profitLossPercentage: 13.79,
              status: 'active',
              sector: 'Banking',
              lastDividend: 19 // per share
            },
            {
              id: 12,
              type: 'stocks',
              symbol: 'INFY',
              company: 'Infosys',
              quantity: 30,
              averagePrice: 1250,
              currentPrice: 1420,
              investment: 37500,
              currentValue: 42600,
              institution: 'Groww',
              purchaseDate: '2022-09-12',
              profitLoss: 5100,
              profitLossPercentage: 13.6,
              status: 'active',
              sector: 'IT',
              lastDividend: 16.5 // per share
            },
          ];
          setSavings(sampleData);
          localStorage.setItem('savings', JSON.stringify(sampleData));
        }
      } catch (error) {
        console.error('Error fetching savings:', error);
      }
    };

    fetchSavings();
  }, []);

  // Save to localStorage whenever savings change
  useEffect(() => {
    if (savings.length > 0) {
      localStorage.setItem('savings', JSON.stringify(savings));
    }
  }, [savings]);

  const handleAddSavings = (newSaving) => {
    if (editingSaving) {
      // Update existing saving
      setSavings(savings.map(s => s.id === editingSaving.id ? { ...newSaving, id: editingSaving.id } : s));
      setEditingSaving(null);
    } else {
      // Add new saving
      setSavings([...savings, { ...newSaving, id: Date.now() }]);
    }
  };

  const handleEditSaving = (saving) => {
    setEditingSaving(saving);
    setIsModalOpen(true);
  };

  const handleDeleteSaving = (id) => {
    if (window.confirm('Are you sure you want to delete this savings entry?')) {
      setSavings(savings.filter(saving => saving.id !== id));
    }
  };

  const filteredSavings = savings.filter((saving) => {
    // Apply search filter
    const matchesSearch = saving.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (saving.institution && saving.institution.toLowerCase().includes(searchQuery.toLowerCase()));
    
    // Apply type filter
    const matchesType = filters.type === 'all' || saving.type === filters.type;
    
    // Apply status filter
    const matchesStatus = filters.status === 'all' || saving.status === filters.status;
    
    return matchesSearch && matchesType && matchesStatus;
  });

  const totalSavings = savings.reduce((sum, saving) => sum + (saving.currentValue || saving.amount), 0);
  const totalInvested = savings.reduce((sum, saving) => sum + saving.amount, 0);
  const totalReturns = totalSavings - totalInvested;

  return (
    <div className="p-6">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-6">
        <div>
          <h1 className="text-2xl font-bold">Savings</h1>
          <p className="text-gray-500">Track and manage your savings</p>
        </div>
        <div className="mt-4 md:mt-0">
          <button 
            onClick={() => {
              setEditingSaving(null);
              setIsModalOpen(true);
            }}
            className="flex items-center space-x-2 bg-blue-600 text-white px-4 py-2 rounded-md hover:bg-blue-700 transition-colors w-full md:w-auto justify-center"
          >
            <FiPlus />
            <span>Add Savings</span>
          </button>
        </div>
      </div>

      {/* Stats Overview */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
        <div className="bg-white p-4 rounded-lg shadow">
          <div className="flex items-center justify-between">
            <p className="text-gray-500 text-sm">Total Savings</p>
            <FiDollarSign className="text-blue-500" />
          </div>
          <p className="text-2xl font-bold mt-1">₹{totalSavings.toLocaleString()}</p>
          <div className="h-2 bg-gray-200 rounded-full mt-3">
            <div 
              className="h-full bg-blue-500 rounded-full" 
              style={{ width: '100%' }}
            ></div>
          </div>
        </div>
        
        <div className="bg-white p-4 rounded-lg shadow">
          <div className="flex items-center justify-between">
            <p className="text-gray-500 text-sm">Total Invested</p>
            <FiDollarSign className="text-green-500" />
          </div>
          <p className="text-2xl font-bold mt-1">₹{totalInvested.toLocaleString()}</p>
        </div>
        
        <div className="bg-white p-4 rounded-lg shadow">
          <div className="flex items-center justify-between">
            <p className="text-gray-500 text-sm">Total Returns</p>
            {totalReturns >= 0 ? (
              <FiTrendingUp className="text-green-500" />
            ) : (
              <FiTrendingDown className="text-red-500" />
            )}
          </div>
          <p className={`text-2xl font-bold mt-1 ${totalReturns >= 0 ? 'text-green-600' : 'text-red-600'}`}>
            {totalReturns >= 0 ? '+' : ''}₹{Math.abs(totalReturns).toLocaleString()}
          </p>
          <p className="text-xs text-gray-500 mt-1">
            {totalInvested > 0 ? `(${((totalReturns / totalInvested) * 100).toFixed(2)}% return)` : ''}
          </p>
        </div>
        
        <div className="bg-white p-4 rounded-lg shadow">
          <div className="flex items-center justify-between">
            <p className="text-gray-500 text-sm">Insurance Coverage</p>
            <FiShield className="text-purple-500" />
          </div>
          <p className="text-2xl font-bold mt-1">
            ₹{savings
              .filter(s => s.type === 'insurance')
              .reduce((sum, policy) => sum + (policy.sumAssured || 0), 0)
              .toLocaleString()}
          </p>
          <p className="text-xs text-gray-500 mt-1">
            {savings.filter(s => s.type === 'insurance').length} active policy{savings.filter(s => s.type === 'insurance').length !== 1 ? 's' : ''}
          </p>
        </div>
      </div>

      {/* Filters and Search */}
      <div className="bg-white p-4 rounded-lg shadow mb-6">
        <div className="flex flex-col md:flex-row md:items-center justify-between space-y-3 md:space-y-0">
          <div className="relative flex-1 max-w-md">
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
              <FiSearch className="text-gray-400" />
            </div>
            <input
              type="text"
              placeholder="Search savings..."
              className="pl-10 pr-4 py-2 border rounded-md w-full focus:outline-none focus:ring-2 focus:ring-blue-500"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>
          
          <div className="flex space-x-3">
            <button 
              onClick={() => setShowFilters(!showFilters)}
              className="flex items-center space-x-2 px-4 py-2 border rounded-md hover:bg-gray-50"
            >
              <FiFilter />
              <span>Filters</span>
              {showFilters ? <FiChevronUp /> : <FiChevronDown />}
            </button>
            <button className="flex items-center space-x-2 px-4 py-2 border rounded-md hover:bg-gray-50">
              <FiDownload />
              <span>Export</span>
            </button>
          </div>
        </div>

        {/* Expanded Filters */}
        {showFilters && (
          <div className="mt-4 pt-4 border-t grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Type</label>
              <select 
                className="w-full p-2 border rounded-md"
                value={filters.type}
                onChange={(e) => setFilters({...filters, type: e.target.value})}
              >
                <option value="all">All Types</option>
                <option value="fd">Fixed Deposit</option>
                <option value="rd">Recurring Deposit</option>
                <option value="gold">Digital Gold</option>
                <option value="stocks">Stocks</option>
                <option value="insurance">Insurance</option>
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Status</label>
              <select 
                className="w-full p-2 border rounded-md"
                value={filters.status}
                onChange={(e) => setFilters({...filters, status: e.target.value})}
              >
                <option value="all">All Status</option>
                <option value="active">Active</option>
                <option value="matured">Matured</option>
                <option value="closed">Closed</option>
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Time Range</label>
              <select 
                className="w-full p-2 border rounded-md"
                value={filters.dateRange}
                onChange={(e) => setFilters({...filters, dateRange: e.target.value})}
              >
                <option value="all">All Time</option>
                <option value="thisMonth">This Month</option>
                <option value="lastMonth">Last Month</option>
                <option value="thisYear">This Year</option>
                <option value="lastYear">Last Year</option>
              </select>
            </div>
          </div>
        )}
      </div>

      {/* Savings Chart */}
      <div className="bg-white p-6 rounded-lg shadow mb-6">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-4">
          <h2 className="text-lg font-semibold mb-2 md:mb-0">Savings Overview</h2>
          <select 
            className="p-2 border rounded-md text-sm"
            value={timeRange}
            onChange={(e) => setTimeRange(e.target.value)}
          >
            <option value="thisMonth">This Month</option>
            <option value="lastMonth">Last Month</option>
            <option value="thisYear">This Year</option>
            <option value="all">All Time</option>
          </select>
        </div>
        <div className="h-64">
          <SavingsChart data={savings} timeRange={timeRange} />
        </div>
      </div>

      {/* Investment Type Tabs */}
      <div className="flex flex-wrap gap-2 mb-4">
        <button 
          onClick={() => setFilters({...filters, type: 'all'})}
          className={`px-3 py-1.5 text-sm rounded-full ${filters.type === 'all' ? 'bg-blue-100 text-blue-700' : 'bg-gray-100 text-gray-700 hover:bg-gray-200'}`}
        >
          All
        </button>
        <button 
          onClick={() => setFilters({...filters, type: 'fd'})}
          className={`px-3 py-1.5 text-sm rounded-full flex items-center ${filters.type === 'fd' ? 'bg-blue-100 text-blue-700' : 'bg-gray-100 text-gray-700 hover:bg-gray-200'}`}
        >
          <span className="mr-1">🏦</span> FDs
        </button>
        <button 
          onClick={() => setFilters({...filters, type: 'rd'})}
          className={`px-3 py-1.5 text-sm rounded-full flex items-center ${filters.type === 'rd' ? 'bg-blue-100 text-blue-700' : 'bg-gray-100 text-gray-700 hover:bg-gray-200'}`}
        >
          <span className="mr-1">📈</span> RDs
        </button>
        <button 
          onClick={() => setFilters({...filters, type: 'gold'})}
          className={`px-3 py-1.5 text-sm rounded-full flex items-center ${filters.type === 'gold' ? 'bg-blue-100 text-blue-700' : 'bg-gray-100 text-gray-700 hover:bg-gray-200'}`}
        >
          <span className="mr-1">🥇</span> Gold
        </button>
        <button 
          onClick={() => setFilters({...filters, type: 'stocks'})}
          className={`px-3 py-1.5 text-sm rounded-full flex items-center ${filters.type === 'stocks' ? 'bg-blue-100 text-blue-700' : 'bg-gray-100 text-gray-700 hover:bg-gray-200'}`}
        >
          <span className="mr-1">📊</span> Stocks
        </button>
        <button 
          onClick={() => setFilters({...filters, type: 'insurance'})}
          className={`px-3 py-1.5 text-sm rounded-full flex items-center ${filters.type === 'insurance' ? 'bg-blue-100 text-blue-700' : 'bg-gray-100 text-gray-700 hover:bg-gray-200'}`}
        >
          <span className="mr-1">🛡️</span> Insurance
        </button>
      </div>

      {/* Savings List */}
      <div className="space-y-4">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center">
          <div>
            <h2 className="text-lg font-semibold">
              {filters.type === 'all' ? 'All Investments' : 
               filters.type === 'fd' ? 'Fixed Deposits' :
               filters.type === 'rd' ? 'Recurring Deposits' :
               filters.type === 'gold' ? 'Digital Gold' :
               filters.type === 'stocks' ? 'Stock Investments' :
               filters.type === 'insurance' ? 'Insurance Policies' : 'My Savings'}
            </h2>
            <p className="text-sm text-gray-500">
              {filteredSavings.length} {filteredSavings.length === 1 ? 'item' : 'items'}
              {filters.status !== 'all' ? ` • ${filters.status.charAt(0).toUpperCase() + filters.status.slice(1)}` : ''}
            </p>
          </div>
          
          <div className="mt-2 md:mt-0 flex items-center space-x-2">
            <select 
              className="text-sm border rounded-md p-1.5 bg-white"
              value={filters.status}
              onChange={(e) => setFilters({...filters, status: e.target.value})}
            >
              <option value="all">All Status</option>
              <option value="active">Active</option>
              <option value="matured">Matured</option>
              <option value="closed">Closed</option>
            </select>
            
            <select 
              className="text-sm border rounded-md p-1.5 bg-white"
              value={filters.dateRange}
              onChange={(e) => setFilters({...filters, dateRange: e.target.value})}
            >
              <option value="all">All Time</option>
              <option value="thisMonth">This Month</option>
              <option value="lastMonth">Last Month</option>
              <option value="thisYear">This Year</option>
            </select>
          </div>
        </div>

        {filteredSavings.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {filteredSavings.map((saving) => (
              <SavingsCard 
                key={saving.id} 
                saving={saving} 
                onEdit={handleEditSaving}
                onDelete={handleDeleteSaving}
              />
            ))}
          </div>
        ) : (
          <div className="text-center py-12 bg-white rounded-lg shadow">
            <p className="text-gray-500">No savings found. Add your first savings to get started.</p>
            <button 
              onClick={() => {
                setEditingSaving(null);
                setIsModalOpen(true);
              }}
              className="mt-4 text-blue-600 hover:text-blue-800 font-medium"
            >
              Add Savings
            </button>
          </div>
        )}
      </div>

      {/* Add/Edit Savings Modal */}
      <AddSavingsModal 
        isOpen={isModalOpen} 
        onClose={() => {
          setIsModalOpen(false);
          setEditingSaving(null);
        }} 
        onSave={(saving) => {
          handleAddSavings(saving);
          setIsModalOpen(false);
          setEditingSaving(null);
        }}
        initialData={editingSaving}
      />
    </div>
  );
}
