'use client';
import { useEffect, useState } from 'react';
import { useRouter, useParams } from 'next/navigation';
import { FiArrowLeft, FiEdit, FiTrash2, FiCalendar, FiDollarSign, FiClock, FiCheckCircle, FiInfo } from 'react-icons/fi';
import Link from 'next/link';

const InsuranceDetailsPage = () => {
  const router = useRouter();
  const { id } = useParams();
  const [insuranceData, setInsuranceData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchInsuranceDetails = () => {
      try {
        // Get all savings from localStorage
        const savedSavings = JSON.parse(localStorage.getItem('savings') || '[]');
        const insurance = savedSavings.find(s => s.id === parseInt(id) && s.type === 'insurance');
        
        if (!insurance) {
          setError('Insurance policy not found');
          setLoading(false);
          return;
        }

        setInsuranceData(insurance);
      } catch (err) {
        console.error('Error fetching insurance details:', err);
        setError('Failed to load insurance details');
      } finally {
        setLoading(false);
      }
    };

    fetchInsuranceDetails();
  }, [id]);

  const formatDate = (dateString) => {
    if (!dateString) return 'N/A';
    const options = { year: 'numeric', month: 'short', day: 'numeric' };
    return new Date(dateString).toLocaleDateString('en-US', options);
  };

  const calculateMaturityBonus = () => {
    if (!insuranceData) return 0;
    // Simple calculation - in a real app, this would use the policy's bonus rate
    const yearsHeld = (new Date().getFullYear() - new Date(insuranceData.startDate).getFullYear());
    return Math.round(insuranceData.sumAssured * 0.05 * yearsHeld); // 5% of sum assured per year
  };

  const calculateSurrenderValue = () => {
    if (!insuranceData) return 0;
    // Simple calculation - in a real app, this would use the policy's surrender value formula
    const yearsHeld = (new Date().getFullYear() - new Date(insuranceData.startDate).getFullYear());
    if (yearsHeld < 3) return 0; // Typically no surrender value in first 3 years
    return Math.round(insuranceData.sumAssured * 0.3); // 30% of sum assured as surrender value
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-blue-500"></div>
      </div>
    );
  }

  if (error || !insuranceData) {
    return (
      <div className="max-w-4xl mx-auto p-6">
        <div className="bg-red-50 border-l-4 border-red-400 p-4 mb-6">
          <div className="flex">
            <div className="flex-shrink-0">
              <svg className="h-5 w-5 text-red-400" viewBox="0 0 20 20" fill="currentColor">
                <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 101.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z" clipRule="evenodd" />
              </svg>
            </div>
            <div className="ml-3">
              <p className="text-sm text-red-700">
                {error || 'Failed to load insurance details. Please try again.'}
              </p>
            </div>
          </div>
        </div>
        <Link href="/savings" className="inline-flex items-center text-blue-600 hover:text-blue-800">
          <FiArrowLeft className="mr-1" /> Back to Savings
        </Link>
      </div>
    );
  }

  const maturityBonus = calculateMaturityBonus();
  const surrenderValue = calculateSurrenderValue();
  const nextPremiumDue = new Date(insuranceData.nextPremiumDue);
  const today = new Date();
  const isPremiumDue = nextPremiumDue <= today;
  const daysUntilPremium = Math.ceil((nextPremiumDue - today) / (1000 * 60 * 60 * 24));

  return (
    <div className="max-w-4xl mx-auto p-4 sm:p-6">
      <div className="mb-6">
        <Link href="/savings" className="inline-flex items-center text-blue-600 hover:text-blue-800 mb-4">
          <FiArrowLeft className="mr-1" /> Back to Savings
        </Link>
        
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-6">
          <div>
            <h1 className="text-2xl font-bold text-gray-900">{insuranceData.title}</h1>
            <p className="text-gray-600">Policy No: {insuranceData.policyNumber}</p>
          </div>
          <div className="mt-4 sm:mt-0 flex space-x-3">
            <Link 
              href={`/savings/insurance/${id}/edit`}
              className="inline-flex items-center px-4 py-2 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
            >
              <FiEdit className="mr-2 h-4 w-4" /> Edit
            </Link>
            <button
              onClick={() => {
                if (window.confirm('Are you sure you want to delete this insurance policy?')) {
                  const savedSavings = JSON.parse(localStorage.getItem('savings') || '[]');
                  const updatedSavings = savedSavings.filter(s => s.id !== insuranceData.id);
                  localStorage.setItem('savings', JSON.stringify(updatedSavings));
                  router.push('/savings');
                }
              }}
              className="inline-flex items-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-red-600 hover:bg-red-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-red-500"
            >
              <FiTrash2 className="mr-2 h-4 w-4" /> Delete
            </button>
          </div>
        </div>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 mb-8">
        <div className="bg-white p-4 rounded-lg shadow">
          <p className="text-sm font-medium text-gray-500">Sum Assured</p>
          <p className="text-xl font-semibold">₹{insuranceData.sumAssured?.toLocaleString() || '0'}</p>
        </div>
        <div className="bg-white p-4 rounded-lg shadow">
          <p className="text-sm font-medium text-gray-500">Current Value</p>
          <p className="text-xl font-semibold">₹{insuranceData.currentValue?.toLocaleString() || '0'}</p>
        </div>
        <div className="bg-white p-4 rounded-lg shadow">
          <p className="text-sm font-medium text-gray-500">Next Premium Due</p>
          <div className="flex items-center">
            <FiCalendar className={`mr-2 ${isPremiumDue ? 'text-red-500' : 'text-yellow-500'}`} />
            <div>
              <p className="font-medium">{formatDate(insuranceData.nextPremiumDue)}</p>
              <p className={`text-sm ${isPremiumDue ? 'text-red-600' : 'text-gray-500'}`}>
                {isPremiumDue ? 'Overdue' : `Due in ${daysUntilPremium} days`}
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Policy Details */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
        <div className="bg-white p-6 rounded-lg shadow">
          <h3 className="text-lg font-medium text-gray-900 mb-4">Policy Details</h3>
          <dl className="space-y-4">
            <div className="flex justify-between">
              <dt className="text-sm font-medium text-gray-500">Policy Number</dt>
              <dd className="text-sm text-gray-900">{insuranceData.policyNumber || 'N/A'}</dd>
            </div>
            <div className="flex justify-between">
              <dt className="text-sm font-medium text-gray-500">Start Date</dt>
              <dd className="text-sm text-gray-900">{formatDate(insuranceData.startDate)}</dd>
            </div>
            <div className="flex justify-between">
              <dt className="text-sm font-medium text-gray-500">Maturity Date</dt>
              <dd className="text-sm text-gray-900">{formatDate(insuranceData.maturityDate)}</dd>
            </div>
            <div className="flex justify-between">
              <dt className="text-sm font-medium text-gray-500">Premium Amount</dt>
              <dd className="text-sm text-gray-900">₹{insuranceData.premiumAmount?.toLocaleString() || '0'}</dd>
            </div>
            <div className="flex justify-between">
              <dt className="text-sm font-medium text-gray-500">Premium Frequency</dt>
              <dd className="text-sm text-gray-900 capitalize">{insuranceData.premiumFrequency || 'N/A'}</dd>
            </div>
            <div className="flex justify-between">
              <dt className="text-sm font-medium text-gray-500">Status</dt>
              <dd className="text-sm">
                <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                  insuranceData.status === 'active' ? 'bg-green-100 text-green-800' : 
                  insuranceData.status === 'lapsed' ? 'bg-red-100 text-red-800' : 
                  'bg-gray-100 text-gray-800'
                }`}>
                  {insuranceData.status?.charAt(0).toUpperCase() + insuranceData.status?.slice(1) || 'N/A'}
                </span>
              </dd>
            </div>
          </dl>
        </div>

        <div className="bg-white p-6 rounded-lg shadow">
          <h3 className="text-lg font-medium text-gray-900 mb-4">Value & Benefits</h3>
          <div className="space-y-4">
            <div className="p-4 bg-blue-50 rounded-lg">
              <h4 className="text-sm font-medium text-blue-800">Maturity Benefit</h4>
              <p className="text-2xl font-bold text-blue-600">₹{(insuranceData.sumAssured + maturityBonus)?.toLocaleString()}</p>
              <p className="text-xs text-blue-600 mt-1">Sum Assured + Bonus</p>
            </div>
            
            <div className="p-4 bg-green-50 rounded-lg">
              <h4 className="text-sm font-medium text-green-800">Surrender Value</h4>
              <p className="text-2xl font-bold text-green-600">₹{surrenderValue?.toLocaleString()}</p>
              <p className="text-xs text-green-600 mt-1">Current surrender value</p>
            </div>
            
            <div className="p-4 bg-yellow-50 rounded-lg">
              <h4 className="text-sm font-medium text-yellow-800">Death Benefit</h4>
              <p className="text-2xl font-bold text-yellow-600">₹{insuranceData.sumAssured?.toLocaleString()}</p>
              <p className="text-xs text-yellow-600 mt-1">Paid to nominee in case of death</p>
            </div>
          </div>
        </div>
      </div>

      {/* Premium History */}
      <div className="bg-white p-6 rounded-lg shadow mb-8">
        <div className="flex justify-between items-center mb-4">
          <h3 className="text-lg font-medium text-gray-900">Premium Payment History</h3>
          <button className="text-sm font-medium text-blue-600 hover:text-blue-500">
            View All
          </button>
        </div>
        
        <div className="space-y-4">
          {[1, 2, 3].map((item) => (
            <div key={item} className="flex items-center p-3 border border-gray-100 rounded-lg">
              <div className="flex-shrink-0 h-10 w-10 rounded-full bg-green-100 flex items-center justify-center">
                <FiCheckCircle className="h-5 w-5 text-green-600" />
              </div>
              <div className="ml-4">
                <p className="text-sm font-medium text-gray-900">Premium Payment</p>
                <p className="text-xs text-gray-500">Paid on {formatDate('2023-05-15')}</p>
              </div>
              <div className="ml-auto text-right">
                <p className="text-sm font-medium text-gray-900">₹{insuranceData.premiumAmount?.toLocaleString() || '0'}</p>
                <p className="text-xs text-green-600">Paid</p>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Policy Documents */}
      <div className="bg-white p-6 rounded-lg shadow mb-8">
        <h3 className="text-lg font-medium text-gray-900 mb-4">Policy Documents</h3>
        <div className="border border-dashed border-gray-300 rounded-lg p-6 text-center">
          <FiInfo className="mx-auto h-12 w-12 text-gray-400" />
          <h4 className="mt-2 text-sm font-medium text-gray-900">No documents uploaded</h4>
          <p className="mt-1 text-sm text-gray-500">Upload your policy documents for easy access</p>
          <button className="mt-4 inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500">
            Upload Document
          </button>
        </div>
      </div>

      {/* Important Notes */}
      <div className="bg-yellow-50 border-l-4 border-yellow-400 p-4">
        <div className="flex">
          <div className="flex-shrink-0">
            <FiInfo className="h-5 w-5 text-yellow-400" />
          </div>
          <div className="ml-3">
            <p className="text-sm text-yellow-700">
              <span className="font-medium">Note:</span> This is a simplified view. For complete policy details, please refer to your original policy document or contact your insurance provider.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default InsuranceDetailsPage;
