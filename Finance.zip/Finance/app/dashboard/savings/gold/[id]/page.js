'use client';
import { useEffect, useState } from 'react';
import { useRouter, useParams } from 'next/navigation';
import { FiArrowLeft, FiEdit, FiTrash2, FiCalendar, FiDollarSign, FiTrendingUp, FiBarChart2, FiClock, FiAlertCircle } from 'react-icons/fi';
import Link from 'next/link';

const GoldDetailsPage = () => {
  const router = useRouter();
  const { id } = useParams();
  const [goldData, setGoldData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [currentGoldPrice, setCurrentGoldPrice] = useState(0);
  const [priceChange, setPriceChange] = useState(0);

  useEffect(() => {
    const fetchGoldDetails = async () => {
      try {
        // Get all savings from localStorage
        const savedSavings = JSON.parse(localStorage.getItem('savings') || '[]');
        const gold = savedSavings.find(s => s.id === parseInt(id) && s.type === 'gold');
        
        if (!gold) {
          setError('Digital gold investment not found');
          setLoading(false);
          return;
        }

        // In a real app, you would fetch current gold price from an API
        // For demo purposes, we'll use a mock price
        const mockCurrentPrice = 6250; // Mock current price per gram
        const purchasePrice = gold.pricePerGram || 6000; // Default to 6000 if not set
        const change = ((mockCurrentPrice - purchasePrice) / purchasePrice * 100).toFixed(2);
        
        setCurrentGoldPrice(mockCurrentPrice);
        setPriceChange(parseFloat(change));
        setGoldData({
          ...gold,
          currentValue: (gold.quantity * mockCurrentPrice).toFixed(2)
        });
      } catch (err) {
        console.error('Error fetching gold details:', err);
        setError('Failed to load gold investment details');
      } finally {
        setLoading(false);
      }
    };

    fetchGoldDetails();
  }, [id]);

  const formatDate = (dateString) => {
    if (!dateString) return 'N/A';
    const options = { year: 'numeric', month: 'short', day: 'numeric' };
    return new Date(dateString).toLocaleDateString('en-US', options);
  };

  const calculateProfitLoss = () => {
    if (!goldData) return 0;
    const currentValue = parseFloat(goldData.currentValue);
    const totalInvested = goldData.quantity * goldData.pricePerGram;
    return (currentValue - totalInvested).toFixed(2);
  };

  const getPriceChangeClass = (change) => {
    if (change > 0) return 'text-green-600';
    if (change < 0) return 'text-red-600';
    return 'text-gray-600';
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-yellow-500"></div>
      </div>
    );
  }


  if (error || !goldData) {
    return (
      <div className="max-w-4xl mx-auto p-6">
        <div className="bg-red-50 border-l-4 border-red-400 p-4 mb-6">
          <div className="flex">
            <div className="flex-shrink-0">
              <svg className="h-5 w-5 text-red-400" viewBox="0 0 20 20" fill="currentColor">
                <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 101.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z" clipRule="evenodd" />
              </svg>
            </div>
            <div className="ml-3">
              <p className="text-sm text-red-700">
                {error || 'Failed to load gold investment details. Please try again.'}
              </p>
            </div>
          </div>
        </div>
        <Link href="/savings" className="inline-flex items-center text-blue-600 hover:text-blue-800">
          <FiArrowLeft className="mr-1" /> Back to Savings
        </Link>
      </div>
    );
  }

  const profitLoss = calculateProfitLoss();
  const profitLossPercentage = (priceChange).toFixed(2);
  const isProfit = profitLoss >= 0;

  return (
    <div className="max-w-4xl mx-auto p-4 sm:p-6">
      <div className="mb-6">
        <Link href="/savings" className="inline-flex items-center text-blue-600 hover:text-blue-800 mb-4">
          <FiArrowLeft className="mr-1" /> Back to Savings
        </Link>
        
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-6">
          <div>
            <h1 className="text-2xl font-bold text-gray-900">{goldData.title}</h1>
            <p className="text-gray-600">{goldData.provider || 'Digital Gold'}</p>
          </div>
          <div className="mt-4 sm:mt-0 flex space-x-3">
            <Link 
              href={`/savings/gold/${id}/edit`}
              className="inline-flex items-center px-4 py-2 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-yellow-500"
            >
              <FiEdit className="mr-2 h-4 w-4" /> Edit
            </Link>
            <button
              onClick={() => {
                if (window.confirm('Are you sure you want to delete this gold investment?')) {
                  const savedSavings = JSON.parse(localStorage.getItem('savings') || '[]');
                  const updatedSavings = savedSavings.filter(s => s.id !== goldData.id);
                  localStorage.setItem('savings', JSON.stringify(updatedSavings));
                  router.push('/savings');
                }
              }}
              className="inline-flex items-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-red-600 hover:bg-red-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-red-500"
            >
              <FiTrash2 className="mr-2 h-4 w-4" /> Delete
            </button>
          </div>
        </div>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
        <div className="bg-white p-4 rounded-lg shadow">
          <p className="text-sm font-medium text-gray-500">Current Value</p>
          <p className="text-xl font-semibold">₹{parseFloat(goldData.currentValue).toLocaleString('en-IN', { maximumFractionDigits: 2 })}</p>
        </div>
        <div className="bg-white p-4 rounded-lg shadow">
          <p className="text-sm font-medium text-gray-500">Quantity</p>
          <p className="text-xl font-semibold">{goldData.quantity} grams</p>
        </div>
        <div className="bg-white p-4 rounded-lg shadow">
          <p className="text-sm font-medium text-gray-500">Current Price</p>
          <div className="flex items-center">
            <p className="text-xl font-semibold mr-2">₹{currentGoldPrice}/g</p>
            <span className={`text-sm ${getPriceChangeClass(priceChange)} flex items-center`}>
              {priceChange > 0 ? '↑' : priceChange < 0 ? '↓' : ''} {Math.abs(priceChange)}%
            </span>
          </div>
        </div>
        <div className={`bg-white p-4 rounded-lg shadow ${isProfit ? 'text-green-600' : 'text-red-600'}`}>
          <p className="text-sm font-medium">Profit/Loss</p>
          <p className="text-xl font-semibold">
            {isProfit ? '+' : ''}₹{Math.abs(profitLoss).toLocaleString('en-IN', { maximumFractionDigits: 2 })}
            <span className="text-sm ml-2">({profitLossPercentage}%)</span>
          </p>
        </div>
      </div>

      {/* Gold Price Chart */}
      <div className="bg-white p-6 rounded-lg shadow mb-8">
        <h2 className="text-lg font-semibold mb-4">Gold Price Trend</h2>
        <div className="h-64 flex items-center justify-center bg-gray-50 rounded-lg">
          <div className="text-center">
            <FiBarChart2 className="mx-auto h-12 w-12 text-gray-400" />
            <p className="mt-2 text-sm text-gray-500">Gold price chart will be displayed here</p>
          </div>
        </div>
      </div>

      {/* Gold Details */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
        <div className="bg-white p-6 rounded-lg shadow">
          <h3 className="text-lg font-medium text-gray-900 mb-4">Investment Details</h3>
          <dl className="space-y-4">
            <div className="flex justify-between">
              <dt className="text-sm font-medium text-gray-500">Purchase Date</dt>
              <dd className="text-sm text-gray-900">{formatDate(goldData.date)}</dd>
            </div>
            <div className="flex justify-between">
              <dt className="text-sm font-medium text-gray-500">Purchase Price</dt>
              <dd className="text-sm text-gray-900">₹{goldData.pricePerGram?.toLocaleString('en-IN')}/g</dd>
            </div>
            <div className="flex justify-between">
              <dt className="text-sm font-medium text-gray-500">Total Invested</dt>
              <dd className="text-sm text-gray-900">₹{(goldData.quantity * goldData.pricePerGram).toLocaleString('en-IN', { maximumFractionDigits: 2 })}</dd>
            </div>
            <div className="flex justify-between">
              <dt className="text-sm font-medium text-gray-500">Storage Type</dt>
              <dd className="text-sm text-gray-900">{goldData.storageType || 'Digital'}</dd>
            </div>
            {goldData.purity && (
              <div className="flex justify-between">
                <dt className="text-sm font-medium text-gray-500">Purity</dt>
                <dd className="text-sm text-gray-900">{goldData.purity}</dd>
              </div>
            )}
          </dl>
        </div>
        
        <div className="bg-white p-6 rounded-lg shadow">
          <h3 className="text-lg font-medium text-gray-900 mb-4">Quick Actions</h3>
          <div className="space-y-4">
            <button className="w-full flex items-center justify-center px-4 py-3 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-yellow-500">
              <FiTrendingUp className="mr-2 h-5 w-5 text-yellow-500" />
              Buy More Gold
            </button>
            <button className="w-full flex items-center justify-center px-4 py-3 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-yellow-500">
              <FiDollarSign className="mr-2 h-5 w-5 text-green-500" />
              Sell Gold
            </button>
            <button className="w-full flex items-center justify-center px-4 py-3 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-yellow-500">
              <FiCalendar className="mr-2 h-5 w-5 text-blue-500" />
              Set Price Alert
            </button>
          </div>
          
          <div className="mt-6">
            <h4 className="text-sm font-medium text-gray-900 mb-2">Need help?</h4>
            <p className="text-sm text-gray-500 mb-3">
              Have questions about your gold investment? Our support team is here to help.
            </p>
            <button className="text-sm font-medium text-yellow-600 hover:text-yellow-500">
              Contact Support
            </button>
          </div>
        </div>
      </div>

      {/* Recent Transactions */}
      <div className="bg-white p-6 rounded-lg shadow">
        <div className="flex justify-between items-center mb-4">
          <h3 className="text-lg font-medium text-gray-900">Transaction History</h3>
          <button className="text-sm font-medium text-yellow-600 hover:text-yellow-500">
            View All
          </button>
        </div>
        
        {goldData.transactions?.length > 0 ? (
          <div className="space-y-4">
            {goldData.transactions.map((txn, index) => (
              <div key={index} className="flex items-center p-3 border border-gray-100 rounded-lg">
                <div className={`flex-shrink-0 h-10 w-10 rounded-full flex items-center justify-center ${
                  txn.type === 'buy' ? 'bg-green-100 text-green-600' : 'bg-red-100 text-red-600'
                }`}>
                  {txn.type === 'buy' ? 'B' : 'S'}
                </div>
                <div className="ml-4">
                  <p className="text-sm font-medium text-gray-900">
                    {txn.type === 'buy' ? 'Gold Purchased' : 'Gold Sold'}
                  </p>
                  <p className="text-xs text-gray-500">{formatDate(txn.date)}</p>
                </div>
                <div className="ml-auto text-right">
                  <p className="text-sm font-medium text-gray-900">
                    {txn.type === 'buy' ? '+' : '-'}{txn.quantity}g
                  </p>
                  <p className={`text-xs ${txn.type === 'buy' ? 'text-green-600' : 'text-red-600'}`}>
                    {txn.type === 'buy' ? 'Debited' : 'Credited'} ₹{txn.amount?.toLocaleString('en-IN')}
                  </p>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="text-center py-8">
            <FiClock className="mx-auto h-12 w-12 text-gray-400" />
            <h4 className="mt-2 text-sm font-medium text-gray-900">No transactions yet</h4>
            <p className="mt-1 text-sm text-gray-500">Your transaction history will appear here.</p>
          </div>
        )}
      </div>

      {/* Important Notes */}
      <div className="mt-6 bg-yellow-50 border-l-4 border-yellow-400 p-4">
        <div className="flex">
          <div className="flex-shrink-0">
            <FiAlertCircle className="h-5 w-5 text-yellow-400" />
          </div>
          <div className="ml-3">
            <p className="text-sm text-yellow-700">
              <span className="font-medium">Note:</span> Gold prices are subject to market risks. The current value shown is an estimate and actual buy/sell prices may vary.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default GoldDetailsPage;
