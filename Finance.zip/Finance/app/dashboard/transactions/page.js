import React from 'react';
import { getAllTransactions } from "../../api/transaction";
import TransactionList from "../../../components/transactions/TransactionList";

export default async function TransactionsPage() {
  const transaction = await getAllTransactions();

  return (
    <TransactionList transaction={transaction} />
  );
}
