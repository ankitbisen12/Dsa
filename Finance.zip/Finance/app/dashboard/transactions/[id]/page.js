import React from "react";
import { getTransactionById } from "../../../api/transaction";
import TransactionDetail from "../../../../components/transactions/TransactionDetail";


export default async function TransactionDetailsPage({ params }) {
  const {id} = await params;
  const transaction = await getTransactionById(id);

  return (
    <React.Fragment>
          <TransactionDetail transaction={transaction} />
    </React.Fragment>
  );
}   
