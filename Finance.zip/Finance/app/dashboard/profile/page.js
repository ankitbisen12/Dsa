import { getCurrentUser } from "../../lib/auth";
import UserProfile from "../../../components/UserProfile";

const Profile = async () => {
  const user = await getCurrentUser();
 
  return <UserProfile user={user} />
};

export default Profile;