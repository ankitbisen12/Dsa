'use client';

import { useState, useEffect } from 'react';
import { FiArrowUpRight, FiClock, FiBookOpen, FiExternalLink } from 'react-icons/fi';
import { motion } from 'framer-motion';

// Mock news data
const mockNews = [
  {
    id: 1,
    source: 'Bloomberg',
    time: 'Today 10:30',
    title: 'Stock markets reach all-time high as tech rally continues',
    summary: 'Global markets surged to record levels as tech stocks led gains amid positive earnings reports.',
    icon: 'B',
    iconColor: 'bg-blue-500',
  },
  {
    id: 2,
    source: 'NVIDIA',
    time: 'Today 09:45',
    title: 'NVIDIA announces new AI chips with 3x performance boost',
    summary: 'The new H200 GPU promises significant improvements in AI training and inference workloads.',
    icon: 'N',
    iconColor: 'bg-green-500',
  },
  {
    id: 3,
    source: 'TSLA',
    time: 'Today 08:15',
    title: 'Tesla unveils new battery technology with 400-mile range',
    summary: 'The new battery promises faster charging and longer lifespan for electric vehicles.',
    icon: 'T',
    iconColor: 'bg-red-500',
  },
  {
    id: 4,
    source: 'CNBC',
    time: 'Yesterday 16:30',
    title: 'Federal Reserve signals potential rate cuts in 2024',
    summary: 'Investors react to the Fed\'s latest economic projections and policy statements.',
    icon: 'C',
    iconColor: 'bg-purple-500',
  },
  {
    id: 5,
    source: 'WSJ',
    time: 'Yesterday 14:20',
    title: 'Bitcoin surges past $50,000 as institutional interest grows',
    summary: 'Cryptocurrency markets rally as major financial institutions announce new crypto services.',
    icon: 'W',
    iconColor: 'bg-yellow-500',
  },
];

export default function NewsPage() {
  const [news, setNews] = useState([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    // In a real app, you would fetch this from an API
    const fetchNews = async () => {
      try {
        // Simulate API call
        await new Promise(resolve => setTimeout(resolve, 800));
        setNews(mockNews);
      } catch (error) {
        console.error('Error fetching news:', error);
      } finally {
        setIsLoading(false);
      }
    };

    fetchNews();
  }, []);

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-blue-500"></div>
      </div>
    );
  }

  return (
    <div className="p-6">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-2xl font-bold text-gray-900">Top 10 News</h1>
        <div className="flex items-center text-sm text-gray-400">
          <span>Powered by AI</span>
          <span className="mx-2">•</span>
          <span>Updated just now</span>
          <FiClock className="ml-2" size={14} />
        </div>
      </div>

      <div className="mb-8 p-6 bg-gray-800 rounded-xl">
        <p className="text-gray-300 mb-4">
          Stay informed with the latest financial news and market updates. Our AI-powered news aggregator brings you the most relevant stories from trusted sources around the world.
        </p>
        <a href="#" className="text-blue-400 hover:text-blue-300 flex items-center text-sm">
          Read more <FiArrowUpRight className="ml-1" size={14} />
        </a>
      </div>

      <div className="space-y-4">
        {news.map((item) => (
          <motion.div
            key={item.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.3, delay: item.id * 0.05 }}
            className="bg-gray-800 rounded-xl p-5 hover:bg-gray-750 transition-colors duration-200 cursor-pointer"
          >
            <div className="flex justify-between items-start">
              <div className="flex items-center">
                <div className={`${item.iconColor} w-8 h-8 rounded-full flex items-center justify-center text-white font-bold mr-3`}>
                  {item.icon}
                </div>
                <span className="text-white font-medium">{item.source}</span>
              </div>
              <span className="text-gray-400 text-sm">{item.time}</span>
            </div>
            <h3 className="text-white text-lg font-semibold mt-3 mb-2">{item.title}</h3>
            <p className="text-gray-400 text-sm mb-3">{item.summary}</p>
            <div className="flex justify-between items-center mt-4">
              <div className="flex items-center text-blue-400 text-sm">
                Read full article
                <FiExternalLink className="ml-1" size={14} />
              </div>
              <div className="flex space-x-2">
                <button className="p-1.5 rounded-full bg-gray-700 text-gray-300 hover:bg-gray-600">
                  <FiBookOpen size={16} />
                </button>
              </div>
            </div>
          </motion.div>
        ))}
      </div>
    </div>
  );
}
