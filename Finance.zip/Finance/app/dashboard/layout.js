'use client';

import { useState, useEffect } from 'react';
import { usePathname } from 'next/navigation';
import Link from 'next/link';
import { useTheme } from 'next-themes';
import { navigation } from "../utils/helper";
import {
  Menu,
  X,
  User,
} from 'lucide-react';
// import { ThemeToggle } from '@/components/ThemeToggle';

// Register Chart.js components
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  ArcElement,
  Title,
  Tooltip,
  Legend
} from 'chart.js';

ChartJS.register(
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  ArcElement,
  Title,
  Tooltip,
  Legend
);

export default function DashboardLayout({ children }) {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const pathname = usePathname();

  const isActive = (href) => pathname === href;

  const { theme } = useTheme();
  const [mounted, setMounted] = useState(false);

  // Ensure component is mounted before rendering to avoid hydration mismatch
  useEffect(() => {
    setMounted(true);
  }, []);

  if (!mounted) {
    return null; // or a loading spinner
  }

  return (
    <div className={`min-h-screen ${theme === 'dark' ? 'dark' : ''}`}>
      <div className="min-h-screen bg-white bg-gray-900 transition-colors duration-200">
        {/* Mobile sidebar */}
        <div className={`fixed inset-0 z-40 lg:hidden ${sidebarOpen ? 'block' : 'hidden'}`}>
          <div
            className="fixed inset-0 bg-gray-600 bg-opacity-75"
            onClick={() => setSidebarOpen(false)}
            aria-hidden="true"
          />
          <div className="fixed inset-y-0 left-0 flex w-64 flex-col bg-white bg-gray-800">
            <div className="flex h-16 flex-shrink-0 items-center justify-between px-4 bg-indigo-600">
              <h1 className="text-xl font-bold text-white">Finance Tracker</h1>
              <button
                type="button"
                className="text-white hover:text-gray-200"
                onClick={() => setSidebarOpen(false)}
              >
                <X className="h-6 w-6" />
              </button>
            </div>
            <nav className="flex-1 overflow-y-auto py-4">
              <div className="space-y-1 px-2">
                {navigation.map((item, index) => {
                  if (item.type === 'divider') {
                    return <div key={`divider-${index}`} className="border-t border-gray-200 my-2" />;
                  }
                  return (
                    <Link
                      key={item.name}
                      href={item.href}
                      className={`group flex items-center px-2 py-2 text-sm font-medium rounded-md ${isActive(item.href)
                        ? 'bg-indigo-50 text-indigo-700'
                        : 'text-gray-600 hover:bg-gray-50 hover:text-gray-900'
                        }`}
                    >
                      <item.icon
                        className={`mr-3 h-6 w-6 flex-shrink-0 ${isActive(item.href) ? 'text-indigo-500' : 'text-gray-400 group-hover:text-gray-500'
                          }`}
                        aria-hidden="true"
                      />
                      {item.name}
                    </Link>
                  );
                })}
              </div>
            </nav>
          </div>
        </div>

        {/* Static sidebar for desktop */}
        <div className="hidden lg:fixed lg:inset-y-0 lg:flex lg:w-64 lg:flex-col">
          <div className="flex min-h-0 flex-1 flex-col border-r border-gray-200 border-gray-700 bg-white bg-gray-800">
            <div className="flex flex-col h-full">
              <div className="flex-1 overflow-y-auto pt-5 pb-4">
                <div className="flex flex-shrink-0 items-center px-4">
                  <h1 className="text-xl font-bold text-indigo-600 text-indigo-400">Finance Tracker</h1>
                </div>
                <nav className="mt-5 space-y-1 px-2">
                  {navigation.slice(0, navigation.findIndex(item => item.type === 'divider')).map((item) => (
                    <Link
                      key={item.name}
                      href={item.href}
                      className={`group flex items-center px-2 py-2 text-sm font-medium rounded-md ${isActive(item.href)
                        ? 'bg-indigo-50 text-indigo-700'
                        : 'text-gray-600 hover:bg-gray-50 hover:text-gray-900'
                        }`}
                    >
                      <item.icon
                        className={`mr-3 h-6 w-6 flex-shrink-0 ${isActive(item.href) ? 'text-indigo-500' : 'text-gray-400 group-hover:text-gray-500'
                          }`}
                        aria-hidden="true"
                      />
                      {item.name}
                    </Link>
                  ))}
                </nav>
              </div>
              <div className="flex-shrink-0 border-t border-gray-200 border-gray-700 p-4">
                <nav className="space-y-1">
                  {navigation.slice(navigation.findIndex(item => item.type === 'divider') + 1).map((item) => (
                    <Link
                      key={item.name}
                      href={item.href}
                      className={`group flex items-center px-2 py-2 text-sm font-medium rounded-md ${isActive(item.href)
                        ? 'bg-indigo-50 bg-indigo-900/30 text-indigo-700 text-indigo-200'
                        : 'text-gray-600 text-gray-300 hover:bg-gray-50 hover:bg-gray-700 hover:text-gray-900 hover:text-white'
                        }`}
                    >
                      <item.icon
                        className={`mr-3 h-6 w-6 flex-shrink-0 ${isActive(item.href)
                          ? 'text-indigo-500 text-indigo-400'
                          : 'text-gray-400 group-hover:text-gray-500 group-hover:text-gray-300'
                          }`}
                        aria-hidden="true"
                      />
                      {item.name}
                    </Link>
                  ))}
                </nav>
              </div>
            </div>
          </div>
        </div>

        {/* Main content */}
        <div className="lg:pl-64 flex flex-col min-h-screen">
          {/* Header */}
          <header className="sticky top-0 z-10 bg-white bg-gray-800 border-b border-gray-200 border-gray-700">
            <div className="flex items-center justify-between px-6 h-16">
              <div className="flex items-center flex-1 max-w-3xl">
                <button
                  type="button"
                  className="mr-3 inline-flex items-center rounded-md p-2 text-gray-500 hover:bg-gray-100 hover:text-gray-700 focus:outline-none focus:ring-2 focus:ring-inset focus:ring-indigo-500 lg:hidden"
                  onClick={() => setSidebarOpen(true)}
                >
                  <span className="sr-only">Open sidebar</span>
                  <Menu className="h-6 w-6" />
                </button>

                {/* Search Bar */}
                <div className="relative w-full max-w-md">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                    <svg className="h-5 w-5 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
                    </svg>
                  </div>
                  <input
                    type="text"
                    placeholder="Search transactions..."
                    className="block w-full pl-10 pr-3 py-2 border border-gray-300 border-gray-600 rounded-md leading-5 bg-white bg-gray-700 text-gray-900 text-white placeholder-gray-500 placeholder-gray-400 focus:outline-none focus:ring-1 focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
                  />
                </div>
              </div>

              <div className="flex items-center space-x-4">
                {/* <ThemeToggle /> */}
                {/* Profile dropdown */}
                <div className="h-8 w-8 rounded-full bg-indigo-100 bg-indigo-900 flex items-center justify-center text-indigo-600 text-indigo-200">
                  <User className="h-5 w-5" />
                </div>
              </div>
            </div>
          </header>

          {/* Page content */}
          <main className="flex-1 bg-gray-50">
            <div className="py-2">
              <div className="mx-auto px-2 sm:px-6 md:px-8">
                {children}
              </div>
            </div>
          </main>
        </div>
      </div>
    </div>
  );
}
