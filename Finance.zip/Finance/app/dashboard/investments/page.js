'use client';

import { ArrowUpRight, ArrowDownRight, Plus, TrendingUp, PieChart, BarChart2 } from 'lucide-react';
import Link from 'next/link';

export default function InvestmentsPage() {
  // Sample data - replace with actual data from your API
  const portfolio = {
    totalValue: 12500,
    totalReturn: 1250,
    returnPercentage: 11.2,
    isPositive: true,
    allocation: [
      { name: 'Stocks', value: 7500, percentage: 60, color: 'bg-blue-500' },
      { name: 'Bonds', value: 3000, percentage: 24, color: 'bg-green-500' },
      { name: 'Crypto', value: 1200, percentage: 9.6, color: 'bg-yellow-500' },
      { name: 'Others', value: 800, percentage: 6.4, color: 'bg-gray-400' },
    ],
    recentTransactions: [
      { id: 1, name: 'Apple Inc.', type: 'Stocks', amount: 2500, date: '2023-06-15', isBuy: true },
      { id: 2, name: 'US Treasury Bond', type: 'Bonds', amount: 1000, date: '2023-06-10', isBuy: true },
      { id: 3, name: 'Bitcoin', type: 'Crypto', amount: 500, date: '2023-06-05', isBuy: true },
      { id: 4, name: 'Tesla Inc.', type: 'Stocks', amount: 1500, date: '2023-05-28', isBuy: true },
    ]
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Investments</h1>
          <p className="mt-1 text-sm text-gray-500">Track and manage your investment portfolio</p>
        </div>
        <div className="mt-4 md:mt-0">
          <Link 
            href="/investments/add"
            className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
          >
            <Plus className="-ml-1 mr-2 h-5 w-5" />
            Add Investment
          </Link>
        </div>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-3">
        {/* Total Portfolio Value */}
        <div className="bg-white overflow-hidden shadow rounded-lg">
          <div className="p-5">
            <div className="flex items-center">
              <div className="flex-shrink-0 bg-indigo-500 rounded-md p-3">
                <TrendingUp className="h-6 w-6 text-white" />
              </div>
              <div className="ml-5 w-0 flex-1">
                <dl>
                  <dt className="text-sm font-medium text-gray-500 truncate">
                    Total Portfolio Value
                  </dt>
                  <dd className="flex items-baseline">
                    <div className="text-2xl font-semibold text-gray-900">
                      ${portfolio.totalValue.toLocaleString()}
                    </div>
                  </dd>
                </dl>
              </div>
            </div>
          </div>
        </div>

        {/* Total Return */}
        <div className="bg-white overflow-hidden shadow rounded-lg">
          <div className="p-5">
            <div className="flex items-center">
              <div className="flex-shrink-0 bg-green-500 rounded-md p-3">
                <BarChart2 className="h-6 w-6 text-white" />
              </div>
              <div className="ml-5 w-0 flex-1">
                <dl>
                  <dt className="text-sm font-medium text-gray-500 truncate">
                    Total Return
                  </dt>
                  <dd className="flex items-baseline">
                    <div className="text-2xl font-semibold text-gray-900">
                      ${portfolio.totalReturn.toLocaleString()}
                    </div>
                    <div className={`ml-2 flex items-baseline text-sm font-semibold ${portfolio.isPositive ? 'text-green-600' : 'text-red-600'}`}>
                      {portfolio.isPositive ? (
                        <ArrowUpRight className="self-center flex-shrink-0 h-4 w-4 text-green-500" />
                      ) : (
                        <ArrowDownRight className="self-center flex-shrink-0 h-4 w-4 text-red-500" />
                      )}
                      <span className="sr-only">
                        {portfolio.isPositive ? 'Increased' : 'Decreased'} by
                      </span>
                      {portfolio.returnPercentage}%
                    </div>
                  </dd>
                </dl>
              </div>
            </div>
          </div>
        </div>

        {/* Asset Allocation */}
        <div className="bg-white overflow-hidden shadow rounded-lg">
          <div className="p-5">
            <div className="flex items-center">
              <div className="flex-shrink-0 bg-purple-500 rounded-md p-3">
                <PieChart className="h-6 w-6 text-white" />
              </div>
              <div className="ml-5 w-0 flex-1">
                <dl>
                  <dt className="text-sm font-medium text-gray-500 truncate">
                    Asset Allocation
                  </dt>
                  <dd className="text-sm text-gray-900">
                    {portfolio.allocation.length} categories
                  </dd>
                </dl>
              </div>
            </div>
            <div className="mt-4">
              <div className="flex h-2 rounded-full bg-gray-200 overflow-hidden">
                {portfolio.allocation.map((asset, index) => (
                  <div 
                    key={index}
                    className={asset.color}
                    style={{ width: `${asset.percentage}%` }}
                    title={`${asset.name}: ${asset.percentage}%`}
                  />
                ))}
              </div>
              <div className="mt-2 grid grid-cols-4 gap-2 text-xs">
                {portfolio.allocation.map((asset, index) => (
                  <div key={index} className="flex items-center">
                    <span 
                      className={`w-2 h-2 rounded-full ${asset.color} mr-1`} 
                      aria-hidden="true"
                    />
                    <span className="truncate">{asset.name}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Recent Transactions */}
      <div className="bg-white shadow overflow-hidden sm:rounded-lg">
        <div className="px-4 py-5 sm:px-6 border-b border-gray-200">
          <h3 className="text-lg font-medium leading-6 text-gray-900">Recent Transactions</h3>
          <p className="mt-1 text-sm text-gray-500">A list of your recent investment transactions.</p>
        </div>
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
              <tr>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Investment
                </th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Type
                </th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Amount
                </th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Date
                </th>
                <th scope="col" className="relative px-6 py-3">
                  <span className="sr-only">Actions</span>
                </th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {portfolio.recentTransactions.map((transaction) => (
                <tr key={transaction.id} className="hover:bg-gray-50">
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="text-sm font-medium text-gray-900">{transaction.name}</div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <span className="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-blue-100 text-blue-800">
                      {transaction.type}
                    </span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className={`text-sm ${transaction.isBuy ? 'text-green-600' : 'text-red-600'}`}>
                      {transaction.isBuy ? '+' : '-'}${transaction.amount.toLocaleString()}
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    {new Date(transaction.date).toLocaleDateString()}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                    <a href="#" className="text-indigo-600 hover:text-indigo-900">View</a>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <div className="px-4 py-4 sm:px-6 border-t border-gray-200">
          <div className="flex justify-end">
            <a href="#" className="text-sm font-medium text-indigo-600 hover:text-indigo-500">
              View all transactions
            </a>
          </div>
        </div>
      </div>
    </div>
  );
}
