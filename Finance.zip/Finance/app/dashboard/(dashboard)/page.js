'use client';

import { useState } from 'react';
import { Line, Bar, Doughnut } from 'react-chartjs-2';
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  BarElement,
  ArcElement,
  Title,
  Tooltip,
  Legend,
} from 'chart.js';
import {
  Home,
  CreditCard,
  BarChart2 as ChartBarIcon,
  Wallet,
  Calendar,
  Target,
  TrendingUp,
  Lightbulb,
  UserCircle,
  ArrowUp as ArrowUpIcon,
  ArrowDown as ArrowDownIcon,
  DollarSign as CurrencyDollarIcon,
  Clock as ClockIcon,
  Plus as PlusIcon,
  X as XMarkIcon,
  Menu as Bars3Icon,
  Search as SearchIcon,
  Bell as BellIcon,
  ChevronDown as ChevronDownIcon,
  Settings as SettingsIcon,
  LogOut as LogOutIcon,
  TrendingUp as TrendingUpIcon,
  TrendingDown as TrendingDownIcon,
  ArrowRight as ArrowRightIcon,
  ShoppingCart,
  Utensils,
  Home as HomeIcon,
  Tv2,
  Bus,
  HeartPulse,
  Gift,
  GraduationCap,
  PiggyBank,
  Landmark,
  Plane,
  FileText,
  Mail,
  Printer,
  Copy as CopyIcon,
  Sliders as SlidersIcon,
  Tag as TagIcon,
  PieChart as PieChartIcon,
  LineChart as LineChartIcon
} from 'lucide-react';
import { format, subDays, parseISO } from 'date-fns';

// Register ChartJS components
ChartJS.register(
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  BarElement,
  ArcElement,
  Title,
  Tooltip,
  Legend
);

export default function DashboardPage() {
  const [timeRange, setTimeRange] = useState('1M');
  const [sortBy, setSortBy] = useState('recent');
  const [showFilters, setShowFilters] = useState(false);

  // Sample data for charts
  const spendingData = {
    labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'],
    datasets: [
      {
        label: 'Income',
        data: [3000, 3200, 3500, 3800, 4000, 4200],
        borderColor: 'rgb(16, 185, 129)',
        backgroundColor: 'rgba(16, 185, 129, 0.1)',
        tension: 0.4,
        fill: true,
      },
      {
        label: 'Expenses',
        data: [2800, 3000, 3200, 2900, 3500, 3800],
        borderColor: 'rgb(239, 68, 68)',
        backgroundColor: 'rgba(239, 68, 68, 0.1)',
        tension: 0.4,
        fill: true,
      },
    ],
  };

  const budgetData = {
    labels: ['Housing', 'Food', 'Transport', 'Entertainment', 'Utilities', 'Others'],
    datasets: [
      {
        data: [1200, 800, 400, 300, 250, 350],
        backgroundColor: [
          'rgba(99, 102, 241, 0.8)',
          'rgba(16, 185, 129, 0.8)',
          'rgba(245, 158, 11, 0.8)',
          'rgba(236, 72, 153, 0.8)',
          'rgba(14, 165, 233, 0.8)',
          'rgba(139, 92, 246, 0.8)',
        ],
        borderWidth: 1,
      },
    ],
  };

  const netWorthData = {
    labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'],
    datasets: [
      {
        label: 'Net Worth',
        data: [25000, 26500, 27200, 29000, 31000, 33500],
        borderColor: 'rgb(99, 102, 241)',
        backgroundColor: 'rgba(99, 102, 241, 0.1)',
        tension: 0.4,
        fill: true,
      },
    ],
  };

  const recentTransactions = [
    {
      id: 1,
      name: 'Grocery Store',
      category: 'Food',
      amount: 156.78,
      date: '2023-05-15',
      type: 'expense',
    },
    {
      id: 2,
      name: 'Salary',
      category: 'Income',
      amount: 3500.0,
      date: '2023-05-01',
      type: 'income',
    },
    {
      id: 3,
      name: 'Electric Bill',
      category: 'Utilities',
      amount: 125.5,
      date: '2023-05-10',
      type: 'expense',
    },
    {
      id: 4,
      name: 'Gas Station',
      category: 'Transport',
      amount: 45.25,
      date: '2023-05-12',
      type: 'expense',
    },
  ];

  const upcomingBills = [
    { id: 1, name: 'Rent', amount: 1200, dueDate: '2023-06-01', category: 'Housing' },
    { id: 2, name: 'Internet', amount: 79.99, dueDate: '2023-06-05', category: 'Utilities' },
    { id: 3, name: 'Phone Bill', amount: 45.0, dueDate: '2023-06-10', category: 'Utilities' },
  ];

  const spendingByCategory = [
    { name: 'Housing', amount: 1200, percentage: 40, color: 'bg-indigo-500' },
    { name: 'Food', amount: 800, percentage: 26.7, color: 'bg-emerald-500' },
    { name: 'Transport', amount: 400, percentage: 13.3, color: 'bg-amber-500' },
    { name: 'Entertainment', amount: 300, percentage: 10, color: 'bg-pink-500' },
    { name: 'Utilities', amount: 250, percentage: 8.3, color: 'bg-sky-500' },
    { name: 'Others', amount: 150, percentage: 5, color: 'bg-purple-500' },
  ];

  const recurringPayments = [
    { id: 1, name: 'Netflix', amount: 15.99, frequency: 'Monthly', nextDate: '2023-06-01' },
    { id: 2, name: 'Gym Membership', amount: 29.99, frequency: 'Monthly', nextDate: '2023-06-05' },
    { id: 3, name: 'Spotify', amount: 9.99, frequency: 'Monthly', nextDate: '2023-06-10' },
  ];

  const savingsGoals = [
    { id: 1, name: 'Emergency Fund', target: 10000, current: 6500, deadline: '2023-12-31' },
    { id: 2, name: 'New Laptop', target: 2000, current: 1200, deadline: '2023-08-31' },
    { id: 3, name: 'Vacation', target: 3000, current: 1800, deadline: '2023-11-30' },
  ];

  const chartOptions = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: {
        position: 'top',
      },
    },
    scales: {
      y: {
        beginAtZero: true,
      },
    },
  };

  const formatCurrency = (amount) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
    }).format(amount);
  };

  const formatDate = (dateString) => {
    return format(parseISO(dateString), 'MMM d, yyyy');
  };

  const totalBalance = 12500.5;
  const totalIncome = 3500;
  const totalExpenses = 1567.89;
  const savingsRate = ((totalIncome - totalExpenses) / totalIncome) * 100;

  return (
    <div className="space-y-4 py-2">
      {/* Summary Cards */}
      <div className="grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-4">
        {/* Total Balance */}
        <div className="bg-white overflow-hidden shadow rounded-lg">
          <div className="p-5">
            <div className="flex items-center">
              <div className="flex-shrink-0 bg-indigo-100 rounded-md p-3">
                <CurrencyDollarIcon className="h-6 w-6 text-indigo-600" />
              </div>
              <div className="ml-4">
                <p className="text-sm font-medium text-gray-500 truncate">Total Balance</p>
                <p className="text-2xl font-semibold text-gray-900">{formatCurrency(totalBalance)}</p>
              </div>
            </div>
          </div>
        </div>

        {/* Total Income */}
        <div className="bg-white overflow-hidden shadow rounded-lg">
          <div className="p-5">
            <div className="flex items-center">
              <div className="flex-shrink-0 bg-green-100 rounded-md p-3">
                <ArrowUpIcon className="h-6 w-6 text-green-600" />
              </div>
              <div className="ml-4">
                <p className="text-sm font-medium text-gray-500 truncate">Income</p>
                <p className="text-2xl font-semibold text-gray-900">{formatCurrency(totalIncome)}</p>
              </div>
            </div>
          </div>
        </div>

        {/* Total Expenses */}
        <div className="bg-white overflow-hidden shadow rounded-lg">
          <div className="p-5">
            <div className="flex items-center">
              <div className="flex-shrink-0 bg-red-100 rounded-md p-3">
                <ArrowDownIcon className="h-6 w-6 text-red-600" />
              </div>
              <div className="ml-4">
                <p className="text-sm font-medium text-gray-500 truncate">Expenses</p>
                <p className="text-2xl font-semibold text-gray-900">{formatCurrency(totalExpenses)}</p>
              </div>
            </div>
          </div>
        </div>

        {/* Savings Rate */}
        <div className="bg-white overflow-hidden shadow rounded-lg">
          <div className="p-5">
            <div className="flex items-center">
              <div className="flex-shrink-0 bg-blue-100 rounded-md p-3">
                <PiggyBank className="h-6 w-6 text-blue-600" />
              </div>
              <div className="ml-4">
                <p className="text-sm font-medium text-gray-500 truncate">Savings Rate</p>
                <p className="text-2xl font-semibold text-gray-900">{savingsRate.toFixed(1)}%</p>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Charts Row 1 */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Spending Chart */}
        <div className="bg-white p-6 rounded-lg shadow">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-lg font-medium text-gray-900">Spending Overview</h2>
            <div className="flex space-x-2">
              <button 
                className={`px-3 py-1 text-sm rounded-md ${timeRange === '1M' ? 'bg-indigo-100 text-indigo-700' : 'text-gray-500'}`}
                onClick={() => setTimeRange('1M')}
              >
                1M
              </button>
              <button 
                className={`px-3 py-1 text-sm rounded-md ${timeRange === '3M' ? 'bg-indigo-100 text-indigo-700' : 'text-gray-500'}`}
                onClick={() => setTimeRange('3M')}
              >
                3M
              </button>
              <button 
                className={`px-3 py-1 text-sm rounded-md ${timeRange === '6M' ? 'bg-indigo-100 text-indigo-700' : 'text-gray-500'}`}
                onClick={() => setTimeRange('6M')}
              >
                6M
              </button>
            </div>
          </div>
          <div className="h-64">
            <Line data={spendingData} options={chartOptions} />
          </div>
        </div>

        {/* Budget Chart */}
        <div className="bg-white p-6 rounded-lg shadow">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-lg font-medium text-gray-900">Budget Breakdown</h2>
            <button className="text-sm font-medium text-indigo-600 hover:text-indigo-500">
              View Details
            </button>
          </div>
          <div className="h-64 flex items-center justify-center">
            <Doughnut 
              data={budgetData} 
              options={{
                ...chartOptions,
                plugins: {
                  ...chartOptions.plugins,
                  legend: {
                    position: 'right',
                  },
                },
              }} 
            />
          </div>
        </div>
      </div>

      {/* Charts Row 2 */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Net Worth Chart */}
        <div className="lg:col-span-2 bg-white p-6 rounded-lg shadow">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-lg font-medium text-gray-900">Net Worth</h2>
            <div className="flex space-x-2">
              <button 
                className={`px-3 py-1 text-sm rounded-md ${timeRange === '1Y' ? 'bg-indigo-100 text-indigo-700' : 'text-gray-500'}`}
                onClick={() => setTimeRange('1Y')}
              >
                1Y
              </button>
              <button 
                className={`px-3 py-1 text-sm rounded-md ${timeRange === 'ALL' ? 'bg-indigo-100 text-indigo-700' : 'text-gray-500'}`}
                onClick={() => setTimeRange('ALL')}
              >
                All Time
              </button>
            </div>
          </div>
          <div className="h-64">
            <Line data={netWorthData} options={chartOptions} />
          </div>
        </div>

        {/* Recent Transactions */}
        <div className="bg-white p-6 rounded-lg shadow">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-lg font-medium text-gray-900">Recent Transactions</h2>
            <button className="text-sm font-medium text-indigo-600 hover:text-indigo-500">
              View All
            </button>
          </div>
          <div className="space-y-4">
            {recentTransactions.map((transaction) => (
              <div key={transaction.id} className="flex items-center justify-between">
                <div className="flex items-center">
                  <div className={`p-2 rounded-full ${
                    transaction.type === 'income' ? 'bg-green-100' : 'bg-red-100'
                  }`}>
                    {transaction.type === 'income' ? (
                      <ArrowUpIcon className="h-4 w-4 text-green-600" />
                    ) : (
                      <ArrowDownIcon className="h-4 w-4 text-red-600" />
                    )}
                  </div>
                  <div className="ml-3">
                    <p className="text-sm font-medium text-gray-900">{transaction.name}</p>
                    <p className="text-xs text-gray-500">
                      {transaction.category} • {formatDate(transaction.date)}
                    </p>
                  </div>
                </div>
                <p className={`text-sm font-medium ${
                  transaction.type === 'income' ? 'text-green-600' : 'text-red-600'
                }`}>
                  {transaction.type === 'income' ? '+' : '-'}{formatCurrency(transaction.amount)}
                </p>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Charts Row 3 */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Upcoming Bills */}
        <div className="bg-white p-6 rounded-lg shadow">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-lg font-medium text-gray-900">Upcoming Bills</h2>
            <button className="text-sm font-medium text-indigo-600 hover:text-indigo-500">
              View All
            </button>
          </div>
          <div className="space-y-4">
            {upcomingBills.map((bill) => (
              <div key={bill.id} className="flex items-center justify-between">
                <div className="flex items-center">
                  <div className="p-2 rounded-full bg-blue-100">
                    <Calendar className="h-4 w-4 text-blue-600" />
                  </div>
                  <div className="ml-3">
                    <p className="text-sm font-medium text-gray-900">{bill.name}</p>
                    <p className="text-xs text-gray-500">Due {formatDate(bill.dueDate)}</p>
                  </div>
                </div>
                <p className="text-sm font-medium text-gray-900">{formatCurrency(bill.amount)}</p>
              </div>
            ))}
          </div>
        </div>

        {/* Savings Goals */}
        <div className="bg-white p-6 rounded-lg shadow">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-lg font-medium text-gray-900">Savings Goals</h2>
            <button className="text-sm font-medium text-indigo-600 hover:text-indigo-500">
              View All
            </button>
          </div>
          <div className="space-y-4">
            {savingsGoals.map((goal) => {
              const progress = (goal.current / goal.target) * 100;
              return (
                <div key={goal.id} className="space-y-1">
                  <div className="flex justify-between text-sm">
                    <span className="font-medium text-gray-900">{goal.name}</span>
                    <span className="text-gray-500">
                      {formatCurrency(goal.current)} / {formatCurrency(goal.target)}
                    </span>
                  </div>
                  <div className="w-full bg-gray-200 rounded-full h-2">
                    <div 
                      className="bg-green-500 h-2 rounded-full" 
                      style={{ width: `${Math.min(progress, 100)}%` }}
                    />
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
}
