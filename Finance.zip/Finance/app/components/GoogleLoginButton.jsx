'use client';

import { useRouter } from 'next/navigation';
import { FcGoogle } from 'react-icons/fc';

export default function GoogleLoginButton() {
  const router = useRouter();

  const handleGoogleLogin = () => {
    router.push('/api/auth/google');
  };

  return (
    <button
      onClick={handleGoogleLogin}
      className="w-full flex items-center justify-center gap-2 bg-white text-gray-700 py-2 px-4 rounded-md border border-gray-300 hover:bg-gray-50 transition-colors"
    >
      <FcGoogle className="text-xl" />
      Continue with Google
    </button>
  );
}
