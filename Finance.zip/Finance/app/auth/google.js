import { OAuth2Client } from 'google-auth-library';

// Initialize the OAuth2 client
export const oauth2Client = new OAuth2Client(
  process.env.GOOGLE_CLIENT_ID,
  process.env.GOOGLE_CLIENT_SECRET,
  `${process.env.NEXT_PUBLIC_APP_URL}/api/auth/google/callback`
);

export const getGoogleAuthURL = () => {
  const scopes = [
    'https://www.googleapis.com/auth/userinfo.profile',
    'https://www.googleapis.com/auth/userinfo.email',
  ];

  return oauth2Client.generateAuthUrl({
    access_type: 'offline',
    prompt: 'consent',
    scope: scopes,
  });
};

export const getGoogleUser = async (code) => {
  const { tokens } = await oauth2Client.getToken(code);
  oauth2Client.setCredentials(tokens);
  
  const userinfo = await oauth2Client.request({
    url: 'https://www.googleapis.com/oauth2/v3/userinfo',
  });

  return {
    id: userinfo.data.sub,
    email: userinfo.data.email,
    displayName: userinfo.data.name,
    photo: userinfo.data.picture,
  };
};


