'use client';
import React, { useState } from 'react';
import Sidebar from '@/components/Sidebar';
import Header from '@/components/Header';
import DocumentList from '@/components/documents/DocumentList';
import DocumentSummary from '@/components/documents/DocumentSummary';

export default function DocumentsPage() {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [activeFilter, setActiveFilter] = useState('All');

  const filters = ['All', 'Active', 'Expired', 'Archived'];

  // Function to handle file upload
  const handleFileUpload = (e) => {
    const file = e.target.files[0];
    if (file) {
      // Here you would typically handle the file upload to your server
      console.log('Uploading file:', file.name);
      // Reset the file input
      e.target.value = null;
    }
  };

  return (
    <div className="flex h-screen bg-gray-50">
      {/* Sidebar */}
      <Sidebar isOpen={sidebarOpen} onClose={() => setSidebarOpen(false)} />

      {/* Main Content */}
      <div className="flex-1 flex flex-col overflow-hidden">
        {/* Header */}
        <Header onMenuClick={() => setSidebarOpen(true)} />

        {/* Main Content */}
        <main className="flex-1 overflow-x-hidden overflow-y-auto bg-gray-50 p-4 md:p-6">
          <div className="max-w-7xl mx-auto">
            {/* Page Title and Actions */}
            <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-6">
              <div>
                <h1 className="text-2xl font-bold text-gray-900">Documents</h1>
                <p className="text-sm text-gray-500">Manage your important files and documents</p>
              </div>
              <div className="mt-4 md:mt-0">
                <label className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-md text-sm font-medium cursor-pointer">
                  <span>Upload Document</span>
                  <input 
                    type="file" 
                    className="hidden" 
                    onChange={handleFileUpload}
                    accept=".pdf,.doc,.docx,.jpg,.jpeg,.png"
                  />
                </label>
              </div>
            </div>

            {/* Summary Cards */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
              <DocumentSummary 
                title="Total Documents" 
                count="24" 
                icon="document"
                trend="up"
                trendPercentage="12%"
              />
              <DocumentSummary 
                title="Active" 
                count="18" 
                icon="document"
                subTitle="2 expiring soon"
              />
              <DocumentSummary 
                title="Expired" 
                count="3" 
                icon="clock"
                trend="down"
                trendPercentage="5%"
              />
              <DocumentSummary 
                title="Storage Used" 
                count="124.5 MB" 
                icon="server"
                subTitle="of 5 GB used"
              />
            </div>

            {/* Filter Tabs and Document List */}
            <div className="bg-white rounded-lg shadow overflow-hidden">
              {/* Filter Tabs */}
              <div className="border-b border-gray-200">
                <nav className="flex -mb-px overflow-x-auto">
                  {filters.map((filter) => (
                    <button
                      key={filter}
                      onClick={() => setActiveFilter(filter)}
                      className={`whitespace-nowrap py-4 px-6 border-b-2 font-medium text-sm ${
                        activeFilter === filter
                          ? 'border-blue-500 text-blue-600'
                          : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                      }`}
                    >
                      {filter}
                    </button>
                  ))}
                </nav>
              </div>

              {/* Document List */}
              <DocumentList />
            </div>
          </div>
        </main>
      </div>
    </div>
  );
}
