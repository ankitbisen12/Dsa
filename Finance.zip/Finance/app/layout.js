import './globals.css';
// import { ThemeProvider } from '@/components/ThemeProvider';
import { openSans } from '../app/ui/fonts';
import connectDB from "../lib/db";

export const metadata = {
  title: 'Finance Tracker',
  description: 'Manage your personal finances',
};

export default async function RootLayout({ children }) {
  await connectDB();
  return (
    <html lang="en" suppressHydrationWarning>
      <body className={` ${openSans.variable} bg-white bg-gray-900 text-gray-900 text-gray-100 transition-colors duration-200`}>
        {children}
      </body>
    </html>
  );
}
