import {
  Home,
  CreditCard,
  Wallet,
  TrendingUp,
  Target,
  Lightbulb,
  Settings,
  User,
  Newspaper,
} from 'lucide-react';

import {FiHome, FiDollarSign, FiPieChart, FiPocket, FiTrendingUp, FiZap, FiBookOpen } from 'react-icons/fi';

//navigation array of ele as object.
export const navigation = [
  { name: 'Dashboard', href: '/dashboard', icon: Home },
  { name: 'Transactions', href: '/dashboard/transactions', icon: CreditCard },
  { name: 'Savings', href: '/dashboard/savings', icon: Wallet },
  { name: 'Investments', href: '/dashboard/investments', icon: TrendingUp },
  { name: 'Budgets', href: '/dashboard/budgets', icon: Target },
  { name: 'Finance AI', href: '/dashboard/finance-ai', icon: Lightbulb },
  { name: 'News', href: '/dashboard/news', icon: Newspaper },
  { type: 'divider' },
  { name: 'Profile', href: '/dashboard/profile', icon: User },
  { name: 'Settings', href: '/dashboard/settings', icon: Settings },
];

export const navNavigation = [
  { name: 'Dashboard', href: '/dashboard', icon: <FiHome className="mr-2" /> },
  { name: 'Transactions', href: '/dashboard/transactions', icon: <FiDollarSign className="mr-2" /> },
  { name: 'Savings', href: '/dashboard/savings', icon: <FiPocket className="mr-2" /> },
  { name: 'Budgets', href: '/dashboard/budgets', icon: <FiPieChart className="mr-2" /> },
  { name: 'Analytics', href: '/dashboard/analytics', icon: <FiTrendingUp className="mr-2" /> },
  { name: 'FinanceAI', href: '/dashboard/finance-ai', icon: <FiZap className="mr-2" /> },
  { name: 'News', href: '/dashboard/news', icon: <FiBookOpen className="mr-2" /> },
];