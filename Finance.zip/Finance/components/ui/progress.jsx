import React from 'react';

export const Progress = ({ 
  value = 0, 
  max = 100, 
  className = '', 
  indicatorClassName = '',
  ...props 
}) => {
  // Ensure value is within bounds
  const progress = Math.min(Math.max(0, value), max);
  const percentage = (progress / max) * 100;

  return (
    <div 
      className={`h-2 w-full bg-gray-200 rounded-full overflow-hidden ${className}`}
      role="progressbar"
      aria-valuenow={progress}
      aria-valuemin={0}
      aria-valuemax={max}
      {...props}
    >
      <div 
        className={`h-full bg-blue-500 transition-all duration-300 ${indicatorClassName}`}
        style={{ width: `${percentage}%` }}
      />
    </div>
  );
};

export default Progress;
