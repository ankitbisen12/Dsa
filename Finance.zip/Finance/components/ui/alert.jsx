import React from 'react';

export const Alert = ({ 
  variant = 'default', 
  className = '', 
  children, 
  ...props 
}) => {
  const baseStyles = 'p-4 rounded-lg border';
  const variantStyles = {
    default: 'bg-background text-foreground border-border',
    destructive: 'bg-destructive/10 text-destructive border-destructive/20',
    success: 'bg-green-50 text-green-800 border-green-200',
    warning: 'bg-yellow-50 text-yellow-800 border-yellow-200',
    info: 'bg-blue-50 text-blue-800 border-blue-200',
  };

  return (
    <div 
      className={`${baseStyles} ${variantStyles[variant]} ${className}`}
      {...props}
    >
      {children}
    </div>
  );
};

export const AlertTitle = ({ 
  className = '', 
  children, 
  ...props 
}) => (
  <h5 
    className={`text-lg font-semibold mb-1 ${className}`} 
    {...props}
  >
    {children}
  </h5>
);

export const AlertDescription = ({ 
  className = '', 
  children, 
  ...props 
}) => (
  <div 
    className={`text-sm ${className}`} 
    {...props}
  >
    {children}
  </div>
);

export default Alert;
