import React from 'react';

export const Card = ({ 
  className = '', 
  children, 
  ...props 
}) => (
  <div 
    className={`bg-white rounded-lg shadow-sm border border-gray-200 overflow-hidden ${className}`}
    {...props}
  >
    {children}
  </div>
);

export const CardHeader = ({ 
  className = '', 
  children, 
  ...props 
}) => (
  <div 
    className={`p-6 pb-2 ${className}`}
    {...props}
  >
    {children}
  </div>
);

export const CardTitle = ({ 
  className = '', 
  children, 
  ...props 
}) => (
  <h3 
    className={`text-xl font-semibold ${className}`}
    {...props}
  >
    {children}
  </h3>
);

export const CardContent = ({ 
  className = '', 
  children, 
  ...props 
}) => (
  <div 
    className={`p-6 pt-0 ${className}`}
    {...props}
  >
    {children}
  </div>
);

export const CardFooter = ({ 
  className = '', 
  children, 
  ...props 
}) => (
  <div 
    className={`p-6 pt-0 ${className}`}
    {...props}
  >
    {children}
  </div>
);

export default Card;
