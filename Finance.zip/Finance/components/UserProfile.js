"use client";

import { useState, useRef } from 'react';
import { useRouter } from 'next/navigation';
import {
  PencilIcon,
  XMarkIcon,
  CameraIcon,
  XMarkIcon as XIcon,
} from '@heroicons/react/24/outline';
import ProfileBtn from "../components/Helper/ProfileBtn";
import { FormField } from "../components/Helper/FormField";
import { formatJoinDate } from "../utils/common";
import { updateProfile, uploadImage } from "../app/api/user";

export default function UserProfile({ user }) {
  const router = useRouter();
  const [isEditing, setIsEditing] = useState(false);
  const [formData, setFormData] = useState({
    name: user?.name || 'NA',
    email: user?.email || 'NA',
    phoneNo: +user?.phoneNo || 0,
    occupation: user?.occupation || 'NA',
    address: user?.address || 'NA',
  });
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [selectedFile, setSelectedFile] = useState(null);
  const [previewUrl, setPreviewUrl] = useState(null);
  const fileInputRef = useRef(null);

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const profileUpdateHandler = async () => {
    await updateProfile(formData);
    setIsEditing(false);
    router.refresh();
  }

  const handleFileChange = (e) => {
    //TODO: Write logic for profile image handle.//done
    const file = e.target.files[0];
    if(!file) return;
    setSelectedFile(e.target.files[0]);
    setPreviewUrl(URL.createObjectURL(file));
  };

  const handleSaveImage = async() => {
    if (!selectedFile) return;
    
    console.log("PreviewUrl",previewUrl);
    const formData = new FormData();
    formData.append("profileImage", selectedFile);
    await uploadImage(formData);
    console.log("Running")
    setIsModalOpen(false);
    setSelectedFile(null);
    setPreviewUrl(null);
    router.refresh();
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Main content */}
      <div className="flex-1 overflow-auto focus:outline-none">
        <div className="relative mx-auto md:px-8 xl:px-0">
          <main className="flex-1">
            <div className="relative mx-auto">
              <div className="px-4 py-6 sm:px-6 lg:px-8">
                {/* Personal Information Section with Profile Picture */}
                <div className="bg-white shadow overflow-hidden sm:rounded-lg">
                  <div className="pt-4">
                    <div className="flex items-center justify-between px-4 mb-6">
                      <div className="flex items-center">
                        <div className="relative group mr-4">
                          <div className="relative">
                            <img
                              className="h-16 w-16 rounded-full object-cover border-4 border-white shadow-sm"
                              src={`${process.env.NEXT_PUBLIC_APP_URL}/api/users/image`}
                              alt="Profile"
                            />
                            <div
                              className="absolute inset-0 flex items-center justify-center bg-black bg-opacity-50 rounded-full opacity-0 group-hover:opacity-100 transition-opacity cursor-pointer"
                              onClick={() => setIsModalOpen(true)}
                            >
                              <CameraIcon className="h-6 w-6 text-white" />
                            </div>
                          </div>
                        </div>
                        <div>
                          <h2 className="text-lg font-medium text-gray-900">Personal Information</h2>
                          <p className="text-sm text-gray-500">Update your personal information.</p>
                        </div>
                      </div>
                      <ProfileBtn
                        buttonText={isEditing ? 'Cancel' : 'Edit'}
                        onButtonClick={() => setIsEditing(!isEditing)}
                        buttonIcon={isEditing ? XMarkIcon : PencilIcon}
                        buttonVariant={isEditing ? 'secondary' : 'primary'}
                      />
                    </div>
                    <div className="border-t border-gray-200 px-4 py-5 sm:px-6">
                      <div className="grid grid-cols-1 gap-y-6 gap-x-4 sm:grid-cols-6">
                        <div className="sm:col-span-3">
                          <FormField
                            label="Full name"
                            name="name"
                            value={formData.name}
                            onChange={handleInputChange}
                            disabled={!isEditing}
                          />
                        </div>
                        <div className="sm:col-span-3">
                          <FormField
                            label="Email address"
                            name="email"
                            type="email"
                            value={formData.email}
                            onChange={handleInputChange}
                            disabled={!isEditing}
                          />
                        </div>
                        <div className="sm:col-span-3">
                          <FormField
                            label="Phone number"
                            name="phoneNo"
                            type="tel"
                            value={formData.phoneNo}
                            onChange={handleInputChange}
                            disabled={!isEditing}
                          />
                        </div>
                        <div className="sm:col-span-3">
                          <FormField
                            label="Occupation"
                            name="occupation"
                            value={formData.occupation}
                            onChange={handleInputChange}
                            disabled={!isEditing}
                          />
                        </div>
                        <div className="sm:col-span-6">
                          <FormField
                            label="Address"
                            name="address"
                            value={formData.address}
                            onChange={handleInputChange}
                            disabled={!isEditing}
                          />
                        </div>
                        <div className="sm:col-span-3">
                          <label htmlFor="joined" className="block text-sm font-medium text-gray-700 mb-1">
                            Joined Since {formatJoinDate(user.createdAt)}
                          </label>
                        </div>
                      </div>
                      {isEditing && (
                        <div className="mt-6 flex justify-end space-x-3">
                          <button
                            type="button"
                            onClick={() => setIsEditing(false)}
                            className="inline-flex items-center px-4 py-2 border border-gray-300 shadow-sm text-sm font-medium rounded-md text-gray-700 bg-white"
                          >
                            Cancel
                          </button>
                          <button
                            type="button"
                            onClick={profileUpdateHandler}
                            className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-indigo-600"
                          >
                            Save changes
                          </button>
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </main>
        </div>
      </div>

      {/* Profile Image Change Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-lg p-6 w-full max-w-md">
            <div className="flex justify-between items-center mb-4">
              <h3 className="text-lg font-medium text-gray-900">Change Profile Picture</h3>
              <button
                onClick={() => {
                  setIsModalOpen(false);
                  setPreviewUrl(null);
                  setSelectedFile(null);
                }}
                className="text-gray-400 hover:text-gray-500"
              >
                <XIcon className="h-6 w-6" />
              </button>
            </div>

            <div className="mt-4 flex flex-col items-center">
              <div className="relative w-32 h-32 rounded-full overflow-hidden border-4 border-gray-200 mb-4">
                <img
                  src={previewUrl || formData.profileImage}
                  alt="Preview"
                  className="w-full h-full object-cover"
                />
              </div>

              <input
                type="file"
                ref={fileInputRef}
                onChange={handleFileChange}
                accept="image/*"
                className="hidden"
              />

              <button
                onClick={() => fileInputRef.current?.click()}
                className="px-4 py-2 bg-indigo-600 text-white rounded-md hover:bg-indigo-700 transition-colors"
              >
                Choose Image
              </button>

              <div className="mt-4 flex space-x-3 w-full">
                <button
                  onClick={() => {
                    setIsModalOpen(false);
                    setPreviewUrl(null);
                    setSelectedFile(null);
                  }}
                  className="flex-1 px-4 py-2 border border-gray-300 rounded-md text-gray-700 hover:bg-gray-50"
                >
                  Cancel
                </button>
                <button
                  onClick={handleSaveImage}
                  disabled={!selectedFile}
                  className={`flex-1 px-4 py-2 rounded-md text-white ${selectedFile ? 'bg-indigo-600 hover:bg-indigo-700' : 'bg-indigo-300 cursor-not-allowed'
                    }`}
                >
                  Save Changes
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
