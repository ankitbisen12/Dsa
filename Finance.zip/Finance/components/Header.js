'use client';
import { useState } from 'react';
import Link from 'next/link';

export default function Header({ onMenuClick }) {
  const [showProfileMenu, setShowProfileMenu] = useState(false);
  const [showTestBanner, setShowTestBanner] = useState(true);

  const navigation = [
    { name: 'Search', icon: '🔍', href: '#' },
    { name: 'Chat', icon: '💬', href: '#' },
    { name: 'Notifications', icon: '🔔', href: '#' },
    { name: 'Help', icon: '❓', href: '#' },
  ];

  return (
    <header className="bg-white shadow-sm">
      <div className="px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Left section - Menu button and logo */}
          <div className="flex items-center">
            <button
              type="button"
              className="lg:hidden p-2 rounded-md text-gray-500 hover:text-gray-600 hover:bg-gray-100 focus:outline-none focus:ring-2 focus:ring-inset focus:ring-blue-500"
              onClick={onMenuClick}
            >
              <span className="sr-only">Open sidebar</span>
              ☰
            </button>
            <div className="hidden lg:block ml-4 text-2xl">🧾</div>
          </div>

          {/* Right section - Navigation icons */}
          <div className="flex items-center">
            <div className="hidden md:flex items-center space-x-1">
              {navigation.map((item) => (
                <Link
                  key={item.name}
                  href={item.href}
                  className="p-2 rounded-full text-gray-500 hover:text-gray-600 hover:bg-gray-100"
                  title={item.name}
                >
                  <span className="sr-only">{item.name}</span>
                  <span className="text-xl">{item.icon}</span>
                </Link>
              ))}
            </div>

            {/* Profile dropdown */}
            <div className="ml-4 relative">
              <button
                type="button"
                className="flex items-center max-w-xs rounded-full bg-white text-sm focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
                onClick={() => setShowProfileMenu(!showProfileMenu)}
              >
                <span className="sr-only">Open user menu</span>
                <div className="h-8 w-8 rounded-full bg-blue-100 flex items-center justify-center text-blue-600 font-medium">
                  U
                </div>
              </button>

              {showProfileMenu && (
                <div className="origin-top-right absolute right-0 mt-2 w-48 rounded-md shadow-lg bg-white ring-1 ring-black ring-opacity-5 focus:outline-none z-10">
                  <div className="py-1">
                    <Link
                      href="/profile"
                      className="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100"
                    >
                      Your Profile
                    </Link>
                    <Link
                      href="/settings"
                      className="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100"
                    >
                      Settings
                    </Link>
                    <button className="block w-full text-left px-4 py-2 text-sm text-gray-700 hover:bg-gray-100">
                      Sign out
                    </button>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Test banner */}
        {showTestBanner && (
          <div className="bg-blue-50 p-3 rounded-md mb-2 flex items-center justify-between">
            <div className="flex items-center">
              <span className="text-blue-500 mr-2">💡</span>
              <p className="text-sm text-blue-800">
                Next, Send Yourself a Test Invoice
              </p>
            </div>
            <div className="flex items-center">
              <div className="w-24 h-1 bg-blue-200 rounded-full mr-2">
                <div className="h-1 bg-blue-500 rounded-full w-1/3"></div>
              </div>
              <button
                onClick={() => setShowTestBanner(false)}
                className="text-blue-500 hover:text-blue-700"
              >
                <span className="text-xl">→</span>
              </button>
            </div>
          </div>
        )}
      </div>
    </header>
  );
}
