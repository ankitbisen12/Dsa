'use client';

import { useEffect, useState } from 'react';
import { useTheme } from 'next-themes';
import { FiSun, FiMoon, FiMonitor } from 'react-icons/fi';

export function ThemeToggle() {
  const [mounted, setMounted] = useState(false);
  const { theme, setTheme } = useTheme();

  // Ensure component is mounted before rendering to avoid hydration mismatch
  useEffect(() => {
    setMounted(true);
  }, []);

  if (!mounted) {
    return (
      <div className="w-10 h-10 rounded-full bg-gray-200 bg-gray-700"></div>
    );
  }

  return (
    <div className="flex items-center space-x-1 p-1 bg-gray-100 bg-gray-800 rounded-full">
      <button
        onClick={() => setTheme('light')}
        className={`p-2 rounded-full ${theme === 'light' ? 'bg-white shadow' : 'text-gray-500 hover:text-gray-700 hover:text-gray-300'}`}
        aria-label="Light mode"
      >
        <FiSun className="w-5 h-5" />
      </button>
      <button
        onClick={() => setTheme('dark')}
        className={`p-2 rounded-full ${theme === 'dark' ? 'bg-gray-700 text-white shadow' : 'text-gray-500 hover:text-gray-700 hover:text-gray-300'}`}
        aria-label="Dark mode"
      >
        <FiMoon className="w-5 h-5" />
      </button>
      <button
        onClick={() => setTheme('system')}
        className={`p-2 rounded-full ${theme === 'system' ? 'bg-gray-200 bg-gray-700 shadow' : 'text-gray-500 hover:text-gray-700 hover:text-gray-300'}`}
        aria-label="System preference"
      >
        <FiMonitor className="w-5 h-5" />
      </button>
    </div>
  );
}
