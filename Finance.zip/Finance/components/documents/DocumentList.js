'use client';

import { useState } from 'react';
import { DocumentIcon, EllipsisVerticalIcon, ArrowDownTrayIcon, TrashIcon, EyeIcon } from '@heroicons/react/24/outline';

const documents = [
  {
    id: 1,
    name: 'Tax_Return_2023.pdf',
    type: 'PDF',
    size: '2.4 MB',
    uploaded: '2 days ago',
    status: 'Active'
  },
  {
    id: 2,
    name: 'Contract_Agreement.docx',
    type: 'DOCX',
    size: '1.1 MB',
    uploaded: '1 week ago',
    status: 'Active'
  },
  {
    id: 3,
    name: 'Business_License.jpg',
    type: 'Image',
    size: '3.2 MB',
    uploaded: '2 weeks ago',
    status: 'Expired'
  },
  {
    id: 4,
    name: 'Bank_Statement_March.pdf',
    type: 'PDF',
    size: '1.8 MB',
    uploaded: '3 weeks ago',
    status: 'Active'
  },
];

export default function DocumentList() {
  const [selectedDocument, setSelectedDocument] = useState(null);

  const handleActionClick = (e, docId) => {
    e.stopPropagation();
    setSelectedDocument(selectedDocument === docId ? null : docId);
  };

  const handleAction = (e, action, docId) => {
    e.stopPropagation();
    setSelectedDocument(null);
    // Handle action (view, download, delete)
    console.log(`${action} document ${docId}`);
  };

  const getStatusBadge = (status) => {
    const statusClasses = {
      Active: 'bg-green-100 text-green-800',
      Expired: 'bg-yellow-100 text-yellow-800',
      Archived: 'bg-gray-100 text-gray-800'
    };
    
    return (
      <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${statusClasses[status] || 'bg-gray-100 text-gray-800'}`}>
        {status}
      </span>
    );
  };

  const getFileIcon = (type) => {
    const iconClasses = 'h-5 w-5 text-gray-400';
    
    switch(type.toLowerCase()) {
      case 'pdf':
        return <DocumentIcon className={`${iconClasses} text-red-500`} />;
      case 'docx':
      case 'doc':
        return <DocumentIcon className={`${iconClasses} text-blue-500`} />;
      case 'jpg':
      case 'jpeg':
      case 'png':
      case 'image':
        return <DocumentIcon className={`${iconClasses} text-green-500`} />;
      default:
        return <DocumentIcon className={iconClasses} />;
    }
  };

  return (
    <div className="overflow-hidden">
      <div className="align-middle inline-block min-w-full border-b border-gray-200">
        <table className="min-w-full divide-y divide-gray-200">
          <thead className="bg-gray-50">
            <tr>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Name
              </th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Type
              </th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Size
              </th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Uploaded
              </th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Status
              </th>
              <th scope="col" className="relative px-6 py-3">
                <span className="sr-only">Actions</span>
              </th>
            </tr>
          </thead>
          <tbody className="bg-white divide-y divide-gray-200">
            {documents.map((doc) => (
              <tr key={doc.id} className="hover:bg-gray-50 cursor-pointer">
                <td className="px-6 py-4 whitespace-nowrap">
                  <div className="flex items-center">
                    <div className="flex-shrink-0 h-10 w-10 flex items-center justify-center">
                      {getFileIcon(doc.type)}
                    </div>
                    <div className="ml-4">
                      <div className="text-sm font-medium text-gray-900">{doc.name}</div>
                    </div>
                  </div>
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <div className="text-sm text-gray-500">{doc.type}</div>
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <div className="text-sm text-gray-500">{doc.size}</div>
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                  {doc.uploaded}
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  {getStatusBadge(doc.status)}
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium relative">
                  <button
                    onClick={(e) => handleActionClick(e, doc.id)}
                    className="text-gray-400 hover:text-gray-600"
                  >
                    <EllipsisVerticalIcon className="h-5 w-5" />
                  </button>
                  {selectedDocument === doc.id && (
                    <div className="absolute right-0 mt-2 w-48 rounded-md shadow-lg bg-white ring-1 ring-black ring-opacity-5 z-10">
                      <div className="py-1">
                        <button
                          onClick={(e) => handleAction(e, 'view', doc.id)}
                          className="flex items-center px-4 py-2 text-sm text-gray-700 hover:bg-gray-100 w-full text-left"
                        >
                          <EyeIcon className="h-4 w-4 mr-2" /> View
                        </button>
                        <button
                          onClick={(e) => handleAction(e, 'download', doc.id)}
                          className="flex items-center px-4 py-2 text-sm text-gray-700 hover:bg-gray-100 w-full text-left"
                        >
                          <ArrowDownTrayIcon className="h-4 w-4 mr-2" /> Download
                        </button>
                        <button
                          onClick={(e) => handleAction(e, 'delete', doc.id)}
                          className="flex items-center px-4 py-2 text-sm text-red-600 hover:bg-gray-100 w-full text-left"
                        >
                          <TrashIcon className="h-4 w-4 mr-2" /> Delete
                        </button>
                      </div>
                    </div>
                  )}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
