'use client';

import { usePathname } from 'next/navigation';

export default function ClientLayout({ children }) {
  const pathname = usePathname();
  const isAuthPage = ['/login', '/signup', '/'].includes(pathname);

  return isAuthPage ? (
    <>{children}</>
  ) : (
    <div className="min-h-screen bg-gray-50">
      {children}
    </div>
  );
}
