"use client";

import React from "react";
import TransactionRow from "./TransactionRow";

const TransactionTable = ({ transaction }) => {
    // const paginatedTransactions = filteredTransactions.slice(startIndex, endIndex);

    // const handlePageChange = (page) => {
    //     setCurrentPage(Math.max(1, Math.min(page, totalPages)));
    //     window.scrollTo({ top: 0, behavior: 'smooth' });
    //   };
    
    //   const handleItemsPerPageChange = (e) => {
    //     const newItemsPerPage = parseInt(e.target.value, 10);
    //     setItemsPerPage(newItemsPerPage);
    //     // Recalculate current page to avoid empty results
    //     const newTotalPages = Math.ceil(transactions.length / newItemsPerPage);
    //     if (currentPage > newTotalPages) {
    //       setCurrentPage(newTotalPages || 1);
    //     }
    //   };

    console.log("Inside TransactionTable", transaction);
    return (
        <div className="bg-white border border-gray-200 shadow-lg overflow-hidden sm:rounded-lg">
            <div className="overflow-x-auto">
                <table className="min-w-full divide-y divide-gray-200">
                    <thead className="bg-gray-50">
                        <tr>
                            <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                Date
                            </th>
                            <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                Vendor
                            </th>
                            <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                Description
                            </th>
                            <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                Category
                            </th>
                            <th scope="col" className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                                Amount
                            </th>
                            <th scope="col" className="px-6 py-3 text-center text-xs font-medium text-gray-500 uppercase tracking-wider">
                                Status
                            </th>
                            <th scope="col" className="relative px-6 py-3">
                                <span className="sr-only">Actions</span>
                            </th>
                        </tr>
                    </thead>
                    <tbody className="bg-white divide-y divide-gray-200">
                        {transaction.length > 0 ? (
                            transaction.map((trans) => (
                                <TransactionRow key={trans.id} transaction={trans} />
                            ))
                        ) : (
                            <tr>
                                <td colSpan="7" className="px-6 py-4 text-center text-sm text-gray-500">
                                    No transactions found. Try adjusting your search or filters.
                                </td>
                            </tr>
                        )}
                    </tbody>
                </table>
            </div>

            {/* Pagination */}
            {/* <div className="bg-white px-4 py-3 flex flex-col sm:flex-row items-center justify-between border-t border-gray-200 sm:px-6 gap-4">
                <div className="flex items-center space-x-2">
                    <span className="text-sm text-gray-700">Rows per page:</span>
                    <select
                        value={itemsPerPage}
                        onChange={handleItemsPerPageChange}
                        className="mt-1 block w-20 pl-3 pr-10 py-1 text-base border-gray-300 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm rounded-md"
                    >
                        <option value={5}>5</option>
                        <option value={10}>10</option>
                        <option value={25}>25</option>
                        <option value={50}>50</option>
                        <option value={100}>100</option>
                    </select>
                </div>

                <div className="text-sm text-gray-700">
                    Showing <span className="font-medium">{filteredTransactions.length > 0 ? startIndex + 1 : 0}</span> to{' '}
                    <span className="font-medium">{Math.min(endIndex, filteredTransactions.length)}</span>{' '}
                    of <span className="font-medium">{filteredTransactions.length}</span> results
                    {dateRange !== 'all' && (
                        <span className="ml-2 text-xs bg-indigo-100 text-indigo-800 px-2 py-1 rounded-full">
                            {dateRange === '7days' ? 'Last 7 Days' :
                                dateRange === '30days' ? 'Last 30 Days' :
                                    dateRange === '6months' ? 'Last 6 Months' : 'Last Year'}
                        </span>
                    )}
                </div>

                <nav className="flex items-center space-x-1">
                    <button
                        onClick={() => handlePageChange(1)}
                        disabled={currentPage === 1}
                        className={`px-2 py-1 rounded-md ${currentPage === 1
                            ? 'text-gray-400 cursor-not-allowed'
                            : 'text-gray-600 hover:bg-gray-100'
                            }`}
                    >
                        <span className="sr-only">First</span>
                        <span className="text-xs">««</span>
                    </button>

                    <button
                        onClick={() => handlePageChange(currentPage - 1)}
                        disabled={currentPage === 1}
                        className={`px-2 py-1 rounded-md ${currentPage === 1
                            ? 'text-gray-400 cursor-not-allowed'
                            : 'text-gray-600 hover:bg-gray-100'
                            }`}
                    >
                        <span className="sr-only">Previous</span>
                        <FiChevronLeft className="h-5 w-5" />
                    </button>

                    {getPageNumbers().map((pageNum) => (
                        <button
                            key={pageNum}
                            onClick={() => handlePageChange(pageNum)}
                            className={`px-3 py-1 rounded-md text-sm font-medium ${currentPage === pageNum
                                ? 'bg-indigo-600 text-white'
                                : 'text-gray-700 hover:bg-gray-100'
                                }`}
                        >
                            {pageNum}
                        </button>
                    ))}

                    <button
                        onClick={() => handlePageChange(currentPage + 1)}
                        disabled={currentPage === totalPages || totalPages === 0}
                        className={`px-2 py-1 rounded-md ${currentPage === totalPages || totalPages === 0
                            ? 'text-gray-400 cursor-not-allowed'
                            : 'text-gray-600 hover:bg-gray-100'
                            }`}
                    >
                        <span className="sr-only">Next</span>
                        <FiChevronRight className="h-5 w-5" />
                    </button>

                    <button
                        onClick={() => handlePageChange(totalPages)}
                        disabled={currentPage === totalPages || totalPages === 0}
                        className={`px-2 py-1 rounded-md ${currentPage === totalPages || totalPages === 0
                            ? 'text-gray-400 cursor-not-allowed'
                            : 'text-gray-600 hover:bg-gray-100'
                            }`}
                    >
                        <span className="sr-only">Last</span>
                        <span className="text-xs">»»</span>
                    </button>
                </nav>
            </div> */}
        </div>
    );
};

export default TransactionTable;
