import React from 'react';

export default function TransactionSummary({ title, amount, subAmount }) {
  return (
    <div className="bg-white overflow-hidden shadow rounded-lg">
      <div className="p-5">
        <div className="flex items-center">
          <div className="flex-shrink-0 bg-blue-500 rounded-md p-3">
            <div className="h-6 w-6 text-white">
              {title.includes('Paid') ? '💰' : 
               title.includes('Drafts') ? '📝' :
               title.includes('Sent') ? '✉️' : '⏰'}
            </div>
          </div>
          <div className="ml-5 w-0 flex-1">
            <dl>
              <dt className="text-sm font-medium text-gray-500 truncate">
                {title}
              </dt>
              <dd>
                <div className="text-lg font-medium text-gray-900">
                  {amount}
                  {subAmount && (
                    <span className="ml-1 text-sm text-gray-500">
                      {subAmount}
                    </span>
                  )}
                </div>
              </dd>
            </dl>
          </div>
        </div>
      </div>
      <div className="bg-gray-50 px-5 py-3">
        <div className="text-sm">
          <a
            href="#"
            className="font-medium text-blue-600 hover:text-blue-500"
          >
            View all
          </a>
        </div>
      </div>
    </div>
  );
}
