'use client';

import React, { useState } from 'react';
import { useRouter } from 'next/navigation';
import { FiEdit2, FiTrash2, FiEye } from 'react-icons/fi';
import { format } from 'date-fns';
import TransactionModal from "../../components/TransactionModal";
import { formatCurrency } from '../../utils/common';
import { updateTransaction, deleteTransaction } from "../../app/api/transaction";

const paymentMethodIcons = {
    credit_card: '💳',
    debit_card: '💳',
    bank_transfer: '🏦',
    paypal: '🔵',
    upi: '📱',
    cash: '💵'
};

const TransactionRow = ({ transaction }) => {
    const router = useRouter();
    const [isModalOpen, setIsModalOpen] = useState(false);

    const viewDetailHandler = (id) => {
        router.push(`/dashboard/transactions/6856ea0beadfaa90158f0082`);
    }

    const modalCloseHandler = () => {
        setIsModalOpen(false);
    };

    const handleDelete = async (id) => {
        //TODO: open a confirmation modal 
        //TODO: delete the transaction from database.
        await deleteTransaction(transaction.id);
        modalCloseHandler();
        router.refresh();
    };

    const submitHandler = async (updatedData) => {
        //TODO: Update the transaction in database
        await updateTransaction(transaction.id, updatedData);
        modalCloseHandler();
        router.refresh();
    }

    return (
        <React.Fragment>
            <tr className="hover:bg-gray-50">
                <td className="px-6 py-4 whitespace-nowrap">
                    <div className="text-sm text-gray-900">
                        {format(new Date(transaction.date), 'MMM d, yyyy')}
                    </div>
                    <div className="text-xs text-gray-500">
                        {format(new Date(transaction.date), 'h:mm a')}
                    </div>
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                    <div className="flex items-center">
                        <div className="flex-shrink-0 h-10 w-10 flex items-center justify-center bg-indigo-100 rounded-full">
                            <span className="text-indigo-600">
                                {paymentMethodIcons[transaction.paymentMethod] || '💳'}
                            </span>
                        </div>
                        <div className="ml-4">
                            <div className="text-sm font-medium text-gray-900">
                                {transaction.vendor}
                            </div>
                            <div className="text-xs text-gray-500">
                                {transaction.paymentMethod.replace('_', ' ').charAt(0).toUpperCase() + transaction.paymentMethod.replace('_', ' ').slice(1)}
                            </div>
                        </div>
                    </div>
                </td>
                <td className="px-6 py-4">
                    <div className="text-sm text-gray-900 max-w-xs truncate">
                        {transaction.description || 'No description'}
                    </div>
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                    <span className="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-green-100 text-green-800">
                        {transaction.category}
                    </span>
                </td>
                <td className={`px-6 py-4 whitespace-nowrap text-right text-sm font-medium ${transaction.type === 'credit' ? 'text-green-600' : 'text-gray-900'
                    }`}>
                    {transaction.type === 'credit' ? '+' : '-'}{formatCurrency(transaction.amount).replace('$', '')}
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-center">
                    <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${transaction.status === 'completed'
                        ? 'bg-green-100 text-green-800'
                        : transaction.status === 'pending'
                            ? 'bg-yellow-100 text-yellow-800'
                            : 'bg-red-100 text-red-800'
                        }`}>
                        {transaction.status.charAt(0).toUpperCase() + transaction.status.slice(1)}
                    </span>
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                    <div className="flex justify-end space-x-2">
                        <button
                            onClick={() => viewDetailHandler(transaction.id)}
                            className="text-indigo-600 hover:text-indigo-900"
                            title="View Details"
                        >
                            <FiEye className="h-4 w-4" />
                        </button>
                        <button
                            onClick={() => setIsModalOpen(true)}
                            className="text-blue-600 hover:text-blue-900"
                            title="Edit"
                        >
                            <FiEdit2 className="h-4 w-4" />
                        </button>
                        <button
                            onClick={() => handleDelete(transaction.id)}
                            className="text-red-600 hover:text-red-900"
                            title="Delete"
                        >
                            <FiTrash2 className="h-4 w-4" />
                        </button>
                    </div>
                </td>
            </tr>
            <TransactionModal isOpen={isModalOpen} onClose={modalCloseHandler} initialData={transaction} onSubmit={submitHandler} />
        </React.Fragment>
    )
}

export default TransactionRow;