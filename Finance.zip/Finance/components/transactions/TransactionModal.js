'use client';

import { useState, useEffect } from 'react';
import { useForm } from "react-hook-form";

const TransactionModal = ({
  isOpen = false,
  onClose = () => { },
  onSubmit = () => { },
  initialData
}) => {
  const {
    register,
    handleSubmit,
    reset,
    formState: { errors },
  } = useForm({
    defaultValues: initialData
  });

  if (!isOpen) return null;

  return (
    <div className="fixed z-10 inset-0 overflow-y-auto" aria-labelledby="modal-title" role="dialog" aria-modal="true">
      <div className="flex items-end justify-center min-h-screen pt-4 px-4 pb-20 text-center sm:block sm:p-0">
        <div
          className="fixed inset-0 bg-gray-500 bg-opacity-75 transition-opacity"
          aria-hidden="true"
          onClick={onClose}
        ></div>
        <span className="hidden sm:inline-block sm:align-middle sm:h-screen" aria-hidden="true">&#8203;</span>
        <div className="inline-block align-bottom bg-white rounded-lg px-4 pt-5 pb-4 text-left overflow-hidden shadow-xl transform transition-all sm:my-8 sm:align-middle sm:max-w-lg sm:w-full sm:p-6">
          <div>
            <h3 className="text-lg leading-6 font-medium text-gray-900 text-center" id="modal-title">
              {initialData?.id ? 'Edit Transaction' : 'Add New Transaction'}
            </h3>
            <div className="mt-6">
              <form onSubmit={handleSubmit((data) => {
                onSubmit(data);
                reset();
              })} className="space-y-4">
                <div>
                  <label htmlFor="vendor" className="block text-sm font-medium text-gray-700 text-left mb-1">
                    Vendor
                  </label>
                  <input
                    type="text"
                    id="vendor"
                    required
                    className="w-full px-3 py-2 border border-gray-200 rounded-md shadow-sm focus:outline-none sm:text-sm"
                    {...register("provider", {
                      required: "Vendor is required",
                    })}
                  />
                </div>

                <div>
                  <label htmlFor="amount" className="block text-sm font-medium text-gray-700 text-left mb-1">
                    Amount
                  </label>
                  <div className="relative rounded-md shadow-sm">
                    <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                      <span className="text-gray-500 text-sm">Rs</span>
                    </div>
                    <input
                      type="number"
                      id="amount"
                      step="0.01"
                      className="w-full pl-7 pr-3 py-2 border border-gray-200 rounded-md focus:outline-none sm:text-sm"
                      placeholder="0.00"
                      {...register("amount", {
                        required: "Amount is required",
                      })}
                    />
                  </div>
                </div>

                <div>
                  <label htmlFor="description" className="block text-sm font-medium text-gray-700 text-left mb-1">
                    Description
                  </label>
                  <textarea
                    id="description"
                    rows={1}
                    className="w-full px-3 py-2 border border-gray-200 rounded-md shadow-sm focus:outline-none sm:text-sm"
                    {...register("description", {
                      required: "Description is required",
                    })}
                  />
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label htmlFor="type" className="block text-sm font-medium text-gray-700 text-left mb-1">
                      Type
                    </label>
                    <select
                      id="type"
                      className="w-full px-3 py-2 border border-gray-200 bg-white rounded-md shadow-sm focus:outline-none sm:text-sm"
                      {...register("transType", {
                        required: "Type is required",
                      })}
                    >
                      <option value="debit">Expense</option>
                      <option value="credit">Income</option>
                    </select>
                  </div>

                  <div>
                    <label htmlFor="status" className="block text-sm font-medium text-gray-700 text-left mb-1">
                      Status
                    </label>
                    <select
                      id="status"
                      className="w-full px-3 py-2 border border-gray-200 bg-white rounded-md shadow-sm focus:outline-none sm:text-sm"
                      {...register("status", {
                        required: "Status is required",
                      })}
                    >
                      <option value="Completed">Completed</option>
                      <option value="Pending">Pending</option>
                      <option value="Failed">Failed</option>
                    </select>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label htmlFor="paymentMethod" className="block text-sm font-medium text-gray-700 text-left mb-1">
                      Payment Method
                    </label>
                    <select
                      id="paymentMethod"
                      className="w-full px-3 py-2 border border-gray-200 bg-white rounded-md shadow-sm focus:outline-none sm:text-sm"
                      {...register("paymentMethod", {
                        required: "PaymentMethod is required",
                      })}
                    >
                      <option value="credit_card">Credit Card</option>
                      <option value="debit_card">Debit Card</option>
                      <option value="bank_transfer">Bank Transfer</option>
                      <option value="paypal">PayPal</option>
                      <option value="upi">UPI</option>
                      <option value="cash">Cash</option>
                    </select>
                  </div>

                  <div>
                    <label htmlFor="category" className="block text-sm font-medium text-gray-700 text-left mb-1">
                      Category
                    </label>
                    <select
                      id="category"
                      className="w-full px-3 py-2 border border-gray-200 bg-white rounded-md shadow-sm focus:outline-none sm:text-sm"
                      {...register("category", {
                        required: "Category is required",
                      })}
                    >
                      <option value="Other">Other</option>
                      <option value="Groceries">Groceries</option>
                      <option value="Dining">Dining</option>
                      <option value="Shopping">Shopping</option>
                      <option value="Entertainment">Entertainment</option>
                      <option value="Bills">Bills</option>
                      <option value="Transportation">Transportation</option>
                      <option value="Income">Income</option>
                      <option value="Education">Education</option>
                      <option value="Health">Health</option>
                    </select>
                  </div>
                </div>

                <div>
                  <label htmlFor="date" className="block text-sm font-medium text-gray-700 text-left mb-1">
                    Date
                  </label>
                  <input
                    type="date"
                    id="date"
                    required
                    className="w-full px-3 py-2 border border-gray-200 rounded-md shadow-sm focus:outline-none sm:text-sm"
                    {...register("transactionDate", {
                      required: "Date is required",
                    })}
                  />
                </div>

                <div className="mt-6 flex justify-end space-x-3">
                  <button
                    type="button"
                    className="px-4 py-2 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 bg-white hover:bg-gray-50 focus:outline-none"
                    onClick={onClose}
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="inline-flex justify-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none"
                  >
                    {initialData?.id ? 'Update' : 'Add'} Transaction
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default TransactionModal;
