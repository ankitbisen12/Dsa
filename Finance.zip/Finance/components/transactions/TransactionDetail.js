'use client';

import React, { useState, useEffect } from 'react';
import TransactionModal from './TransactionModal';
import { useRouter} from 'next/navigation';
import Link from 'next/link';
import { FiArrowLeft, FiEdit2, FiTrash2, FiPrinter, FiDownload, FiShare2, FiEye } from 'react-icons/fi';
import { formatCurrency, formatDate } from "../../utils/common";
import { updateTransaction, deleteTransaction } from '../../app/api/transaction';

const TransactionDetail = ({ transaction }) => {
    const [isModalOpen, setIsModalOpen] = useState(false);
    const router = useRouter();
    const [isLoading, setIsLoading] = useState(true);
    const [error, setError] = useState(null);

    const modalCloseHandler = () => {
        setIsModalOpen(false);
    };

    const handleUpdateTransaction = async (newTransactionData) => {
        //TODO: pop a message when successfully updated.
        await updateTransaction(transaction.id, newTransactionData);
        modalCloseHandler();
        router.refresh();
    };

    const handleDelete = async () => {
        // TODO: open a confirmation modal
        // TODO: delete the transaction from database.
        await deleteTransaction(transaction.id);
        modalCloseHandler();
        router.push('/dashboard/transactions');
    };

    if (error) {
        return (
            <div className="max-w-4xl mx-auto p-6">
                <div className="bg-red-50 border-l-4 border-red-500 p-4">
                    <div className="flex">
                        <div className="flex-shrink-0">
                            <svg className="h-5 w-5 text-red-500" viewBox="0 0 20 20" fill="currentColor">
                                <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 101.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z" clipRule="evenodd" />
                            </svg>
                        </div>
                        <div className="ml-3">
                            <p className="text-sm text-red-700">{error}</p>
                        </div>
                    </div>
                </div>
                <div className="mt-6">
                    <Link
                        href="/dashboard/transactions"
                        className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
                    >
                        <FiArrowLeft className="mr-2 h-4 w-4" />
                        Back to Transactions
                    </Link>
                </div>
            </div>
        );
    }

    if (!transaction) {
        return null;
    }

    return (
        <div className="max-w-4xl mx-auto p-4 sm:p-6">
            <div className="mb-6">
                <Link
                    href="/dashboard/transactions"
                    className="inline-flex items-center text-indigo-600 hover:text-indigo-800 mb-4"
                    target="_self"
                >
                    <FiArrowLeft className="mr-1" /> Back to Transactions
                </Link>

                <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-6">
                    <div>
                        <h1 className="text-2xl font-bold text-gray-900">Transaction Details</h1>
                        <p className="text-sm text-gray-500 mt-1">Reference: {transaction?.reference || 'N/A'}</p>
                    </div>

                    <div className="mt-4 sm:mt-0 flex space-x-3">
                        <button
                            onClick={() => setIsModalOpen(true)}
                            className="inline-flex items-center px-4 py-2 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 bg-white hover:bg-gray-50 focus:outline-none"
                        >
                            <FiEdit2 className="mr-2 h-4 w-4" /> Edit
                        </button>
                        <button
                            onClick={handleDelete}
                            className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-red-600 hover:bg-red-700 focus:outline-none"
                        >
                            <FiTrash2 className="mr-2 h-4 w-4" /> Delete
                        </button>
                    </div>
                </div>

                <div className="bg-white shadow overflow-hidden sm:rounded-lg">
                    <div className="px-4 py-5 sm:px-6 border-b border-gray-200">
                        <div className="flex justify-between items-center">
                            <div>
                                <h3 className="text-lg leading-6 font-medium text-gray-900">
                                    {transaction?.provider}
                                </h3>
                                <p className="mt-1 max-w-2xl text-sm text-gray-500">
                                    {transaction?.description}
                                </p>
                            </div>
                            <div className="text-right">
                                <p className={`text-2xl font-bold ${transaction.type === 'credit' ? 'text-green-600' : 'text-red-600'}`}>
                                    {transaction.transType === 'credit' ? '+' : '-'}{formatCurrency(transaction.amount)}
                                </p>
                                <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${transaction.status === 'completed'
                                    ? 'bg-green-100 text-green-800'
                                    : transaction.status === 'pending'
                                        ? 'bg-yellow-100 text-yellow-800'
                                        : 'bg-gray-100 text-gray-800'
                                    }`}>
                                    {transaction.status.charAt(0).toUpperCase() + transaction.status.slice(1)}
                                </span>
                            </div>
                        </div>
                    </div>

                    <div className="border-t border-gray-200 px-4 py-5 sm:p-0">
                        <dl className="sm:divide-y sm:divide-gray-200">
                            <div className="py-4 sm:py-5 sm:grid sm:grid-cols-3 sm:gap-4 sm:px-6">
                                <dt className="text-sm font-medium text-gray-500">Date</dt>
                                <dd className="mt-1 text-sm text-gray-900 sm:mt-0 sm:col-span-2">
                                    {formatDate(transaction?.date)}
                                </dd>
                            </div>
                            <div className="py-4 sm:py-5 sm:grid sm:grid-cols-3 sm:gap-4 sm:px-6">
                                <dt className="text-sm font-medium text-gray-500">Category</dt>
                                <dd className="mt-1 text-sm text-gray-900 sm:mt-0 sm:col-span-2">
                                    <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-indigo-100 text-indigo-800">
                                        {transaction?.category}
                                    </span>
                                </dd>
                            </div>
                            <div className="py-4 sm:py-5 sm:grid sm:grid-cols-3 sm:gap-4 sm:px-6">
                                <dt className="text-sm font-medium text-gray-500">Payment Method</dt>
                                <dd className="mt-1 text-sm text-gray-900 sm:mt-0 sm:col-span-2">
                                    {transaction?.paymentMethod}
                                </dd>
                            </div>
                            {/* {transaction?.notes && (
                                <div className="py-4 sm:py-5 sm:grid sm:grid-cols-3 sm:gap-4 sm:px-6">
                                    <dt className="text-sm font-medium text-gray-500">Notes</dt>
                                    <dd className="mt-1 text-sm text-gray-900 sm:mt-0 sm:col-span-2">
                                        {transaction.notes}
                                    </dd>
                                </div>
                            )} */}
                            {/* {transaction.receiptUrl && (
                                <div className="py-4 sm:py-5 sm:grid sm:grid-cols-3 sm:gap-4 sm:px-6">
                                    <dt className="text-sm font-medium text-gray-500">Receipt</dt>
                                    <dd className="mt-1 text-sm text-gray-900 sm:mt-0 sm:col-span-2">
                                        <div className="flex space-x-3">
                                            <a
                                                href={transaction.receiptUrl}
                                                target="_blank"
                                                rel="noopener noreferrer"
                                                className="inline-flex items-center px-3 py-1.5 border border-gray-300 shadow-sm text-sm leading-4 font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50 focus:outline-none"
                                            >
                                                <FiEye className="mr-1.5 h-4 w-4" /> View
                                            </a>
                                            <a
                                                href={transaction.receiptUrl}
                                                download
                                                className="inline-flex items-center px-3 py-1.5 border border-gray-300 shadow-sm text-sm leading-4 font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50 focus:outline-none"
                                            >
                                                <FiDownload className="mr-1.5 h-4 w-4" /> Download
                                            </a>
                                        </div>
                                    </dd>
                                </div>
                            )} */}
                        </dl>
                    </div>
                </div>
            </div>

            {/* Edit Transaction Modal */}
            <TransactionModal
                isOpen={isModalOpen}
                onClose={modalCloseHandler}
                initialData={transaction}
                onSubmit={handleUpdateTransaction}
            />
        </div>
    )
}

export default TransactionDetail;

//TODO: On clicking on view button a new window will open which show the receipt of transaction.
//TODO: If receipt is present then show the download button and user can download the receipt .
//TODO: Built small resuable component.