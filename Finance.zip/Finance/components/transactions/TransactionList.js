'use client';

import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { FiPlus } from 'react-icons/fi';
import TransactionTable from './TransactionTable';
import TransactionModal from './TransactionModal';
import { createTransaction } from "../../app/api/transaction";

// Mock data - In a real app, this would come from an API
const mockTransactions = [
  {
    id: '1',
    date: '2024-06-01',
    amount: 125.75,
    vendor: 'Grocery Store',
    description: 'Weekly grocery shopping',
    type: 'debit',
    status: 'completed',
    paymentMethod: 'credit_card',
    category: 'Groceries'
  },
  {
    id: '2',
    date: '2024-06-02',
    amount: 2500.00,
    vendor: 'Company Inc',
    description: 'Monthly salary',
    type: 'credit',
    status: 'completed',
    paymentMethod: 'bank_transfer',
    category: 'Income'
  },
  {
    id: '3',
    date: '2024-06-03',
    amount: 45.99,
    vendor: 'Netflix',
    description: 'Monthly subscription',
    type: 'debit',
    status: 'pending',
    paymentMethod: 'credit_card',
    category: 'Entertainment'
  },
  {
    id: '4',
    date: '2024-06-04',
    amount: 32.50,
    vendor: 'Coffee Shop',
    description: 'Morning coffee and snack',
    type: 'debit',
    status: 'completed',
    paymentMethod: 'debit_card',
    category: 'Food & Drinks'
  },
  {
    id: '5',
    date: '2024-06-05',
    amount: 89.99,
    vendor: 'Book Store',
    description: 'New books',
    type: 'debit',
    status: 'completed',
    paymentMethod: 'credit_card',
    category: 'Education'
  },
  {
    id: '6',
    date: '2024-06-06',
    amount: 120.00,
    vendor: 'Electric Company',
    description: 'Monthly bill',
    type: 'debit',
    status: 'pending',
    paymentMethod: 'bank_transfer',
    category: 'Utilities'
  }
];

export default function TransactionsPage({ transaction }) {
  const router = useRouter();
  const [transactions, setTransactions] = useState(mockTransactions);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [currentPage, setCurrentPage] = useState(1);
  const [itemsPerPage, setItemsPerPage] = useState(10);
  const [dateRange, setDateRange] = useState('all'); // '7days', '30days', '6months', '1year', 'all'
  const [filteredTransactions, setFilteredTransactions] = useState([...transactions]);

  // Filter transactions by date range
  useEffect(() => {
    const today = new Date();
    let filtered = [...transactions];

    if (dateRange !== 'all') {
      const dateRanges = {
        '7days': () => new Date(today.setDate(today.getDate() - 7)),
        '30days': () => new Date(today.setDate(today.getDate() - 30)),
        '6months': () => new Date(today.setMonth(today.getMonth() - 6)),
        '1year': () => new Date(today.setFullYear(today.getFullYear() - 1))
      };

      const startDate = dateRanges[dateRange]();
      filtered = transactions.filter(tx => new Date(tx.date) >= startDate);
    }

    setFilteredTransactions(filtered);
    setCurrentPage(1); // Reset to first page when filter changes
  }, [dateRange, transactions]);

  // Pagination
  const totalPages = Math.ceil(filteredTransactions.length / itemsPerPage);
  const startIndex = (currentPage - 1) * itemsPerPage;
  const endIndex = Math.min(startIndex + itemsPerPage, filteredTransactions.length);

  const modalCloseHandler = () => {
    setIsModalOpen(false);
  };

  const submitHandler = async (newTransactionData) => {
    console.log("submitHandler clicked for new transaction");
    const result = await createTransaction(newTransactionData);
    console.log("final result", result);
    modalCloseHandler();
    router.refresh();
  };

  return (
    <div className="flex-1 overflow-x-hidden overflow-y-auto bg-gray-50 p-2 md:p-0">
      <div className="max-w-7xl mx-auto">
        {/* Page Title and Actions */}
        <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-6">
          <div>
            <h1 className="text-2xl font-bold text-gray-900">Transactions</h1>
            <p className="text-sm text-gray-500">Track and manage your financial transactions</p>
          </div>
          <div className="mt-4 md:mt-0 flex space-x-2">
            <button
              onClick={() => setIsModalOpen(true)}
              className="inline-flex items-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none"
            >
              <FiPlus className="mr-2 h-4 w-4" /> Add Transaction
            </button>
          </div>
        </div>

        {/* Date Range Filter and Table */}
        <div className="flex justify-end mb-4">
          <div className="relative">
            <select
              value={dateRange}
              onChange={(e) => setDateRange(e.target.value)}
              className="block appearance-none bg-white border border-gray-300 px-4 py-2 pr-8 rounded shadow leading-tight focus:outline-none"
            >
              <option value="all">All Time</option>
              <option value="7days">Last 7 Days</option>
              <option value="30days">Last 30 Days</option>
              <option value="6months">Last 6 Months</option>
              <option value="1year">Last Year</option>
            </select>
            <div className="pointer-events-none absolute inset-y-0 right-0 flex items-center px-2 text-gray-700">
              <svg className="fill-current h-4 w-4" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20">
                <path d="M9.293 12.95l.707.707L15.657 8l-1.414-1.414L10 10.828 5.757 6.586 4.343 8z" />
              </svg>
            </div>
          </div>
        </div>

        {/* Transactions Table */}
        <TransactionTable transaction={transactions} />

        {/* Transaction Modal */}
        <TransactionModal isOpen={isModalOpen} onClose={modalCloseHandler} onSubmit={submitHandler} initialData={null} />
      </div>
    </div>
  );
}
