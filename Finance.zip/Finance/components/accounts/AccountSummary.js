'use client';

import { 
  BanknotesIcon,
  ArrowUpIcon,
  ArrowDownIcon,
  CurrencyDollarIcon,
  CreditCardIcon
} from '@heroicons/react/24/outline';

export default function AccountSummary({ title, amount, subTitle, icon, trend, trendPercentage }) {
  const getIcon = () => {
    const iconClasses = 'h-6 w-6 text-white';
    
    switch(icon) {
      case 'total':
        return <CurrencyDollarIcon className={iconClasses} />;
      case 'income':
        return <ArrowUpIcon className={iconClasses} />;
      case 'expense':
        return <ArrowDownIcon className={iconClasses} />;
      case 'debt':
        return <CreditCardIcon className={iconClasses} />;
      default:
        return <BanknotesIcon className={iconClasses} />;
    }
  };

  const getTrendColor = () => {
    if (!trend) return 'text-gray-400';
    return trend === 'up' ? 'text-green-500' : 'text-red-500';
  };

  const getBgColor = () => {
    switch(icon) {
      case 'total':
        return 'bg-indigo-500';
      case 'income':
        return 'bg-green-500';
      case 'expense':
        return 'bg-red-500';
      case 'debt':
        return 'bg-yellow-500';
      default:
        return 'bg-blue-500';
    }
  };

  return (
    <div className="bg-white overflow-hidden shadow rounded-lg">
      <div className="p-5">
        <div className="flex items-center">
          <div className={`flex-shrink-0 ${getBgColor()} rounded-md p-3`}>
            {getIcon()}
          </div>
          <div className="ml-5 w-0 flex-1">
            <dl>
              <dt className="text-sm font-medium text-gray-500 truncate">
                {title}
              </dt>
              <dd className="flex items-baseline">
                <div className="text-2xl font-semibold text-gray-900">
                  {amount}
                </div>
                {trend && (
                  <div className={`ml-2 flex items-baseline text-sm font-semibold ${getTrendColor()}`}>
                    {trend === 'up' ? (
                      <svg className="self-center flex-shrink-0 h-5 w-5 text-green-500" fill="currentColor" viewBox="0 0 20 20">
                        <path fillRule="evenodd" d="M5.293 9.707a1 1 0 010-1.414l4-4a1 1 0 011.414 0l4 4a1 1 0 01-1.414 1.414L11 7.414V15a1 1 0 11-2 0V7.414L6.707 9.707a1 1 0 01-1.414 0z" clipRule="evenodd" />
                      </svg>
                    ) : (
                      <svg className="self-center flex-shrink-0 h-5 w-5 text-red-500" fill="currentColor" viewBox="0 0 20 20">
                        <path fillRule="evenodd" d="M14.707 10.293a1 1 0 010 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 111.414-1.414L9 12.586V5a1 1 0 012 0v7.586l2.293-2.293a1 1 0 011.414 0z" clipRule="evenodd" />
                      </svg>
                    )}
                    <span className="sr-only">
                      {trend === 'up' ? 'Increased' : 'Decreased'} by
                    </span>
                    {trendPercentage}
                  </div>
                )}
              </dd>
              {subTitle && (
                <dd className="text-sm text-gray-500">
                  {subTitle}
                </dd>
              )}
            </dl>
          </div>
        </div>
      </div>
    </div>
  );
}

AccountSummary.defaultProps = {
  trend: null,
  trendPercentage: '',
  subTitle: ''
};
