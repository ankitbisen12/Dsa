'use client';

import { useState } from 'react';
import { 
  BanknotesIcon,
  CreditCardIcon,
  CurrencyDollarIcon,
  WalletIcon,
  PencilIcon,
  TrashIcon,
  EyeIcon,
  PlusIcon
} from '@heroicons/react/24/outline';

const accounts = [
  {
    id: 1,
    name: 'Chase Checking',
    type: 'Checking',
    balance: 12500.50,
    accountNumber: '•••• 3456',
    status: 'Active',
    currency: 'USD'
  },
  {
    id: 2,
    name: 'Bank of America Savings',
    type: 'Savings',
    balance: 32500.75,
    accountNumber: '•••• 7890',
    status: 'Active',
    currency: 'USD'
  },
  {
    id: 3,
    name: 'Chase Credit Card',
    type: 'Credit Card',
    balance: -1250.30,
    accountNumber: '•••• 2345',
    status: 'Active',
    currency: 'USD'
  },
  {
    id: 4,
    name: 'Cash Wallet',
    type: 'Cash',
    balance: 250.00,
    accountNumber: 'N/A',
    status: 'Active',
    currency: 'USD'
  },
];

export default function AccountList() {
  const [selectedAccount, setSelectedAccount] = useState(null);
  const [showAddAccount, setShowAddAccount] = useState(false);
  const [newAccount, setNewAccount] = useState({
    name: '',
    type: 'Checking',
    initialBalance: '',
    accountNumber: '',
    currency: 'USD'
  });

  const handleActionClick = (e, accountId) => {
    e.stopPropagation();
    setSelectedAccount(selectedAccount === accountId ? null : accountId);
  };

  const handleAction = (e, action, account) => {
    e.stopPropagation();
    setSelectedAccount(null);
    // Handle action (view, edit, delete)
    console.log(`${action} account`, account);
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setNewAccount(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleAddAccount = (e) => {
    e.preventDefault();
    // Here you would typically make an API call to add the account
    console.log('Adding new account:', newAccount);
    // Reset form
    setNewAccount({
      name: '',
      type: 'Checking',
      initialBalance: '',
      accountNumber: '',
      currency: 'USD'
    });
    setShowAddAccount(false);
  };

  const getAccountIcon = (type) => {
    const iconClasses = 'h-6 w-6 text-white';
    
    switch(type.toLowerCase()) {
      case 'savings':
        return <CurrencyDollarIcon className={iconClasses} />;
      case 'credit card':
        return <CreditCardIcon className={iconClasses} />;
      case 'cash':
        return <WalletIcon className={iconClasses} />;
      default: // checking
        return <BanknotesIcon className={iconClasses} />;
    }
  };

  const formatCurrency = (amount, currency = 'USD') => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: currency,
    }).format(Math.abs(amount));
  };

  return (
    <div className="overflow-hidden">
      {/* Add Account Form */}
      {showAddAccount && (
        <div className="bg-white p-6 rounded-lg shadow-md mb-6">
          <h3 className="text-lg font-medium text-gray-900 mb-4">Add New Account</h3>
          <form onSubmit={handleAddAccount} className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label htmlFor="name" className="block text-sm font-medium text-gray-700">
                  Account Name
                </label>
                <input
                  type="text"
                  name="name"
                  id="name"
                  required
                  value={newAccount.name}
                  onChange={handleInputChange}
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 sm:text-sm"
                />
              </div>
              <div>
                <label htmlFor="type" className="block text-sm font-medium text-gray-700">
                  Account Type
                </label>
                <select
                  id="type"
                  name="type"
                  value={newAccount.type}
                  onChange={handleInputChange}
                  className="mt-1 block w-full rounded-md border-gray-300 py-2 pl-3 pr-10 text-base focus:border-blue-500 focus:outline-none focus:ring-blue-500 sm:text-sm"
                >
                  <option value="Checking">Checking</option>
                  <option value="Savings">Savings</option>
                  <option value="Credit Card">Credit Card</option>
                  <option value="Cash">Cash</option>
                </select>
              </div>
              <div>
                <label htmlFor="initialBalance" className="block text-sm font-medium text-gray-700">
                  Initial Balance
                </label>
                <div className="mt-1 relative rounded-md shadow-sm">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                    <span className="text-gray-500 sm:text-sm">$</span>
                  </div>
                  <input
                    type="number"
                    name="initialBalance"
                    id="initialBalance"
                    step="0.01"
                    required
                    value={newAccount.initialBalance}
                    onChange={handleInputChange}
                    className="focus:ring-blue-500 focus:border-blue-500 block w-full pl-7 pr-12 sm:text-sm border-gray-300 rounded-md"
                    placeholder="0.00"
                  />
                </div>
              </div>
              <div>
                <label htmlFor="accountNumber" className="block text-sm font-medium text-gray-700">
                  Account Number (Last 4 digits)
                </label>
                <input
                  type="text"
                  name="accountNumber"
                  id="accountNumber"
                  value={newAccount.accountNumber}
                  onChange={handleInputChange}
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 sm:text-sm"
                  placeholder="Last 4 digits"
                />
              </div>
            </div>
            <div className="flex justify-end space-x-3 pt-2">
              <button
                type="button"
                onClick={() => setShowAddAccount(false)}
                className="inline-flex items-center px-4 py-2 border border-gray-300 shadow-sm text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
              >
                Add Account
              </button>
            </div>
          </form>
        </div>
      )}

      {/* Accounts List */}
      <div className="align-middle inline-block min-w-full border-b border-gray-200">
        <table className="min-w-full divide-y divide-gray-200">
          <thead className="bg-gray-50">
            <tr>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Account
              </th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Type
              </th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Account Number
              </th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Balance
              </th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Status
              </th>
              <th scope="col" className="relative px-6 py-3">
                <span className="sr-only">Actions</span>
              </th>
            </tr>
          </thead>
          <tbody className="bg-white divide-y divide-gray-200">
            {accounts.map((account) => (
              <tr key={account.id} className="hover:bg-gray-50 cursor-pointer">
                <td className="px-6 py-4 whitespace-nowrap">
                  <div className="flex items-center">
                    <div className="flex-shrink-0 h-10 w-10 rounded-md bg-blue-500 flex items-center justify-center">
                      {getAccountIcon(account.type)}
                    </div>
                    <div className="ml-4">
                      <div className="text-sm font-medium text-gray-900">{account.name}</div>
                      <div className="text-sm text-gray-500">{account.currency}</div>
                    </div>
                  </div>
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <div className="text-sm text-gray-900">{account.type}</div>
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <div className="text-sm text-gray-500">{account.accountNumber}</div>
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <div className={`text-sm font-medium ${account.balance < 0 ? 'text-red-600' : 'text-gray-900'}`}>
                    {formatCurrency(account.balance, account.currency)}
                  </div>
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <span className="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-green-100 text-green-800">
                    {account.status}
                  </span>
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium relative">
                  <button
                    onClick={(e) => handleActionClick(e, account.id)}
                    className="text-gray-400 hover:text-gray-600"
                  >
                    <svg className="h-5 w-5" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor">
                      <path d="M10 6a2 2 0 110-4 2 2 0 010 4zM10 12a2 2 0 110-4 2 2 0 010 4zM10 18a2 2 0 110-4 2 2 0 010 4z" />
                    </svg>
                  </button>
                  {selectedAccount === account.id && (
                    <div className="absolute right-0 mt-2 w-48 rounded-md shadow-lg bg-white ring-1 ring-black ring-opacity-5 z-10">
                      <div className="py-1">
                        <button
                          onClick={(e) => handleAction(e, 'view', account)}
                          className="flex items-center px-4 py-2 text-sm text-gray-700 hover:bg-gray-100 w-full text-left"
                        >
                          <EyeIcon className="h-4 w-4 mr-2" /> View
                        </button>
                        <button
                          onClick={(e) => handleAction(e, 'edit', account)}
                          className="flex items-center px-4 py-2 text-sm text-gray-700 hover:bg-gray-100 w-full text-left"
                        >
                          <PencilIcon className="h-4 w-4 mr-2" /> Edit
                        </button>
                        <button
                          onClick={(e) => handleAction(e, 'delete', account)}
                          className="flex items-center px-4 py-2 text-sm text-red-600 hover:bg-gray-100 w-full text-left"
                        >
                          <TrashIcon className="h-4 w-4 mr-2" /> Delete
                        </button>
                      </div>
                    </div>
                  )}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Add Account Button */}
      {!showAddAccount && (
        <div className="mt-4">
          <button
            type="button"
            onClick={() => setShowAddAccount(true)}
            className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
          >
            <PlusIcon className="-ml-1 mr-2 h-5 w-5" />
            Add Account
          </button>
        </div>
      )}
    </div>
  );
}
