
const ProfileBtn = ({ buttonText, onButtonClick, buttonVariant = 'primary', buttonIcon: ButtonIcon, children }) => {
    return (
        <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-2">
            {children}
            {buttonText && (
                <button
                    type="button"
                    onClick={onButtonClick}
                    className={`mt-3 md:mt-0 inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white ${buttonVariant === 'primary' ? 'bg-indigo-600 hover:bg-indigo-700' : 'bg-red-800 text-gray-400 '
                        }`}
                >
                    {ButtonIcon && <ButtonIcon className="h-4 w-4 mr-2" />}
                    {buttonText}
                </button>
            )}
        </div>
    );
}

export default ProfileBtn;
