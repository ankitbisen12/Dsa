export const FormField = ({ label, value, type = 'text', name, onChange, placeholder, disabled = false }) => {
    return (
        <div className="mb-2">
            <label htmlFor={name} className="block text-sm font-medium text-gray-700 mb-1">
                {label}
            </label>
            <input
                type={type}
                name={name}
                id={name}
                value={value}
                onChange={onChange}
                disabled={disabled}
                placeholder={placeholder}
                className="block w-full rounded-md border-gray-300 shadow-sm outline-none sm:text-sm p-2 "
            />
        </div>
    );
}