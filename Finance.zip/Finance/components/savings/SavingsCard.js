import { FiEdit2, FiTrash2, FiChevronRight, FiCalendar } from 'react-icons/fi';
import { useRouter } from 'next/navigation';

export default function SavingsCard({ saving, onEdit, onDelete }) {
  const router = useRouter();
  
  const handleViewDetails = () => {
    if (saving.type === 'rd') {
      router.push(`/savings/rd/${saving.id}`);
    } else if (saving.type === 'gold') {
      router.push(`/savings/gold/${saving.id}`);
    } else if (saving.type === 'insurance') {
      router.push(`/savings/insurance/${saving.id}`);
    } else if (saving.type === 'stocks') {
      router.push(`/savings/stocks/${saving.id}`);
    }
  };
  const getTypeDetails = () => {
    switch (saving.type) {
      case 'fd':
        return {
          bgColor: 'bg-blue-50',
          textColor: 'text-blue-600',
          icon: '🏦',
          typeName: 'Fixed Deposit',
          showQuantity: false
        };
      case 'rd':
        return {
          bgColor: 'bg-green-50',
          textColor: 'text-green-600',
          icon: '📈',
          typeName: 'Recurring Deposit',
          showQuantity: false
        };
      case 'gold':
        return {
          bgColor: 'bg-yellow-50',
          textColor: 'text-yellow-600',
          icon: '🥇',
          typeName: 'Digital Gold',
          showQuantity: true,
          quantityLabel: 'Grams',
          quantityValue: saving.quantity
        };
      case 'stocks':
        return {
          bgColor: 'bg-purple-50',
          textColor: 'text-purple-600',
          icon: '📊',
          typeName: 'Stocks',
          showQuantity: true,
          quantityLabel: 'Shares',
          quantityValue: saving.quantity,
          showSymbol: true,
          symbol: saving.symbol
        };
      case 'insurance':
        return {
          bgColor: 'bg-red-50',
          textColor: 'text-red-600',
          icon: '🛡️',
          typeName: 'Insurance',
          policyNumber: saving.policyNumber,
          showPremium: true,
          premiumAmount: saving.premiumAmount,
          premiumFrequency: saving.premiumFrequency
        };
      default:
        return {
          bgColor: 'bg-gray-50',
          textColor: 'text-gray-600',
          icon: '💰',
          typeName: 'Savings',
          showQuantity: false
        };
    }
  };

  const { 
    bgColor, 
    textColor, 
    icon, 
    typeName, 
    showQuantity, 
    quantityLabel, 
    quantityValue,
    showSymbol,
    symbol,
    policyNumber,
    showPremium,
    premiumAmount,
    premiumFrequency
  } = getTypeDetails();
  
  const formatDate = (dateString) => {
    const options = { year: 'numeric', month: 'short', day: 'numeric' };
    return new Date(dateString).toLocaleDateString('en-US', options);
  };

  const getProgress = () => {
    if (saving.type === 'rd' && saving.installments) {
      const paidCount = typeof saving.paidInstallments === 'object' ? saving.paidInstallments.number : saving.paidInstallments || 0;
      const totalInstallments = typeof saving.installments === 'object' ? saving.installments.number : saving.installments;
      return (paidCount / totalInstallments) * 100;
    }
    return 100;
  };

  const getNextInstallmentDate = () => {
    if (saving.type !== 'rd' || !saving.date) return null;
    
    const paidCount = typeof saving.paidInstallments === 'object' ? saving.paidInstallments.number : saving.paidInstallments || 0;
    if (!paidCount) return null;
    
    const startDate = new Date(saving.date);
    // Add number of months equal to paid installments to get next installment date
    const nextDate = new Date(startDate);
    nextDate.setMonth(startDate.getMonth() + paidCount);
    
    // Format the date as "MMM dd, yyyy"
    return nextDate.toLocaleDateString('en-US', { 
      year: 'numeric', 
      month: 'short', 
      day: 'numeric' 
    });
  };
  
  const nextInstallmentDate = getNextInstallmentDate();

  return (
    <div 
      className="bg-white rounded-lg shadow-md overflow-hidden border border-gray-100 hover:shadow-lg transition-transform hover:-translate-y-0.5 cursor-pointer"
      onClick={handleViewDetails}
    >
      <div className="p-4">
        <div className="flex justify-between items-start mb-4">
          <div className="flex items-center space-x-3">
            <div className={`w-10 h-10 ${bgColor} rounded-full flex items-center justify-center text-xl`}>
              {icon}
            </div>
            <div>
              <h3 className="font-medium text-gray-900">{saving.title}</h3>
              <p className="text-sm text-gray-500">{saving.institution}</p>
            </div>
          </div>
          <div className="flex space-x-2">
            <button 
              onClick={(e) => {
                e.stopPropagation();
                onEdit(saving);
              }}
              className="text-gray-400 hover:text-blue-600 transition-colors"
            >
              <FiEdit2 size={18} />
            </button>
            <button 
              onClick={(e) => {
                e.stopPropagation();
                onDelete(saving.id);
              }}
              className="text-gray-400 hover:text-red-600 transition-colors"
            >
              <FiTrash2 size={18} />
            </button>
          </div>
        </div>

        <div className="mt-4 space-y-2">
          {/* Stock Symbol if applicable */}
          {showSymbol && symbol && (
            <div className="flex justify-between items-center">
              <span className="text-sm text-gray-500">Symbol</span>
              <span className="font-medium">{symbol}</span>
            </div>
          )}
          
          {/* Policy Number for Insurance */}
          {policyNumber && (
            <div className="flex justify-between items-center">
              <span className="text-sm text-gray-500">Policy No.</span>
              <span className="text-sm font-mono">{policyNumber}</span>
            </div>
          )}
          
          {/* Investment Amount */}
          <div className="flex justify-between items-center">
            <span className="text-sm text-gray-500">
              {saving.type === 'stocks' ? 'Invested' : 'Amount'}
            </span>
            <span className="font-medium">₹{saving.amount?.toLocaleString() || '0'}</span>
          </div>
          
          {/* Current Value */}
          {saving.currentValue !== undefined && (
            <div className="flex justify-between items-center">
              <span className="text-sm text-gray-500">Current Value</span>
              <div className="text-right">
                <span className="font-medium">₹{saving.currentValue.toLocaleString()}</span>
                {saving.profitLoss !== undefined && (
                  <span className={`ml-2 text-xs ${saving.profitLoss >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                    {saving.profitLoss >= 0 ? '↑' : '↓'} {Math.abs(saving.profitLoss).toLocaleString()} 
                    ({saving.profitLossPercentage?.toFixed(2)}%)
                  </span>
                )}
              </div>
            </div>
          )}
          
          {/* Quantity for Gold/Stocks */}
          {showQuantity && quantityValue !== undefined && (
            <div className="flex justify-between items-center">
              <span className="text-sm text-gray-500">{quantityLabel}</span>
              <span>{quantityValue} {saving.type === 'gold' ? 'g' : ''}</span>
            </div>
          )}
          
          {/* Premium Info for Insurance */}
          {showPremium && (
            <div className="flex justify-between items-center">
              <span className="text-sm text-gray-500">Premium</span>
              <span>₹{premiumAmount?.toLocaleString()} {premiumFrequency && `(${premiumFrequency})`}</span>
            </div>
          )}
          
          {/* Maturity Date */}
          {saving.maturityDate && (
            <div className="flex justify-between items-center">
              <span className="text-sm text-gray-500">
                {saving.type === 'insurance' ? 'Maturity' : 'Maturity Date'}
              </span>
              <span>{formatDate(saving.maturityDate)}</span>
            </div>
          )}
          
          {/* Interest Rate */}
          {saving.interestRate && (
            <div className="flex justify-between items-center">
              <span className="text-sm text-gray-500">Interest Rate</span>
              <span>{saving.interestRate}%</span>
            </div>
          )}
          
          {/* Next Premium Due for Insurance */}
          {saving.nextPremiumDue && (
            <div className="flex justify-between items-center text-sm">
              <span className="text-gray-500">Next Premium</span>
              <span className="flex items-center">
                <FiCalendar className="mr-1 text-blue-500" size={14} />
                {formatDate(saving.nextPremiumDue)}
              </span>
            </div>
          )}
          
          {saving.installments && (
            <div className="mt-2 space-y-2">
              <div className="flex justify-between text-sm">
                <span className="text-gray-500">Installments</span>
                <span>{
                  (typeof saving.paidInstallments === 'object' ? saving.paidInstallments.number : saving.paidInstallments) || 0
                }/{
                  typeof saving.installments === 'object' ? saving.installments.number : saving.installments
                } paid</span>
              </div>
              <div className="w-full bg-gray-200 rounded-full h-2">
                <div 
                  className="bg-blue-600 h-2 rounded-full" 
                  style={{ width: `${getProgress()}%` }}
                ></div>
              </div>
              {nextInstallmentDate && (
                <div className="flex items-center text-sm text-gray-600 mt-1">
                  <FiCalendar className="mr-1.5 text-blue-500" size={14} />
                  <span>Next: {nextInstallmentDate}</span>
                </div>
              )}
            </div>
          )}
        </div>
      </div>
      
      <div className="border-t border-gray-100 px-4 py-2 bg-gray-50 flex justify-between items-center">
        <span className={`text-xs px-2 py-1 rounded-full ${bgColor} ${textColor}`}>
          {typeName}
        </span>
        <div className="text-blue-600 text-sm font-medium flex items-center">
          View Details <FiChevronRight className="ml-1" />
        </div>
      </div>
    </div>
  );
}
