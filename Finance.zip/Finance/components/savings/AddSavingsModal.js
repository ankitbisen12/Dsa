'use client';
import { useState, useEffect } from 'react';
import { FiX, FiUpload, FiDollarSign, FiCalendar, FiPercent, FiHash } from 'react-icons/fi';

export default function AddSavingsModal({ isOpen, onClose, onSave, initialData }) {
  const [formData, setFormData] = useState({
    type: 'fd',
    title: '',
    amount: '',
    institution: '',
    date: new Date().toISOString().split('T')[0],
    maturityDate: '',
    interestRate: '',
    installments: '',
    paidInstallments: '',
    quantity: '',
    currentValue: '',
    status: 'active',
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [file, setFile] = useState(null);
  const [fileName, setFileName] = useState('');

  useEffect(() => {
    if (initialData) {
      setFormData({
        ...initialData,
        date: initialData.date ? initialData.date.split('T')[0] : '',
        maturityDate: initialData.maturityDate ? initialData.maturityDate.split('T')[0] : '',
      });
    } else {
      // Reset form when opening modal for new entry
      setFormData({
        type: 'fd',
        title: '',
        amount: '',
        institution: '',
        date: new Date().toISOString().split('T')[0],
        maturityDate: '',
        interestRate: '',
        installments: '',
        paidInstallments: '',
        quantity: '',
        currentValue: '',
        status: 'active',
      });
      setFile(null);
      setFileName('');
    }
  }, [initialData, isOpen]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleFileChange = (e) => {
    const selectedFile = e.target.files[0];
    if (selectedFile) {
      setFile(selectedFile);
      setFileName(selectedFile.name);
    }
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    setIsSubmitting(true);
    
    // In a real app, you would upload the file here and get a URL
    setTimeout(() => {
      const newSavings = {
        ...formData,
        id: initialData?.id || Date.now(),
        amount: parseFloat(formData.amount) || 0,
        interestRate: parseFloat(formData.interestRate) || 0,
        installments: parseInt(formData.installments) || 0,
        paidInstallments: parseInt(formData.paidInstallments) || 0,
        quantity: parseFloat(formData.quantity) || 0,
        currentValue: parseFloat(formData.currentValue) || 0,
        statementUrl: file ? URL.createObjectURL(file) : null,
      };
      
      onSave(newSavings);
      onClose();
      setIsSubmitting(false);
    }, 1000);
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-lg w-full max-w-2xl max-h-[90vh] overflow-y-auto">
        <div className="flex justify-between items-center p-4 border-b">
          <h2 className="text-xl font-semibold">
            {initialData ? 'Edit Savings' : 'Add New Savings'}
          </h2>
          <button onClick={onClose} className="text-gray-500 hover:text-gray-700">
            <FiX size={24} />
          </button>
        </div>
        
        <form onSubmit={handleSubmit} className="p-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Left Column */}
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Type</label>
                <select
                  name="type"
                  value={formData.type}
                  onChange={handleChange}
                  className="w-full p-2 border rounded-md "
                  required
                >
                  <option value="fd">Fixed Deposit</option>
                  <option value="rd">Recurring Deposit</option>
                  <option value="gold">Digital Gold</option>
                  <option value="stocks">Stocks</option>
                  <option value="insurance">Insurance</option>
                </select>
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Title</label>
                <input
                  type="text"
                  name="title"
                  value={formData.title}
                  onChange={handleChange}
                  placeholder="e.g., HDFC FD, SBI RD, etc."
                  className="w-full p-2 border rounded-md"
                  required
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Institution</label>
                <input
                  type="text"
                  name="institution"
                  value={formData.institution}
                  onChange={handleChange}
                  placeholder="e.g., HDFC Bank, SBI, etc."
                  className="w-full p-2 border rounded-md"
                  required
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  {formData.type === 'gold' ? 'Quantity (grams)' : 'Amount (₹)'}
                </label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                    <FiDollarSign className="text-gray-400" />
                  </div>
                  <input
                    type="number"
                    name="amount"
                    value={formData.amount}
                    onChange={handleChange}
                    placeholder={formData.type === 'gold' ? '0.00' : '0'}
                    step={formData.type === 'gold' ? '0.01' : '1'}
                    min="0"
                    className="w-full pl-10 p-2 border rounded-md"
                    required
                  />
                </div>
              </div>
              
              {formData.type === 'gold' && (
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Current Value (₹)
                  </label>
                  <div className="relative">
                    <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                      <FiDollarSign className="text-gray-400" />
                    </div>
                    <input
                      type="number"
                      name="currentValue"
                      value={formData.currentValue}
                      onChange={handleChange}
                      placeholder="0"
                      min="0"
                      step="1"
                      className="w-full pl-10 p-2 border rounded-md"
                    />
                  </div>
                </div>
              )}
            </div>
            
            {/* Right Column */}
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Date</label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                    <FiCalendar className="text-gray-400" />
                  </div>
                  <input
                    type="date"
                    name="date"
                    value={formData.date}
                    onChange={handleChange}
                    className="w-full pl-10 p-2 border rounded-md"
                    required
                  />
                </div>
              </div>
              
              {(formData.type === 'fd' || formData.type === 'rd' || formData.type === 'insurance') && (
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    {formData.type === 'insurance' ? 'Maturity/End Date' : 'Maturity Date'}
                  </label>
                  <div className="relative">
                    <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                      <FiCalendar className="text-gray-400" />
                    </div>
                    <input
                      type="date"
                      name="maturityDate"
                      value={formData.maturityDate}
                      onChange={handleChange}
                      className="w-full pl-10 p-2 border rounded-md"
                      required={formData.type !== 'insurance'}
                    />
                  </div>
                </div>
              )}
              
              {(formData.type === 'fd' || formData.type === 'rd') && (
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Interest Rate (%)
                  </label>
                  <div className="relative">
                    <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                      <FiPercent className="text-gray-400" />
                    </div>
                    <input
                      type="number"
                      name="interestRate"
                      value={formData.interestRate}
                      onChange={handleChange}
                      placeholder="0.00"
                      step="0.01"
                      min="0"
                      className="w-full pl-10 p-2 border rounded-md"
                    />
                  </div>
                </div>
              )}
              
              {formData.type === 'rd' && (
                <>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Total Installments
                    </label>
                    <div className="relative">
                      <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                        <FiHash className="text-gray-400" />
                      </div>
                      <input
                        type="number"
                        name="installments"
                        value={formData.installments}
                        onChange={handleChange}
                        placeholder="12"
                        min="1"
                        className="w-full pl-10 p-2 border rounded-md"
                      />
                    </div>
                  </div>
                  
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Paid Installments
                    </label>
                    <div className="relative">
                      <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                        <FiHash className="text-gray-400" />
                      </div>
                      <input
                        type="number"
                        name="paidInstallments"
                        value={formData.paidInstallments}
                        onChange={handleChange}
                        placeholder="0"
                        min="0"
                        max={formData.installments || ''}
                        className="w-full pl-10 p-2 border rounded-md"
                      />
                    </div>
                  </div>
                </>
              )}
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Status
                </label>
                <select
                  name="status"
                  value={formData.status}
                  onChange={handleChange}
                  className="w-full p-2 border rounded-md"
                >
                  <option value="active">Active</option>
                  <option value="matured">Matured</option>
                  <option value="closed">Closed</option>
                </select>
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Upload Statement (Optional)
                </label>
                <div className="mt-1 flex items-center">
                  <label className="cursor-pointer bg-white py-2 px-3 border border-gray-300 rounded-md text-sm leading-4 font-medium text-gray-700 hover:bg-gray-50">
                    <span>Choose File</span>
                    <input
                      type="file"
                      className="sr-only"
                      onChange={handleFileChange}
                      accept=".pdf,.csv,.xls,.xlsx"
                    />
                  </label>
                  <span className="ml-2 text-sm text-gray-500">
                    {fileName || 'No file chosen'}
                  </span>
                </div>
                <p className="mt-1 text-xs text-gray-500">
                  PDF, CSV, Excel (Max 5MB)
                </p>
              </div>
            </div>
          </div>
          
          <div className="mt-8 flex justify-end space-x-3">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 border border-gray-300 rounded-md text-sm font-medium text-gray-700 bg-white hover:bg-gray-50"
              disabled={isSubmitting}
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 disabled:opacity-50"
              disabled={isSubmitting}
            >
              {isSubmitting ? 'Saving...' : 'Save'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
