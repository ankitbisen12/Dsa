'use client';
import { Line } from 'react-chartjs-2';
import { Chart as ChartJS, CategoryScale, LinearScale, PointElement, LineElement, Title, Tooltip, Legend } from 'chart.js';

// Register ChartJS components
ChartJS.register(CategoryScale, LinearScale, PointElement, LineElement, Title, Tooltip, Legend);

export default function SavingsChart({ data, timeRange = 'thisMonth' }) {
  // This is a simplified example - in a real app, you'd process your data here
  const getChartData = () => {
    // Mock data - replace with actual data processing
    const labels = [];
    const values = [];
    
    // Generate sample data based on time range
    const days = timeRange === 'thisMonth' ? new Date().getDate() : 12;
    const baseValue = 10000;
    
    for (let i = 1; i <= days; i++) {
      labels.push(timeRange === 'thisMonth' ? `${i}` : `Month ${i}`);
      values.push(baseValue + (Math.random() * 5000) + (i * 1000));
    }
    
    return {
      labels,
      datasets: [
        {
          label: 'Total Savings',
          data: values,
          borderColor: 'rgb(59, 130, 246)',
          backgroundColor: 'rgba(59, 130, 246, 0.1)',
          tension: 0.3,
          fill: true,
        },
      ],
    };
  };

  const options = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: {
        position: 'top',
      },
      tooltip: {
        callbacks: {
          label: function(context) {
            return `₹${context.parsed.y.toLocaleString()}`;
          }
        }
      }
    },
    scales: {
      y: {
        beginAtZero: true,
        ticks: {
          callback: function(value) {
            return '₹' + value.toLocaleString();
          }
        }
      }
    }
  };

  return (
    <div className="w-full h-full">
      <Line data={getChartData()} options={options} />
    </div>
  );
}
