export function fetchAllTransactions() {
    return new Promise(async (resolve) => {
      const response = await fetch("/api/transactions");
      //TODO: Server will filter deleted transactions.
      const data = await response.json();
      resolve({ data });
    });
  }
  
  export function fetchTransactionById(id) {
    return new Promise(async (resolve) => {
      const response = await fetch("/api/transactions/" + id);
      const data = await response.json();
      // console.log(data);
      resolve({ data });
    });
  }
  
  export function createTransaction(transaction) {
    return new Promise(async (resolve) => {
      const response = await fetch("/api/transactions", {
        method: "POST",
        body: JSON.stringify(transaction),
        headers: { "content-type": "application/json" },
      });
      const data = await response.json();
      resolve({ data });
    });
  }
  
  export function updateTransaction(update) {
    return new Promise(async (resolve) => {
      const response = await fetch("/api/transactions/" + update.id, {
        method: "PATCH",
        body: JSON.stringify(update),
        headers: { "content-type": "application/json" },
      });
      const data = await response.json();
      resolve({ data });
    });
  }

  export function deleteTransaction(itemId) {
    return new Promise(async (resolve) => {
      const response = await fetch("/api/transactions" + itemId, {
        method: "DELETE",
        body: JSON.stringify(),
        headers: { "content-type": "application/json" },
      });
      const data = await response.json();
      resolve({ data: { id: itemId } });
    });
  }