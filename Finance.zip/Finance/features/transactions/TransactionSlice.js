import { createAsyncThunk, createSlice } from "@reduxjs/toolkit";
import { fetchAllTransactions, fetchTransactionById, createTransaction, updateTransaction, deleteTransaction } from "./TransactionAPI";

const initialState = {
    transactions: [],
    status: "idle",
    selectedTransaction: null
};

export const fetchAllTransactionsAsync = createAsyncThunk(
    "transaction/fetchAllTransactions",
    async () => {
        const response = await fetchAllTransactions();
        // The value we return becomes the `fulfilled` action payload
        return response.data;
    }
);

export const fetchTransactionByIdAsync = createAsyncThunk(
    "transaction/fetchTransactionById",
    async (id) => {
        const response = await fetchTransactionById(id);
        // The value we return becomes the `fulfilled` action payload
        return response.data;
    }
);

export const createTransactionAsync = createAsyncThunk(
    "transaction/createTransaction",
    async ({ transaction}) => {
        const response = await createTransaction(transaction);
        return response.data;
    }
);

export const updateTransactionAsync = createAsyncThunk(
    "transaction/updateTransaction",
    async ({ transaction}) => {
        const response = await updateTransaction(transaction);
        return response.data;
    }
);

export const transactionSlice = createSlice({
    name: "transaction",
    initialState,
    reducers: {
    },
    extraReducers: (builder) => {
        builder
            .addCase(fetchAllTransactionsAsync.pending, (state) => {
                state.status = "loading";
            })
            .addCase(fetchAllTransactionsAsync.fulfilled, (state, action) => {
                state.status = "idle";
                state.transactions = action.payload;
            })
            .addCase(fetchTransactionByIdAsync.pending, (state) => {
                state.status = "loading";
            })
            .addCase(fetchTransactionByIdAsync.fulfilled, (state, action) => {
                state.status = "idle";
                state.selectedTransaction = action.payload;
            })
            .addCase(createTransactionAsync.pending, (state) => {
                state.status = "loading";
            })
            .addCase(createTransactionAsync.fulfilled, (state, action) => {
                state.status = "idle";
                state.transactions.push(action.payload);
            })
            .addCase(updateTransactionAsync.pending, (state) => {
                state.status = "loading";
            })
            .addCase(updateTransactionAsync.fulfilled, (state, action) => {
                state.status = "idle";
                const index = state.transactions.findIndex(
                    (transaction) => transaction.id === action.payload.id
                );
                state.transactions[index] = action.payload;
            });
    },
});

export const selectTransactions = (state) => state.transaction.transactions;
export const selectTransactionById = (state) => state.transaction.selectedTransaction;
export const selectedStatus = (state) => state.transaction.status;

export default transactionSlice.reducer;
