import OpenAI from "openai";

const openai = new OpenAI({
  apiKey: "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",
});

const completion = openai.chat.completions.create({
  model: "gpt-4o-mini",
  store: true,
  messages: [
    {"role": "user", "content": "write a haiku about ai"},
  ],
  max_tokens: 5
});

completion.then((result) => console.log(result.choices[0].message));