## Create a Add transaction button which opens a form which contains
    - Date
    - Amnt
    - Vendor
    - Description
    - Type (debit or credit)
    - Status

## Key Goals: 
   - Display user transactions in a clear and searchable format
   - Allow filter , sorting , and categorization 
   - offer insights like monthly total, top spend categories , and recurring deposits.

## add a route /transaction/details
   - Display every detail of transaction 

## Filters and Search
   - Search bar :search by amount,upi app
   - Payment method filter

## Buttons
   - Add Transaction -new Opens a modal/form to add a new entry
   - Export CSV/PDF - For record-keeping
   - Bulk Actions - Select multiple rows to delete or categories

## Add Pagination 
   - Only recent 10 transactions will show 

## Nice to have
   - Auto detect and categories UPI notes(if integrated with SMS or email parsing)
   - Visual insights (bar/pie charts for spending habits)
   - Mobile Responsive design
   - Manual transaction entry form
   - Real time amount formatting.


## TODO TASK for transactions/[id]
   - On Cliking on Export the current month transactions will downloaded in a PDF file.
   - On clicking on Download the receipt will be downloaded for particular transaction
   - On Cliking on View Button the receipt will be opened in a new tab.

   

## Login Page
## Used react-hook-form library
 