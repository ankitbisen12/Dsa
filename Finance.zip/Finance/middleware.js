// middleware.js
import {  NextResponse } from "next/server";
import { decrypt } from "./app/lib/session";  // adjust path as needed

// Only these routes are public; everything else requires auth
const publicRoutes = ["/", "/login", "/signup"];

export default async function middleware(req) {
  const { pathname } = req.nextUrl;

  // Check for session cookie and decrypt
  const cookie = req.cookies.get("session")?.value;
  const session = cookie ? await decrypt(cookie) : null;

  // If route is not in publicRoutes and user is NOT authenticated, redirect to /login
  if (!publicRoutes.includes(pathname) && !session?.userId) {
    return NextResponse.redirect(new URL("/", req.nextUrl));
  }

  // If route IS public (login/signup) and user IS authenticated, redirect to /dashboard
  if (["/login", "/signup"].includes(pathname) && session?.userId) {
    return NextResponse.redirect(new URL("/", req.nextUrl));
  }

  // Otherwise, allow
  return NextResponse.next();
}

// Apply middleware to all pages (excluding static files, API, and _next internals)
export const config = {
  matcher: ["/((?!api|_next|.*\\..*).*)"],
};
