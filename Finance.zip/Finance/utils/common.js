export const formatCurrency = (amount) => {
    return new Intl.NumberFormat('en-US', {
        style: 'currency',
        currency: 'USD',
    }).format(amount);
};

export const formatDate = (dateString) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
    });
  };

export const formatJoinDate=(isoDate)=> {
  const date = new Date(isoDate);

  const day = date.getDate();
  const month = date.toLocaleString('default', { month: 'long' }); // 'June'
  const year = date.getFullYear();

  return `${day} ${month} ${year}`;
}


export const sanitizeUser = (user) => {
    return {id:user._id.toString(),role:user.role};
}