import mongoose from "mongoose";

const goldSavingsSchema = new mongoose.Schema({
    title: { type: String, required: true },
    savingType: { type: String, required: true },
    amount: { type: Number, required: true },
    grams: { type: String, required: true },
    purchaseDate: { type: Date, required: true },
    status: { type: String, enum: ['Active', 'Inactive'], default: 'Active' },
    provider: { type: String, required: [true, 'Provider is required'] },
    user: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'User',
        required: [true, 'User reference is required']
    },

}, { timestamps: true });

goldSavingsSchema.virtual('id').get(function () {
    return this._id;
});

goldSavingsSchema.set('toJSON', {
    virtuals: true,
    versionKey: false,
    transform: function (doc, ret) {
        delete ret._id;
    },
})

const GoldSavings = mongoose.model('GoldSavings', goldSavingsSchema);

export default GoldSavings.models.GoldSavings || GoldSavings;

