import mongoose from 'mongoose';

// Define the schema
const TransactionSchema = new mongoose.Schema({
    user: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'User',
        required: [true, 'User reference is required']
    },
    provider: { type: String, required: true },
    amount: { type: Number, min: [0, 'Amount cannot be negative'], required: true },
    description: { type: String, required: true },
    transType: { type: String, required: true },
    paymentMethod: { type: String, required: true },
    category: { type: String, required: true },
    status: { type: String, enum: ['Completed', 'Pending', 'Failed'], default: 'NA' },
    transactionDate: { type: String, required: true }
}, { timestamps: true });

// Add virtual for id
TransactionSchema.virtual('id').get(function () {
    return this._id;
});

// Configure toJSON
TransactionSchema.set('toJSON', {
    virtuals: true,
    versionKey: false,
    transform: function (doc, ret) {
        delete ret._id;
        delete ret.__v;
    },
});

const Transaction = mongoose.models.Transaction || mongoose.model("Transaction", TransactionSchema);
export default Transaction;