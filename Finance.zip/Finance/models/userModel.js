import mongoose from "mongoose";

const userSchema = new mongoose.Schema({
    name: {
        type: String,
        required: [true, "Name is required"],
        maxlength: [70, "Name can't be more than 70 characters"]
    },
    email: {
        type: String,
        unique: true,
        required: [true, "Email is required"],
        trim: true,
        match: [/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/, "Please enter a valid email address"]
    },
    password: { type: Buffer},
    role: { type: String, enum: ['User', 'Admin'], default: 'User' },
    salt: { type: Buffer },
    phoneNo: { type: Number, unique: true },
    profileImage: { type: String },
    occupation:{type:String},
    address: { type: String},
    status: { type: String, enum: ['Active', 'Inactive'], default: 'Active' },
    profileImage: {
        data: Buffer,
        contentType: String,
    }
}, {
    timestamps: true
});

userSchema.virtual('id').get(function () {
    return this._id;
});

userSchema.set('toJSON', {
    virtuals: true,
    versionKey: false,
    transform: function (doc, ret) {
        delete ret._id;
    },
});

// Static method to find or create user from Google profile
userSchema.statics.findOrCreate = async function (profile) {
    let user = await this.findOne({ email: profile.email });

    if (!user) {
        // Create new user
        user = new this({
            name: profile.name,
            email: profile.email,
        });
        await user.save();
    }

    return user;
};

const User = mongoose.models.User || mongoose.model('User', userSchema);
export default User;