import mongoose from 'mongoose';

const savingsModel = new mongoose.Schema({
    user: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'User',
        required: [true, 'User reference is required']
    },
    savingType: {
        type: String,
        required: [true, 'Saving type is required'],
        enum: ['FD', 'RD', 'SIP', 'PPF', 'SSY', 'NSC', 'Lumpsum', 'Other'],
        trim: true
    },
    title: {
        type: String,
        required: [true, 'Title is required'],
        maxlength: [100, 'Title cannot be more than 100 characters']
    },
    provider: {
        type: String,
        required: [true, 'Provider is required'],
    },
    mAmount: {
        type: Number,
        required: [true, 'Maturity amount is required'],
        min: [0, 'Maturity amount cannot be negative']
    },
    startDate: {
        type: Date,
        required: [true, 'Start date is required'],
        default: Date.now
    },
    endDate: {
        type: Date,
        required: [
            function() { return this.savingType !== 'RD' && this.savingType !== 'SIP'; },
            'End date is required for this saving type'
        ]
    },
    currentValue: {
        type: Number,
        default: 0
    },
    installmentAmnt: {
        type: Number,
        required: [
            function() { return ['RD', 'SIP'].includes(this.savingType); },
            'Installment amount is required for this saving type'
        ],
        min: [0, 'Installment amount cannot be negative']
    },
    interestRate: {
        type: Number,
        required: [true, 'Interest rate is required'],
        min: [0, 'Interest rate cannot be negative'],
        max: [100, 'Interest rate seems too high']
    },
    interestPayout: {
        type: String,
        enum: ['Monthly', 'Quarterly', 'Annually', 'At Maturity'],
        default: 'At Maturity'
    },
    status: {
        type: String,
        enum: ['Active', 'Matured', 'Closed'],
        default: 'Active'
    },
    totalInstallments: {
        type: Number,
        min: [1, 'Total installments must be at least 1']
    },
    paidInstallments: {
        type: Number,
        default: 0,
        min: [0, 'Paid installments cannot be negative']
    },
    nextDueDate: {
        type: Date
    },
    taxDeduction: {
        type: Boolean,
        default: false
    },
    taxDeductionSection: {
        type: String,
        trim: true
    },
    notes: {
        type: String,
        trim: true,
        maxlength: [500, 'Notes cannot be more than 500 characters']
    },
    isAutoDebit: {
        type: Boolean,
        default: false
    },
    autoDebitDate: {
        type: Number,
        min: 1,
        max: 31,
        validate: {
            validator: Number.isInteger,
            message: 'Auto debit date must be a valid day of month'
        }
    },
    documents: [{
        name: String,
        url: String,
        uploadedAt: {
            type: Date,
            default: Date.now
        }
    }], 
    isActive: {
        type: Boolean,
        default: true
    }
}, { 
    timestamps: true,
    toJSON: { virtuals: true },
    toObject: { virtuals: true }
});

// Virtual for remaining installments
savingsModel.virtual('remainingInstallments').get(function() {
    if (this.totalInstallments && this.paidInstallments) {
        return this.totalInstallments - this.paidInstallments;
    }
    return null;
});

// Virtual for maturity in days
savingsModel.virtual('daysToMaturity').get(function() {
    if (this.endDate) {
        const today = new Date();
        const diffTime = this.endDate - today;
        return Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    }
    return null;
});

// Indexes for better query performance
savingsModel.index({ user: 1, status: 1 });
savingsModel.index({ endDate: 1 });
savingsModel.index({ status: 1 });

savingsModel.virtual('id').get(function () {
    return this._id;
});

savingsModel.set('toJSON', {
    virtuals: true,
    versionKey: false,
    transform: function (doc, ret) {
        delete ret._id;
    },
});

const Savings = mongoose.model('Savings', savingsModel);

export default mongoose.models.Savings || Savings;
